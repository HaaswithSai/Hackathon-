import json
from typing import List, Dict, Any

from .programmatic.loop_detector import detect_loop
from .programmatic.termination_detector import detect_premature_termination, detect_termination_blindness
from .llm_judge.echo_chamber import detect_echo_chamber

def aggregate_failures(transcript_path: str, task_success: bool) -> Dict[str, Any]:
    """
    Reads a raw transcript and runs the full MAST evaluation swarm.
    Returns a dictionary of failure mode boolean flags.
    """
    transcript = []
    try:
        with open(transcript_path, 'r') as f:
            for line in f:
                if line.strip():
                    transcript.append(json.loads(line))
    except Exception as e:
        print(f"Failed to read transcript: {e}")
        return {}

    failures = {
        "success": task_success,
        "Category_1_Specification": {
            "looping": detect_loop(transcript),
            "termination_blindness": detect_termination_blindness(transcript, task_success),
            # role_drift, task_disobedience, context_degradation would be called here via LLM Judge
        },
        "Category_2_Misalignment": {
            "echo_chamber": detect_echo_chamber(transcript),
            # info_siloing, agent_dominance, reasoning_action_mismatch, unresolved_conflict
        },
        "Category_3_Verification": {
            "premature_termination": detect_premature_termination(transcript, task_success),
            # superficial_verification, incorrect_verification, hallucinated_verification
        }
    }
    
    # The Aggregator Node resolves conflicts.
    # E.g., if LLM Judge flags echo chamber, but task succeeded on first pass (1-2 turns),
    # it might be genuine consensus (sycophancy without error), override the judge.
    if failures["success"] and len(transcript) <= 3:
        if failures["Category_2_Misalignment"]["echo_chamber"]:
            print("Aggregator Override: Task succeeded rapidly. Overriding Echo Chamber false positive.")
            failures["Category_2_Misalignment"]["echo_chamber"] = False
            
    return failures
