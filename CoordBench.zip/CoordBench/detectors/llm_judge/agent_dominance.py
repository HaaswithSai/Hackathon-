from typing import List, Dict, Any

def detect_agent_dominance(transcript: List[Dict[str, Any]], dominance_threshold: float = 0.8) -> bool:
    """
    Detects Agent Dominance.
    Definition: A single agent contributes >80% of the token volume or tool calls, 
    effectively treating the other agents as passive observers rather than peers.
    This is primarily a programmatic check based on token counts in the transcript,
    but sits in the LLM_judge category contextually as a semantic failure of collaboration.
    """
    if not transcript:
        return False
        
    agent_stats = {}
    total_tokens = 0
    total_tool_calls = 0
    
    for turn in transcript:
        agent = turn.get("agent", "Unknown")
        
        # We calculate "contribution" as completion tokens
        tokens = turn.get("completion_tokens", 0)
        tools = len(turn.get("tools_called", []))
        
        if agent not in agent_stats:
            agent_stats[agent] = {"tokens": 0, "tools": 0}
            
        agent_stats[agent]["tokens"] += tokens
        agent_stats[agent]["tools"] += tools
        
        total_tokens += tokens
        total_tool_calls += tools
        
    if total_tokens == 0 and total_tool_calls == 0:
        return False
        
    for agent, stats in agent_stats.items():
        token_share = stats["tokens"] / total_tokens if total_tokens > 0 else 0
        tool_share = stats["tools"] / total_tool_calls if total_tool_calls > 0 else 0
        
        if token_share > dominance_threshold or tool_share > dominance_threshold:
            # We don't want to flag dominance if there's only one agent supposed to work
            if len(agent_stats) > 1:
                return True
                
    return False
