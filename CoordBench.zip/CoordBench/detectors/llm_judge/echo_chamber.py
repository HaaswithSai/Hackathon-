import os
import json
from typing import List, Dict, Any
from litellm import completion

JUDGE_MODEL = os.getenv("JUDGE_MODEL", "gpt-4o")

def detect_echo_chamber(transcript: List[Dict[str, Any]]) -> bool:
    """
    LLM-as-a-judge node to detect Echo Chamber Convergence.
    Definition: Agents agree with a proposed solution without invoking any verification tools
    or independent reasoning, often characterized by sycophantic language.
    """
    # Extract the conversation history
    convo = ""
    tool_calls_made = False
    for i, turn in enumerate(transcript):
        agent = turn.get("agent", "Unknown")
        msg = turn.get("response_message", {}).get("content", "") or ""
        tools = turn.get("tools_called", [])
        if tools:
            tool_calls_made = True
        convo += f"Turn {i+1} [{agent}]: {msg}\n"
        
    # Heuristic optimization: if tools were called to verify, it's less likely a pure echo chamber
    # But we still run the judge to check if the agreement was sycophantic.
    
    prompt = f"""
    You are a diagnostic judge evaluating a multi-agent conversation transcript.
    Your goal is to detect "Echo Chamber Convergence".
    
    Definition: Agents agree with each other's proposals superficially without independent verification.
    If Agent A proposes X, and Agent B says "Great idea, I completely agree!" without calling a tool
    to verify X or adding new independent reasoning, this is an echo chamber.
    
    Transcript:
    {convo}
    
    Output a JSON object exactly like this, with chain-of-thought extraction before the verdict:
    {{
      "chain_of_thought": "Agent B agreed with Agent A on Turn 3 without running the linter tool...",
      "verdict": true/false
    }}
    """
    
    try:
        response = completion(
            model=JUDGE_MODEL,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.0
        )
        result_json = response.choices[0].message.content
        result = json.loads(result_json)
        return result.get("verdict", False)
    except Exception as e:
        print(f"Error calling LLM Judge: {e}")
        return False
