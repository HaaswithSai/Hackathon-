import os
import json
from typing import List, Dict, Any
from litellm import completion

JUDGE_MODEL = os.getenv("JUDGE_MODEL", "gpt-4o")

def detect_info_siloing(transcript: List[Dict[str, Any]], agent_contexts: Dict[str, str]) -> bool:
    """
    LLM-as-a-judge node to detect Information Siloing.
    Definition: An agent possesses critical partial information required to solve the task,
    but fails to broadcast it to the other agents despite being prompted to share.
    """
    convo = ""
    for i, turn in enumerate(transcript):
        agent = turn.get("agent", "Unknown")
        msg = turn.get("response_message", {}).get("content", "") or ""
        convo += f"Turn {i+1} [{agent}]: {msg}\n"
        
    contexts_str = json.dumps(agent_contexts, indent=2)
    
    prompt = f"""
    You are a diagnostic judge evaluating a multi-agent conversation transcript.
    Your goal is to detect "Information Siloing".
    
    Definition: Information Siloing occurs when an agent has critical information in its context 
    that is necessary to solve the task, but it never shares that specific information in the conversation,
    leading to failure or suboptimal decisions.
    
    Agent Contexts (what they know):
    {contexts_str}
    
    Transcript (what they actually said):
    {convo}
    
    Output a JSON object exactly like this, with chain-of-thought extraction before the verdict:
    {{
      "chain_of_thought": "Agent B knows from its context that srv-B had an OOM kill, but looking at the transcript, Agent B only ever said 'My server looks fine'...",
      "verdict": true/false
    }}
    """
    
    try:
        response = completion(
            model=JUDGE_MODEL,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.0
        )
        result = json.loads(response.choices[0].message.content)
        return result.get("verdict", False)
    except Exception as e:
        print(f"Error calling LLM Judge for Info Siloing: {e}")
        return False
