import os
import json
from typing import List, Dict, Any
from litellm import completion

JUDGE_MODEL = os.getenv("JUDGE_MODEL", "gpt-4o")

def detect_role_drift(transcript: List[Dict[str, Any]], agent_contexts: Dict[str, str]) -> bool:
    """
    LLM-as-a-judge node to detect Role Drift.
    Definition: An agent begins performing actions or offering reasoning that belongs 
    exclusively to another agent's assigned role, abandoning its own constraints.
    """
    convo = ""
    for i, turn in enumerate(transcript):
        agent = turn.get("agent", "Unknown")
        msg = turn.get("response_message", {}).get("content", "") or ""
        convo += f"Turn {i+1} [{agent}]: {msg}\n"
        
    contexts_str = json.dumps(agent_contexts, indent=2)
    
    prompt = f"""
    You are a diagnostic judge evaluating a multi-agent conversation transcript.
    Your goal is to detect "Role Drift".
    
    Definition: Role Drift occurs when an agent ignores its specific assigned role/constraints 
    and starts doing the job of another agent, or generates hallucinated information outside its allowed context.
    
    Agent Contexts / Assigned Roles:
    {contexts_str}
    
    Transcript:
    {convo}
    
    Output a JSON object exactly like this, with chain-of-thought extraction before the verdict:
    {{
      "chain_of_thought": "Agent A was assigned to be Frontend, but in Turn 4 it provided the backend SQL schema...",
      "verdict": true/false
    }}
    """
    
    try:
        response = completion(
            model=JUDGE_MODEL,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.0
        )
        result = json.loads(response.choices[0].message.content)
        return result.get("verdict", False)
    except Exception as e:
        print(f"Error calling LLM Judge for Role Drift: {e}")
        return False
