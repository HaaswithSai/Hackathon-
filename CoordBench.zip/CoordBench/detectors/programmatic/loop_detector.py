import Levenshtein
from typing import List, Dict, Any

def detect_loop(transcript: List[Dict[str, Any]], distance_threshold: float = 0.1, consecutive_turns: int = 3) -> bool:
    """
    Detects if agents are caught in a tool-calling or text loop.
    Computes Levenshtein distance between consecutive tool calls or messages.
    If the normalized distance is below the threshold for 3+ consecutive turns, a loop is flagged.
    """
    if len(transcript) < consecutive_turns:
        return False
        
    loop_count = 0
    for i in range(1, len(transcript)):
        prev = transcript[i-1]
        curr = transcript[i]
        
        # Check tool calls first
        prev_tools = prev.get("tools_called", [])
        curr_tools = curr.get("tools_called", [])
        
        if prev_tools and curr_tools:
            # Simplify by just stringifying the tool call arguments
            prev_args = str([t.get("function", {}).get("arguments", "") for t in prev_tools])
            curr_args = str([t.get("function", {}).get("arguments", "") for t in curr_tools])
            
            max_len = max(len(prev_args), len(curr_args))
            if max_len == 0:
                continue
                
            dist = Levenshtein.distance(prev_args, curr_args) / max_len
            if dist < distance_threshold:
                loop_count += 1
                if loop_count >= consecutive_turns - 1:
                    return True
            else:
                loop_count = 0
        else:
            # Fall back to checking message content
            prev_content = prev.get("response_message", {}).get("content", "") or ""
            curr_content = curr.get("response_message", {}).get("content", "") or ""
            
            max_len = max(len(prev_content), len(curr_content))
            if max_len < 20: # Ignore very short messages like "OK"
                continue
                
            dist = Levenshtein.distance(prev_content, curr_content) / max_len
            if dist < distance_threshold:
                loop_count += 1
                if loop_count >= consecutive_turns - 1:
                    return True
            else:
                loop_count = 0
                
    return False
