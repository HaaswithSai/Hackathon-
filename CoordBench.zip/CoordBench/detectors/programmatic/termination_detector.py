from typing import List, Dict, Any

def detect_premature_termination(transcript: List[Dict[str, Any]], task_success: bool) -> bool:
    """
    Detects if the TERMINATE signal was emitted before the programmatic evaluator returned success.
    In our offline evaluation pipeline, we know if the final answer was correct.
    If the agents terminated but the answer was wrong, it's premature termination.
    """
    has_termination = any(turn.get("is_termination", False) for turn in transcript)
    
    if has_termination and not task_success:
        return True
        
    return False

def detect_termination_blindness(transcript: List[Dict[str, Any]], task_success: bool) -> bool:
    """
    Detects if the agents reached the correct answer but failed to emit TERMINATE,
    causing the run to hit max_turns or token limits.
    """
    has_termination = any(turn.get("is_termination", False) for turn in transcript)
    
    if task_success and not has_termination:
        return True
        
    return False
