import re
from typing import List, Dict, Any

class AgentDominanceDetector:
    """
    Detects if an agent exhibits dominance by frequently rejecting 
    other agents' input without verifiable tool use or data.
    """
    
    REJECTION_PHRASES = [
        r"\bno\b", r"disagree", r"incorrect", r"wrong", r"reject",
        r"cannot accept", r"unacceptable", r"impossible"
    ]
    
    def __init__(self, threshold: float = 0.5, min_turns: int = 3):
        """
        :param threshold: The ratio of rejections to total messages for an agent to be flagged.
        :param min_turns: Minimum messages from an agent before being evaluated for dominance.
        """
        self.threshold = threshold
        self.min_turns = min_turns

    def detect(self, transcript: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluates a transcript for agent dominance.
        Transcript is expected to be a list of dicts with 'agent' and 'content' keys.
        """
        rejection_counts = {}
        total_counts = {}
        
        for turn in transcript:
            agent = turn.get("agent", "Unknown")
            content = turn.get("content", "").lower()
            
            # Simple heuristic for tool usage (e.g., contains JSON block or tool string)
            has_tool_usage = "```json" in content or "tool_call" in content or "using tool" in content
            
            # Check for rejection phrases
            is_rejection = any(re.search(phrase, content) for phrase in self.REJECTION_PHRASES)
            
            if agent not in total_counts:
                total_counts[agent] = 0
                rejection_counts[agent] = 0
                
            total_counts[agent] += 1
            
            # Dominance heuristic: rejection without tool usage or clear verifiable backing
            if is_rejection and not has_tool_usage:
                rejection_counts[agent] += 1
                
        results = {
            "flagged": False,
            "details": {}
        }
        
        for agent, total in total_counts.items():
            if total >= self.min_turns:
                ratio = rejection_counts[agent] / total
                results["details"][agent] = {
                    "rejections": rejection_counts[agent],
                    "total": total,
                    "ratio": ratio
                }
                if ratio >= self.threshold:
                    results["flagged"] = True
                    results["dominant_agent"] = agent
                    
        return results
