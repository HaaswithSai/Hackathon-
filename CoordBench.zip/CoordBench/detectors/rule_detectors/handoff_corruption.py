import re
from typing import List, Dict, Any

class HandoffCorruptionDetector:
    """
    Detects if information successfully retrieved or stated by Agent A 
    was missing or altered when passed to or used by Agent B.
    """
    
    def __init__(self):
        pass

    def detect(self, transcript: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluates a transcript for handoff corruption.
        We track explicit variable-like assignments (e.g., "code is 123", "IP: 192.168.0.1")
        and see if they get mangled by the next agent.
        """
        results = {
            "flagged": False,
            "details": {}
        }
        
        # Simple regex to find assignments or stated facts, e.g., "port 8080", "part is 456"
        # We will look for numbers for simplicity as they are often subjects of corruption.
        number_pattern = re.compile(r'\b\d+\b')
        
        stated_facts = {} # Track numbers stated by agents
        
        for turn in transcript:
            agent = turn.get("agent", "")
            content = turn.get("content", "")
            
            numbers_in_turn = number_pattern.findall(content)
            
            # Check if this agent is using a number that is close to but NOT exactly 
            # what was previously stated, which might indicate corruption (e.g., 456 -> 457)
            for prev_agent, prev_numbers in stated_facts.items():
                if prev_agent != agent:
                    for num in numbers_in_turn:
                        for prev_num in prev_numbers:
                            # If it's a different number but has the same length and differs by 1 digit
                            if len(num) == len(prev_num) and num != prev_num and len(num) >= 3:
                                diff_count = sum(1 for a, b in zip(num, prev_num) if a != b)
                                if diff_count == 1:
                                    results["flagged"] = True
                                    results["details"]["corruption_detected"] = True
                                    results["details"]["original_value"] = prev_num
                                    results["details"]["corrupted_value"] = num
                                    results["details"]["from_agent"] = prev_agent
                                    results["details"]["to_agent"] = agent
                                    return results
                                    
            # Register numbers stated by this agent
            if agent not in stated_facts:
                stated_facts[agent] = set()
            stated_facts[agent].update(numbers_in_turn)
            
        return results
