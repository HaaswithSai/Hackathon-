from typing import List, Dict, Any

class InterAgentConflictDetector:
    """
    Detects 'Deadlocks' or stagnation where agents repeat the same
    arguments in a loop without advancing the state.
    """
    
    def __init__(self, similarity_threshold: float = 0.8, window_size: int = 4):
        """
        :param similarity_threshold: Jaccard similarity threshold to consider two messages identical.
        :param window_size: Look back window to detect loops (e.g. A->B->A->B).
        """
        self.similarity_threshold = similarity_threshold
        self.window_size = window_size

    def _jaccard_similarity(self, str1: str, str2: str) -> float:
        set1 = set(str1.lower().split())
        set2 = set(str2.lower().split())
        if not set1 or not set2:
            return 0.0
        intersection = set1.intersection(set2)
        union = set1.union(set2)
        return len(intersection) / len(union)

    def detect(self, transcript: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluates a transcript for stagnation (deadlocks).
        """
        results = {
            "flagged": False,
            "details": {}
        }
        
        if len(transcript) < self.window_size:
            return results
            
        for i in range(len(transcript)):
            current_turn = transcript[i]
            current_content = current_turn.get("content", "")
            current_agent = current_turn.get("agent", "")
            
            # Look back to see if this agent said something highly similar recently
            start_idx = max(0, i - self.window_size)
            for j in range(start_idx, i):
                past_turn = transcript[j]
                
                # Check if it's the same agent repeating itself
                if past_turn.get("agent") == current_agent:
                    sim = self._jaccard_similarity(current_content, past_turn.get("content", ""))
                    if sim >= self.similarity_threshold:
                        results["flagged"] = True
                        results["details"]["loop_detected"] = True
                        results["details"]["agent"] = current_agent
                        results["details"]["similarity"] = sim
                        results["details"]["repeated_turn_indices"] = (j, i)
                        return results
                        
        return results
