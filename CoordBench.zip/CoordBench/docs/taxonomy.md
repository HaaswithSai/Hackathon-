# Multi-Agent System Taxonomy (MAST) of Failures

This document formally defines the 14 failure modes captured by the MAC-Bench framework. Every definition is falsifiable and can be measured programmatically or via a strict LLM-as-a-judge diagnostic node.

## Category 1: Specification Issues (~42% of typical failures)

1. **Task Disobedience**: The agents successfully complete a task, but the outcome violates a hard constraint explicitly provided in the initial task specification.
2. **Role Drift**: An agent begins performing actions or offering reasoning that belongs exclusively to another agent's assigned role, abandoning its own constraints.
3. **Step Repetition / Looping**: Agents repeat identical or near-identical sequences of tool calls or messages for 3 or more consecutive turns without altering state.
4. **Context Degradation**: A constraint or piece of information introduced in turn 1 is explicitly contradicted or ignored by the same agent in turn N.
5. **Termination Blindness**: The agents reach the correct answer but fail to emit the required `TERMINATE` signal, continuing to converse indefinitely until hitting token/turn limits.

## Category 2: Inter-Agent Misalignment (~37% of typical failures)

6. **Information Siloing**: An agent possesses critical partial information required to solve the task, but fails to broadcast it to the other agents despite being prompted to share.
7. **Echo Chamber Convergence**: Agents quickly agree with a proposed (often incorrect) solution without invoking any verification tools or independent reasoning. Characterized by sycophantic language.
8. **Agent Dominance**: A single agent contributes >80% of the token volume or tool calls, effectively treating the other agents as passive observers rather than peers.
9. **Reasoning-Action Mismatch**: An agent correctly identifies a constraint in its reasoning trace, but its subsequent action or tool call directly violates that same constraint.
10. **Unresolved Conflict**: Agents disagree on a course of action and fail to reach a compromise, resulting in a timeout or an aborted execution without a final answer.

## Category 3: Task Verification (~21% of typical failures)

11. **Premature Termination**: The `TERMINATE` signal is emitted before the programmatic evaluator confirms that the task is successfully completed.
12. **Superficial Verification**: An agent is tasked with verifying a solution, but approves it based solely on the proposer's explanation, without calling any independent verification tools (e.g., tests, linters).
13. **Incorrect Verification**: An agent runs a verification tool, the tool returns an error or failure signal, but the agent ignores the signal and approves the solution anyway.
14. **Hallucinated Verification**: An agent claims to have run a test or checked a system and reports success, but the interceptor proxy shows no corresponding tool call was actually made.
