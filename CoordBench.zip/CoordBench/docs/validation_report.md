# MAST Detector Validation Report

This report documents the validation of the automated MAST failure mode detectors against human-annotated transcripts.
The metric used is Cohen's Kappa ($\kappa$), measuring inter-rater reliability between the automated swarm (Programmatic + LLM Judge + Aggregator) and the human gold standard.

## Methodology
- 50 hold-out transcripts were annotated by 3 independent human raters. Disagreements were resolved via discussion.
- The automated swarm processed the same 50 transcripts.
- Target threshold: $\kappa \ge 0.65$ per failure mode.

## Results

| Category | Failure Mode | Cohen's $\kappa$ | Status | Notes |
|----------|--------------|------------------|--------|-------|
| 1 | Task Disobedience | 0.81 | PASS | Handled well by LLM Judge. |
| 1 | Role Drift | 0.76 | PASS | Required strict prompt engineering to avoid false positives. |
| 1 | Step Repetition/Looping | 0.94 | PASS | Programmatic Levenshtein distance is highly reliable. |
| 1 | Context Degradation | 0.68 | PASS | Barely passed threshold; long contexts challenge the judge. |
| 1 | Termination Blindness | 1.00 | PASS | Purely programmatic, 100% agreement. |
| 2 | Information Siloing | 0.72 | PASS | |
| 2 | Echo Chamber Convergence | 0.78 | PASS | Aggregator override reduced false positives significantly. |
| 2 | Agent Dominance | 0.88 | PASS | Mixed programmatic (token counting) + LLM context. |
| 2 | Reasoning-Action Mismatch | 0.61 | FAIL | Sub-threshold. Needs few-shot CoT prompt refinement. |
| 2 | Unresolved Conflict | 0.84 | PASS | |
| 3 | Premature Termination | 1.00 | PASS | Purely programmatic. |
| 3 | Superficial Verification | 0.71 | PASS | |
| 3 | Incorrect Verification | 0.66 | PASS | |
| 3 | Hallucinated Verification | 0.85 | PASS | Cross-referencing tool calls with text is robust. |

## Next Steps
- Refine the *Reasoning-Action Mismatch* prompt to force the LLM judge to explicitly quote the constraint and the action before rendering a verdict.
- Re-evaluate on a new batch of 50 transcripts.
