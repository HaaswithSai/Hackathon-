import json
import logging
from typing import Dict, Any

logger = logging.getLogger("DPIPEval")

def evaluate(ground_truth: Any, final_answer: str) -> bool:
    """
    Evaluates a DPIP task. 
    The evaluation checks if the final answer contains the exact match
    for the ground truth values. Since LLM outputs can be verbose,
    we do a robust substring search or JSON extraction.
    """
    # If ground truth is a string, just check if it's in the output
    if isinstance(ground_truth, str):
        return ground_truth.lower() in final_answer.lower()
        
    # If ground truth is a dictionary, check if all values are present in the output
    if isinstance(ground_truth, dict):
        final_answer_lower = final_answer.lower()
        for key, value in ground_truth.items():
            if isinstance(value, str):
                if value.lower() not in final_answer_lower:
                    logger.debug(f"Missing expected string value: {value}")
                    return False
            elif isinstance(value, list):
                for item in value:
                    if str(item).lower() not in final_answer_lower:
                        logger.debug(f"Missing expected list item: {item}")
                        return False
            elif isinstance(value, (int, float, bool)):
                if str(value).lower() not in final_answer_lower:
                    logger.debug(f"Missing expected primitive value: {value}")
                    return False
        return True
        
    return False

if __name__ == "__main__":
    # Example test
    gt = {"culprit": "srv-B", "root_cause": "memory_leak_in_payment_service"}
    ans = "Based on our discussion, the culprit is srv-B due to a memory_leak_in_payment_service causing OOM."
    print("Pass:", evaluate(gt, ans))
