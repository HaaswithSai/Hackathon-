import json
import logging
from typing import Dict, Any

logger = logging.getLogger("MergeEval")

def extract_json(text: str) -> Any:
    """Attempts to extract a JSON object from the LLM's final answer."""
    import re
    match = re.search(r'```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```', text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
            
    try:
        start_idx = text.find('{')
        end_idx = text.rfind('}') + 1
        if start_idx != -1 and end_idx != -1:
            return json.loads(text[start_idx:end_idx])
    except json.JSONDecodeError:
        pass
        
    return None

def schema_subset_match(expected: Any, actual: Any) -> bool:
    """
    Recursively checks if actual contains the expected schema.
    Actual can have extra fields, but must have all expected fields with matching types.
    """
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            return False
        for k, v in expected.items():
            if k not in actual:
                return False
            if not schema_subset_match(v, actual[k]):
                return False
        return True
    elif isinstance(expected, list):
        if not isinstance(actual, list):
            return False
        if len(expected) == 0:
            return True
        # Check if actual list elements match expected schema
        # Assuming homogeneous lists for schemas
        if len(actual) > 0:
            return schema_subset_match(expected[0], actual[0])
        return False
    else:
        # Primitive type matching
        return str(expected).lower() == str(actual).lower()

def evaluate(ground_truth: Any, final_answer: str, eval_type: str = "schema_match") -> bool:
    """
    Evaluates Cooperative Merge tasks.
    The true evaluation would involve running Docker integration tests.
    Here we implement 'schema_match' which compares the agreed upon API/payload structure
    to ensure it strictly satisfies all requirements.
    """
    parsed_answer = extract_json(final_answer)
    if parsed_answer is None:
        logger.error("Could not parse JSON from final answer for merge evaluation")
        return False
        
    if eval_type == "exact_match":
        return parsed_answer == ground_truth
        
    elif eval_type == "schema_match":
        # The agreed schema must satisfy all required fields in the ground truth
        return schema_subset_match(ground_truth, parsed_answer)

    return False
