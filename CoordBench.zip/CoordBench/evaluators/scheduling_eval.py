import json
import logging
from typing import Dict, Any

logger = logging.getLogger("SchedulingEval")

def extract_json(text: str) -> Any:
    """Attempts to extract a JSON object from the LLM's final answer."""
    import re
    # Try to find a JSON block
    match = re.search(r'```json\s*(\{.*?\}|\[.*?\])\s*```', text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
            
    # Try aggressive parse
    try:
        start_idx = text.find('{')
        end_idx = text.rfind('}') + 1
        if start_idx != -1 and end_idx != -1:
            return json.loads(text[start_idx:end_idx])
            
        start_idx = text.find('[')
        end_idx = text.rfind(']') + 1
        if start_idx != -1 and end_idx != -1:
            return json.loads(text[start_idx:end_idx])
    except json.JSONDecodeError:
        pass
        
    return None

def evaluate(ground_truth: Any, final_answer: str, eval_type: str) -> bool:
    """
    Evaluates adversarial constraint scheduling tasks.
    In a full implementation, this maps the proposed schedule to boolean SAT variables
    and checks satisfiability against the hard constraints.
    Here we implement the structural matchers specified in the task definitions.
    """
    parsed_answer = extract_json(final_answer)
    if parsed_answer is None:
        logger.error("Could not parse JSON from final answer")
        return False
        
    if eval_type == "exact_match":
        return parsed_answer == ground_truth
        
    elif eval_type == "set_match":
        if not isinstance(parsed_answer, dict) or not isinstance(ground_truth, dict):
            return False
        for k, v in ground_truth.items():
            if set(parsed_answer.get(k, [])) != set(v):
                return False
        return True
        
    elif eval_type == "ordered_list_match":
        if not isinstance(parsed_answer, list) or not isinstance(ground_truth, list):
            return False
        return parsed_answer == ground_truth
        
    elif eval_type == "ordered_steps_with_owners":
        if not isinstance(parsed_answer, list) or not isinstance(ground_truth, list):
            return False
        if len(parsed_answer) != len(ground_truth):
            return False
        for i in range(len(ground_truth)):
            gt_step = ground_truth[i]
            pa_step = parsed_answer[i]
            if not isinstance(pa_step, dict):
                return False
            if pa_step.get("step") != gt_step.get("step") or pa_step.get("owner") != gt_step.get("owner"):
                return False
        return True

    return False
