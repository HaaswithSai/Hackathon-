import autogen
from typing import Dict, Any, Union
from .base_adapter import BaseAdapter

class PartitionedGroupChatManager(autogen.GroupChatManager):
    """
    Custom GroupChatManager that partitions memory by intercepting the broadcast.
    """
    def send(self, message: Union[Dict, str], recipient: autogen.Agent, request_reply: bool = None, silent: bool = False):
        # Intercept the broadcast from the manager to the agents.
        content = message.get("content", "") if isinstance(message, dict) else str(message)
        
        # Always allow messages to the orchestrator (user_proxy)
        if recipient.name == "orchestrator":
            super().send(message, recipient, request_reply, silent)
            return
            
        # Selective broadcast: only send if the agent is explicitly addressed
        # or if it's the initial task prompt (the first message in the chat).
        if len(self.groupchat.messages) <= 1 or f"@{recipient.name}" in content:
            super().send(message, recipient, request_reply, silent)

class AutoGenAdapter(BaseAdapter):
    def __init__(self, model_name: str, proxy_url: str):
        super().__init__(model_name, proxy_url)
        self.agents = []
        self.user_proxy = None
        
        self.llm_config = {
            "config_list": [{
                "model": self.model_name,
                "base_url": self.proxy_url,
                "api_key": "dummy"
            }],
            "temperature": 0.0,
        }

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        agent_contexts = task_def.get("agent_contexts", {})
        self.agents = []
        
        for agent_name, system_message in agent_contexts.items():
            agent_config = dict(self.llm_config)
            agent_config["config_list"][0]["default_headers"] = {
                "x-mac-agent-name": agent_name
            }
            
            # Inject prompts to encourage interrupting and addressing
            interrupt_prompt = (
                "\n\nYou are in a dynamic group chat. "
                "If you detect a flaw in another agent's reasoning, you can and should interrupt. "
                "CRITICAL: Memory is partitioned. Agents DO NOT see your messages by default. "
                f"If you want to share information with another agent, you MUST explicitly address them by starting your message or referencing them like '@<AgentName>'. "
                "When the task is solved and all constraints are met, output 'TERMINATE'."
            )
            
            agent = autogen.AssistantAgent(
                name=agent_name,
                system_message=system_message + interrupt_prompt,
                llm_config=agent_config,
            )
            self.agents.append(agent)
            
        self.user_proxy = autogen.UserProxyAgent(
            name="orchestrator",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=15,
            is_termination_msg=lambda x: "TERMINATE" in x.get("content", ""),
            code_execution_config=False,
        )

    def run_task(self, task_def: Dict[str, Any]) -> str:
        if not self.agents or not self.user_proxy:
            raise ValueError("Agents not setup.")
            
        question = task_def.get("question", "Solve the task.")
        
        groupchat = autogen.GroupChat(
            agents=[self.user_proxy] + self.agents, 
            messages=[], 
            max_round=20,
            speaker_selection_method="auto"  # Enables dynamic interruption and cross-talk
        )
        
        manager = PartitionedGroupChatManager(groupchat=groupchat, llm_config=self.llm_config)
        
        self.user_proxy.initiate_chat(
            manager,
            message=question
        )
        
        history = self.user_proxy.chat_messages[manager]
        for msg in reversed(history):
            if msg.get("content") and "TERMINATE" not in msg.get("content", ""):
                return msg.get("content")
        return ""
