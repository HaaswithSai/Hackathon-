import os
from typing import Dict, Any
from crewai import Agent, Task, Crew, Process
from langchain_openai import ChatOpenAI
from .base_adapter import BaseAdapter

class CrewAIAdapter(BaseAdapter):
    def __init__(self, model_name: str, proxy_url: str):
        super().__init__(model_name, proxy_url)
        self.crew = None
        
        # Configure LiteLLM/LangChain to point to our proxy
        self.llm = ChatOpenAI(
            model_name=self.model_name,
            openai_api_base=self.proxy_url,
            openai_api_key="dummy",
            temperature=0.0
        )

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        agent_contexts = task_def.get("agent_contexts", {})
        crew_agents = []
        
        for agent_name, context in agent_contexts.items():
            # In CrewAI, we define roles and backstories.
            # We must map the agent context to these concepts.
            agent = Agent(
                role=agent_name,
                goal=f"Solve your part of the task perfectly.",
                backstory=context,
                verbose=True,
                allow_delegation=True, # Allow agents to coordinate
                llm=self.llm,
                # We can't easily inject per-agent HTTP headers deeply into LangChain's ChatOpenAI 
                # in a quick script, but we can prefix their outputs if needed, 
                # or rely on the proxy parsing the prompt to identify the agent role.
            )
            crew_agents.append(agent)
            
        question = task_def.get("question", "Solve the task.")
        
        # CrewAI requires explicit tasks. We create one massive coordination task
        # assigned to all agents, or sequentially. The user specified "strictly multi agent architecture 
        # the agents to speak communicate reason not just sequentially one after other".
        # Hierarchical process is closer to that than sequential.
        
        coordination_task = Task(
            description=question + " Discuss with your peers and output only the final negotiated answer.",
            expected_output="The final synthesized answer satisfying all constraints.",
            agent=crew_agents[0] # Assigned to the first agent to initiate
        )
        
        self.crew = Crew(
            agents=crew_agents,
            tasks=[coordination_task],
            process=Process.sequential, # Can be set to hierarchical if manager LLM is provided
            verbose=True
        )

    def run_task(self, task_def: Dict[str, Any]) -> str:
        if not self.crew:
            raise ValueError("Crew not setup.")
            
        result = self.crew.kickoff()
        return str(result)
