import json
import logging
from typing import Dict, Any, List, TypedDict
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, AIMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from .base_adapter import BaseAdapter

class AgentState(TypedDict):
    agent_memories: Dict[str, List[BaseMessage]]
    current_agent: str
    final_answer: str
    routing_history: List[str]

class LangGraphAdapter(BaseAdapter):
    def __init__(self, model_name: str, proxy_url: str):
        super().__init__(model_name, proxy_url)
        self.graph = None
        self.llm = ChatOpenAI(
            model_name=self.model_name,
            openai_api_base=self.proxy_url,
            openai_api_key="dummy",
            temperature=0.0
        )
        self.agent_names = []

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        agent_contexts = task_def.get("agent_contexts", {})
        self.agent_names = list(agent_contexts.keys())
        
        workflow = StateGraph(AgentState)
        
        # We create a supervisor node that routes messages
        def supervisor_node(state: AgentState):
            # Check if any agent has output TERMINATE in their last message
            for agent, memory in state["agent_memories"].items():
                if memory and "TERMINATE" in memory[-1].content:
                    return {"current_agent": "FINISH", "final_answer": memory[-1].content}
            
            # Supervisor uses LLM to decide the next agent
            sys_prompt = (
                f"You are a supervisor managing these agents: {self.agent_names}.\n"
                "Based on the routing history, select the next agent to speak.\n"
                "You must output ONLY the exact name of the next agent."
            )
            
            history_str = " -> ".join(state.get("routing_history", []))
            user_prompt = f"Routing history: {history_str if history_str else 'Start'}\nWho should speak next?"
            
            try:
                response = self.llm.invoke([
                    SystemMessage(content=sys_prompt),
                    HumanMessage(content=user_prompt)
                ])
                next_agent = response.content.strip()
                if next_agent not in self.agent_names:
                    next_agent = self.agent_names[0]
            except Exception:
                next_agent = self.agent_names[0]
                
            new_history = state.get("routing_history", []) + [next_agent]
            return {"current_agent": next_agent, "routing_history": new_history}

        # Create a node for each agent
        for agent_name, context in agent_contexts.items():
            def agent_node(state: AgentState, name=agent_name, ctx=context):
                memories = state.get("agent_memories", {}).copy()
                my_memory = memories.get(name, [])
                
                sys_msg = SystemMessage(content=ctx + "\n\nIf the task is complete and all constraints are met, output 'TERMINATE'. If you need information from another agent, explicitly address them.")
                
                response = self.llm.invoke([sys_msg] + my_memory)
                
                # Update this agent's memory
                new_memory = my_memory + [AIMessage(content=response.content)]
                memories[name] = new_memory
                
                # Cross-talk: if the agent addresses another agent (e.g., "@AgentB"), 
                # we pass the message to that agent's memory too
                for other_agent in self.agent_names:
                    if other_agent != name and f"@{other_agent}" in response.content:
                        other_mem = memories.get(other_agent, [])
                        msg_from_me = HumanMessage(content=f"Message from {name}: {response.content}")
                        memories[other_agent] = other_mem + [msg_from_me]

                return {"agent_memories": memories}
                
            workflow.add_node(agent_name, agent_node)
            workflow.add_edge(agent_name, "supervisor")

        workflow.add_node("supervisor", supervisor_node)
        
        # Routing logic
        def route(state: AgentState):
            if state["current_agent"] == "FINISH":
                return END
            return state["current_agent"]
            
        workflow.add_conditional_edges("supervisor", route)
        workflow.set_entry_point("supervisor")
        
        self.graph = workflow.compile()

    def run_task(self, task_def: Dict[str, Any]) -> str:
        if not self.graph:
            raise ValueError("Graph not setup.")
            
        question = task_def.get("question", "Solve the task.")
        
        # Initialize memory with the initial question for all agents
        initial_memories = {
            name: [HumanMessage(content=question)] for name in self.agent_names
        }
        
        initial_state = {
            "agent_memories": initial_memories,
            "current_agent": "",
            "final_answer": "",
            "routing_history": []
        }
        
        # Recursion limit prevents infinite loops
        final_state = self.graph.invoke(initial_state, {"recursion_limit": 50})
        return final_state.get("final_answer", "")
