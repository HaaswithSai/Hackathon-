import json
import os
import typer
from dotenv import load_dotenv
load_dotenv()
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from detectors.aggregator import aggregate_failures
from evaluators.dpip_eval import evaluate as dpip_evaluate
from evaluators.scheduling_eval import evaluate as scheduling_evaluate
from evaluators.merge_eval import evaluate as merge_evaluate

app = typer.Typer(help="Evaluate a MAC-Bench transcript")
console = Console()

def load_task(task_path: str, task_id: str = None) -> dict:
    with open(task_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        if isinstance(data, list):
            if task_id:
                for t in data:
                    if t.get("id") == task_id:
                        return t
            return data[0]
        return data

@app.command()
def evaluate(
    transcript_path: str = typer.Argument(..., help="Path to the .jsonl transcript"),
    task_file: str = typer.Argument(..., help="Path to the task definition file"),
    task_id: str = typer.Option(None, help="Specific task ID if file is a list"),
    final_answer: str = typer.Option(None, help="Final answer string if available")
):
    if not os.path.exists(transcript_path):
        console.print(f"[bold red]Transcript not found:[/bold red] {transcript_path}")
        raise typer.Exit(1)
        
    task_def = load_task(task_file, task_id)
    ground_truth = task_def.get("ground_truth")
    
    # Calculate transcript metrics
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_latency_ms = 0
    turns = 0
    last_response = final_answer or ""
    
    with open(transcript_path, 'r') as f:
        for line in f:
            if line.strip():
                turn = json.loads(line)
                turns += 1
                total_prompt_tokens += turn.get("prompt_tokens", 0)
                total_completion_tokens += turn.get("completion_tokens", 0)
                total_latency_ms += turn.get("latency_ms", 0)
                
                # If no final answer provided, attempt to extract from last turn
                if not final_answer:
                    if "content" in turn.get("response_message", {}):
                        last_response = turn["response_message"]["content"]
                        
    # Determine task success
    task_type = task_def.get("id", "").split("_")[0]
    is_success = False
    
    if task_type == "dpip":
        is_success = dpip_evaluate(ground_truth, last_response)
    elif task_type == "sched":
        is_success = scheduling_evaluate(ground_truth, last_response)
    elif task_type == "merge":
        is_success = merge_evaluate(ground_truth, last_response)
    else:
        # Fallback to simple inclusion
        is_success = str(ground_truth).lower() in last_response.lower()
        
    # Run MAST Swarm
    console.print(f"[bold yellow]Running MAST Evaluator Swarm on {turns} turns...[/bold yellow]")
    failures = aggregate_failures(transcript_path, is_success)
    
    # Display Results
    console.print(Panel.fit(
        f"[bold green]Task Success:[/bold green] {is_success}\n"
        f"[bold blue]Total Turns:[/bold blue] {turns}\n"
        f"[bold cyan]Total Tokens:[/bold cyan] {total_prompt_tokens + total_completion_tokens} "
        f"(Prompt: {total_prompt_tokens}, Completion: {total_completion_tokens})\n"
        f"[bold magenta]Total Latency:[/bold magenta] {total_latency_ms / 1000:.2f}s",
        title="[bold]Run Metrics[/bold]"
    ))
    
    # Failure Modes Table
    table = Table(title="MAST Failure Modes")
    table.add_column("Category", style="cyan")
    table.add_column("Failure Mode", style="magenta")
    table.add_column("Detected", style="bold")
    
    for category, modes in failures.items():
        if category == "success": continue
        for mode, detected in modes.items():
            status = "[bold red]YES[/bold red]" if detected else "[dim green]No[/dim green]"
            table.add_row(category.replace("_", " "), mode.replace("_", " ").title(), status)
            
    console.print(table)
    
if __name__ == "__main__":
    app()
