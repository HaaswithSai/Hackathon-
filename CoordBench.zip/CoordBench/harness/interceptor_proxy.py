import time
import json
import os
import uuid
import logging
from typing import Dict, Any

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Request, BackgroundTasks
from fastapi.responses import JSONResponse
import httpx
import jsonlines

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("InterceptorProxy")

app = FastAPI(title="MAC-Bench Interceptor Proxy")

# In a real scenario, these come from .env
# We default to LiteLLM's standard format or OpenAI's API
UPSTREAM_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
TRANSCRIPT_DIR = os.getenv("TRANSCRIPT_DIR", "transcripts/raw")

os.makedirs(TRANSCRIPT_DIR, exist_ok=True)

# We store the active run's transcript path here. 
# In a robust setup, we'd use a run_id header in the request to route to the correct transcript.
active_run_id = "default"

def set_active_run(run_id: str):
    global active_run_id
    active_run_id = run_id

def log_to_transcript(run_id: str, entry: Dict[str, Any]):
    """Appends an intercepted turn to the JSONL transcript."""
    filepath = os.path.join(TRANSCRIPT_DIR, f"{run_id}.jsonl")
    try:
        with jsonlines.open(filepath, mode='a') as writer:
            writer.write(entry)
    except Exception as e:
        logger.error(f"Failed to write to transcript {filepath}: {e}")

@app.post("/{path:path}")
async def proxy_post(path: str, request: Request, background_tasks: BackgroundTasks):
    """
    Intercepts POST requests (usually /chat/completions), records start time,
    forwards to the upstream LLM API, measures latency, extracts token usage,
    and logs the entire transaction to the transcript.
    """
    # Extract request body
    try:
        req_body = await request.json()
        
        # Strip 'name' field from messages for Mistral/Anthropic compatibility
        if "messages" in req_body:
            for msg in req_body["messages"]:
                if "name" in msg:
                    # Prepend name to content so context isn't lost
                    name = msg.pop("name")
                    content = msg.get("content", "")
                    if isinstance(content, str) and not content.startswith(f"[{name}]"):
                        msg["content"] = f"[{name}] {content}"
            
            # Mistral strictly requires the last message to be from a 'user' or 'tool'.
            # If the partitioned memory caused an agent to be called again without receiving 
            # any new messages, its history will end with its own 'assistant' message.
            if len(req_body["messages"]) > 0:
                if req_body["messages"][-1].get("role") == "assistant":
                    req_body["messages"].append({
                        "role": "user",
                        "content": "Please continue your thoughts or wait for others."
                    })
                        
    except Exception:
        req_body = {}

    headers = dict(request.headers)
    
    # Clean up headers that might interfere with proxying
    headers.pop("host", None)
    headers.pop("content-length", None)
    
    # Inject real API key if available
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        headers["authorization"] = f"Bearer {api_key}"
    
    # We look for a custom header to identify the run and the agent
    run_id = headers.pop("x-mac-run-id", active_run_id)
    agent_name = headers.pop("x-mac-agent-name", "unknown_agent")

    # Ensure no double slashes or duplicate /v1
    if path.startswith("v1/"):
        path = path[3:]
    upstream_endpoint = f"{UPSTREAM_URL.rstrip('/')}/{path.lstrip('/')}"
    
    start_time = time.time()
    
    # Forward the request using httpx
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                upstream_endpoint,
                json=req_body,
                headers=headers,
                timeout=120.0
            )
            response_body = response.json()
            status_code = response.status_code
        except Exception as e:
            logger.error(f"Upstream request failed: {e}")
            response_body = {"error": str(e)}
            status_code = 500

    latency_ms = int((time.time() - start_time) * 1000)

    # Extract metrics (assuming OpenAI API format)
    usage = response_body.get("usage", {})
    prompt_tokens = usage.get("prompt_tokens", 0)
    completion_tokens = usage.get("completion_tokens", 0)
    
    # Extract tools if any were called
    choices = response_body.get("choices", [])
    tool_calls = []
    message = {}
    if choices:
        message = choices[0].get("message", {})
        tool_calls = message.get("tool_calls", [])

    # Check for TERMINATE signal in the content
    content = message.get("content", "") or ""
    is_termination = "TERMINATE" in content

    # Build transcript entry
    transcript_entry = {
        "turn_id": str(uuid.uuid4()),
        "timestamp": time.time(),
        "agent": agent_name,
        "latency_ms": latency_ms,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "request_messages": req_body.get("messages", []),
        "response_message": message,
        "tools_called": tool_calls,
        "is_termination": is_termination
    }

    # Queue the file write
    background_tasks.add_task(log_to_transcript, run_id, transcript_entry)

    # Return the response to the framework exactly as received
    return JSONResponse(content=response_body, status_code=status_code)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("harness.interceptor_proxy:app", host="0.0.0.0", port=8080, reload=True)
