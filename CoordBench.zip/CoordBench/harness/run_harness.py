import os
import json
import logging
import typer
import uuid
import httpx
from rich.console import Console
from dotenv import load_dotenv
load_dotenv()

from harness.interceptor_proxy import set_active_run
from harness.adapters.autogen_adapter import AutoGenAdapter
from harness.adapters.crewai_adapter import CrewAIAdapter
from harness.adapters.langgraph_adapter import LangGraphAdapter

# Setup
app = typer.Typer(help="MAC-Bench Orchestration Harness")
console = Console()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("RunHarness")

ADAPTERS = {
    "autogen": AutoGenAdapter,
    "crewai": CrewAIAdapter,
    "langgraph": LangGraphAdapter
}

def load_task(task_path: str) -> dict:
    if not os.path.exists(task_path):
        raise FileNotFoundError(f"Task file {task_path} not found.")
    with open(task_path, "r", encoding="utf-8") as f:
        # Some task files are lists of dicts, some are single dicts
        data = json.load(f)
        if isinstance(data, list):
            # For testing, grab the first one if it's a list
            return data[0]
        return data

@app.command()
def run(
    task_file: str = typer.Argument(..., help="Path to the JSON/Python task definition"),
    framework: str = typer.Option(..., help="Which framework to test (autogen, crewai, langgraph)"),
    model: str = typer.Option("gpt-4o", help="Model name for the agents"),
    proxy_url: str = typer.Option("http://localhost:8080/v1", help="Interceptor proxy URL")
):
    """
    Executes a single MAC-Bench task using the specified framework and model.
    """
    if framework not in ADAPTERS:
        console.print(f"[bold red]Error:[/bold red] Unknown framework '{framework}'. Available: {list(ADAPTERS.keys())}")
        raise typer.Exit(1)
        
    try:
        task_def = load_task(task_file)
    except Exception as e:
        console.print(f"[bold red]Failed to load task:[/bold red] {e}")
        raise typer.Exit(1)
        
    task_id = task_def.get("id", "unknown_task")
    run_id = f"{framework}_{model}_{task_id}_{uuid.uuid4().hex[:8]}"
    
    console.print(f"[bold green]Starting Run:[/bold green] {run_id}")
    console.print(f"Task: {task_id} | Framework: {framework} | Model: {model}")
    
    # In a full deployment, this would notify the proxy of the active run ID
    # For local execution, we just set the global in the proxy module if it's running in the same process
    # Or we rely on headers. Since we might run proxy separately, let's just log it.
    console.print(f"Transcript will be saved as: {run_id}.jsonl")
    
    # Initialize the adapter
    adapter_class = ADAPTERS[framework]
    adapter = adapter_class(model_name=model, proxy_url=proxy_url)
    
    console.print("[bold yellow]Setting up agents...[/bold yellow]")
    adapter.setup_agents(task_def)
    
    console.print("[bold yellow]Running task...[/bold yellow]")
    try:
        final_answer = adapter.run_task(task_def)
        console.print("[bold green]Task Complete.[/bold green]")
        console.print(f"[bold blue]Final Answer:[/bold blue]\n{final_answer}")
    except Exception as e:
        console.print(f"[bold red]Run failed:[/bold red] {e}")
        logger.exception(e)

if __name__ == "__main__":
    app()
