[
  {
    "id": "adv_001",
    "question": "Design a deployment pipeline that satisfies all constraints from both Engineering and Security. Output the final pipeline as an ordered list of stages.",
    "ground_truth": ["unit_tests", "sast_scan", "build_artifact", "dast_scan", "staging_deploy", "penetration_test", "canary_deploy_5pct", "monitor_30min", "full_production_deploy"],
    "evaluator": "ordered_list_match",
    "agent_contexts": {
      "agent_engineering": "You represent Engineering. Your hard constraints: (1) unit_tests must run before build_artifact, (2) canary_deploy_5pct must come before full_production_deploy, (3) staging_deploy must happen before any production deploy, (4) total pipeline must complete in under 90 minutes. You want to minimize stages and ship fast.",
      "agent_security": "You represent Security. Your hard constraints: (1) sast_scan must run before build_artifact, (2) dast_scan must run after staging_deploy, (3) penetration_test must run before any production deploy, (4) monitor_30min must follow canary_deploy_5pct. No constraint on total time.",
      "agent_orchestrator": "You must synthesize Engineering and Security into a single valid pipeline. Both sets of hard constraints must be satisfied. Output the final ordered list only when both agents confirm their constraints are met."
    }
  },
  {
    "id": "adv_002",
    "question": "Negotiate a data retention policy that satisfies both Legal's compliance requirements and Engineering's storage cost constraints. Output as: {retention_days, deletion_method, audit_log_retention_days}.",
    "ground_truth": {"retention_days": 365, "deletion_method": "cryptographic_erasure", "audit_log_retention_days": 2555},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_legal": "You represent Legal/Compliance. Hard constraints: (1) user PII must be retained minimum 365 days for legal holds, (2) audit logs must be retained 7 years (2555 days) for SOX compliance, (3) deletion must be cryptographically verifiable — simple deletion is not acceptable.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) storage costs must not exceed current budget — retention beyond 365 days for primary data is too expensive, (2) cryptographic_erasure is acceptable but takes 2h per TB — must be scheduled off-peak, (3) audit logs can use cheap cold storage (glacier-tier) to reduce cost.",
      "agent_orchestrator": "You must negotiate between Legal and Engineering and output a single agreed policy. Both sides have veto power. Find the solution where all hard constraints from both sides are simultaneously satisfied."
    }
  },
  {
    "id": "adv_003",
    "question": "Create a sprint plan that satisfies both Product's feature deadline and Engineering's technical debt mandate. Output as: {features_in_sprint, tech_debt_tasks_in_sprint, deferred_items}.",
    "ground_truth": {
      "features_in_sprint": ["user_auth_v2", "payment_3ds"],
      "tech_debt_tasks_in_sprint": ["upgrade_node_18", "remove_legacy_api"],
      "deferred_items": ["dark_mode", "export_csv"]
    },
    "evaluator": "set_match",
    "agent_contexts": {
      "agent_product": "You represent Product. Hard constraints: (1) user_auth_v2 and payment_3ds MUST ship this sprint — contractual obligation, (2) dark_mode and export_csv are medium priority and can slip once, (3) sprint is 10 story points. user_auth_v2=4pts, payment_3ds=3pts, dark_mode=3pts, export_csv=2pts.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) upgrade_node_18 must happen this sprint — Node 16 EOL is in 2 weeks, (2) remove_legacy_api must happen this sprint — it blocks the auth_v2 implementation, (3) tech debt tasks: upgrade_node_18=2pts, remove_legacy_api=1pt. Total sprint capacity is 10 points.",
      "agent_orchestrator": "You must produce a sprint plan satisfying all hard constraints from both Product and Engineering within the 10-point capacity. Items that cannot fit must go in deferred_items."
    }
  },
  {
    "id": "adv_004",
    "question": "Design a database access policy satisfying both the ML team's training data needs and the Privacy team's GDPR requirements. Output as: {allowed_tables, anonymization_required, access_method, retention_limit_days}.",
    "ground_truth": {
      "allowed_tables": ["events_anonymized", "products", "sessions_aggregated"],
      "anonymization_required": true,
      "access_method": "read_only_replica",
      "retention_limit_days": 90
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_ml": "You represent the ML team. Hard constraints: (1) need access to user behavioral events for model training, (2) need product catalog table (non-PII), (3) need session data aggregated by cohort, (4) direct production DB access preferred for freshness, (5) need at least 90 days of data history.",
      "agent_privacy": "You represent Privacy/GDPR compliance. Hard constraints: (1) raw PII tables (users, payments, addresses) are completely off-limits, (2) any user behavioral data must be anonymized before ML access, (3) production DB write access forbidden, (4) data older than 90 days must be deleted from ML systems, (5) access must be auditable."
    }
  },
  {
    "id": "adv_005",
    "question": "Negotiate a vendor contract term that satisfies both Finance's cost controls and Engineering's SLA requirements. Output as: {monthly_cost_usd, uptime_sla_pct, support_tier, contract_length_months}.",
    "ground_truth": {
      "monthly_cost_usd": 45000,
      "uptime_sla_pct": 99.9,
      "support_tier": "business",
      "contract_length_months": 24
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_finance": "You represent Finance. Hard constraints: (1) monthly spend cannot exceed $50,000, (2) contract must be minimum 24 months for budget planning purposes, (3) enterprise tier ($65,000/mo) is rejected — exceeds budget, (4) starter tier ($20,000/mo) acceptable on cost but check SLA.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) minimum 99.9% uptime SLA required — our customer contracts depend on it, (2) starter tier only offers 99.5% SLA — unacceptable, (3) business tier ($45,000/mo) offers 99.9% SLA and 'business' support level, (4) enterprise tier offers 99.99% but is over budget.",
      "agent_orchestrator": "Find the vendor tier that simultaneously satisfies Finance's budget ceiling and Engineering's SLA floor. Output the final agreed contract terms."
    }
  },
  {
    "id": "adv_006",
    "question": "Create an incident response plan that satisfies both the on-call Engineering rotation and the Customer Success escalation requirements. Output as ordered steps with owner assignments.",
    "ground_truth": [
      {"step": "alert_fires", "owner": "pagerduty_auto"},
      {"step": "on_call_acknowledges", "owner": "engineering_oncall", "sla_minutes": 5},
      {"step": "severity_classification", "owner": "engineering_oncall", "sla_minutes": 10},
      {"step": "customer_notify_if_sev1", "owner": "customer_success", "sla_minutes": 15},
      {"step": "incident_commander_assigned", "owner": "engineering_lead", "sla_minutes": 20},
      {"step": "status_page_update", "owner": "customer_success", "sla_minutes": 20},
      {"step": "resolution_or_escalate", "owner": "engineering_oncall", "sla_minutes": 60},
      {"step": "post_mortem_scheduled", "owner": "engineering_lead", "sla_minutes": 1440}
    ],
    "evaluator": "ordered_steps_with_owners",
    "agent_contexts": {
      "agent_engineering": "You represent Engineering. Hard constraints: (1) on-call must acknowledge within 5 minutes, (2) severity must be classified before any external communication, (3) engineering lead assigned as incident commander only for SEV1/SEV2, (4) post-mortem must be scheduled within 24h of resolution.",
      "agent_customer_success": "You represent Customer Success. Hard constraints: (1) customers must be notified within 15 minutes of SEV1 confirmation, (2) status page must be updated before any customer emails go out, (3) customer success must own all external communication — engineering cannot contact customers directly, (4) update cadence every 30 minutes during active incident."
    }
  },
  {
    "id": "adv_007",
    "question": "Design a model deployment policy satisfying both the Research team's experimentation speed and the Platform team's reliability requirements. Output as: {approval_stages, rollback_trigger, min_test_duration_hours, canary_pct}.",
    "ground_truth": {
      "approval_stages": ["automated_eval", "researcher_sign_off", "platform_review"],
      "rollback_trigger": "error_rate_above_1pct_or_latency_p99_above_500ms",
      "min_test_duration_hours": 24,
      "canary_pct": 5
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_research": "You represent Research. Hard constraints: (1) researchers must be able to deploy new model versions within 48h of request, (2) automated eval gate must run but manual platform review should not block >24h, (3) canary percentage must be at least 5% to get statistically meaningful signal, (4) rollback must be possible within 10 minutes.",
      "agent_platform": "You represent Platform/SRE. Hard constraints: (1) all model deployments need automated eval + researcher sign-off + platform review — no skipping stages, (2) minimum 24-hour canary before full rollout, (3) automatic rollback if error rate exceeds 1% OR p99 latency exceeds 500ms, (4) canary capped at 10% to limit blast radius."
    }
  },
  {
    "id": "adv_008",
    "question": "Negotiate a remote work policy satisfying both HR's collaboration requirements and the Engineering team's flexibility demands. Output as: {required_in_office_days, core_hours_utc, async_communication_tool, meeting_policy}.",
    "ground_truth": {
      "required_in_office_days": 2,
      "core_hours_utc": "14:00-17:00",
      "async_communication_tool": "Slack_with_24h_response_SLA",
      "meeting_policy": "no_meetings_outside_core_hours_except_oncall"
      },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_hr": "You represent HR. Hard constraints: (1) minimum 2 in-office days per week for team cohesion, (2) all employees must be reachable during core hours, (3) core hours must overlap across US and EU timezones, (4) async tools cannot replace synchronous standups — at least 3 syncs per week required.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) maximum 2 in-office days — more disrupts deep work, (2) no mandatory meetings before 14:00 UTC or after 17:00 UTC, (3) on-call engineers exempt from in-office requirements, (4) async-first culture — Slack with 24h response SLA preferred over email, (5) standups can be async via written updates."
    }
  },
  {
    "id": "adv_009",
    "question": "Design a CI/CD gate policy satisfying both the QA team's quality bar and the Engineering team's merge velocity requirements. Output as: {required_checks, max_wait_minutes, merge_queue_enabled, flaky_test_policy}.",
    "ground_truth": {
      "required_checks": ["unit_tests", "integration_tests", "security_scan", "coverage_above_80pct"],
      "max_wait_minutes": 30,
      "merge_queue_enabled": true,
      "flaky_test_policy": "auto_retry_once_then_quarantine"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_qa": "You represent QA. Hard constraints: (1) unit tests, integration tests, security scan, and 80% coverage gate are all required — none optional, (2) flaky tests cannot be silently ignored — must be tracked and fixed, (3) merge queue must be enabled to prevent test skipping via fast-merge, (4) e2e tests preferred but can be async if velocity is blocked.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) CI pipeline must complete in under 30 minutes or developers context-switch away, (2) flaky tests blocking merges is unacceptable — causes 2h delays on average, (3) merge queue is acceptable if it doesn't add >5 minutes, (4) e2e tests as required gate is a hard NO — they take 45 minutes."
    }
  },
  {
    "id": "adv_010",
    "question": "Design a logging and observability policy that satisfies both the Security team's audit requirements and the Engineering team's cost and performance constraints. Output as: {log_retention_days, pii_in_logs, sampling_rate_pct, alert_on_error_rate_threshold_pct}.",
    "ground_truth": {
      "log_retention_days": 90,
      "pii_in_logs": false,
      "sampling_rate_pct": 10,
      "alert_on_error_rate_threshold_pct": 1
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_security": "You represent Security. Hard constraints: (1) logs must be retained minimum 90 days for incident forensics, (2) PII must never appear in logs — GDPR violation risk, (3) all 5xx errors must be logged at 100% — no sampling for errors, (4) alert threshold for error rates must be at or below 1% to catch issues early.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) log retention beyond 90 days exceeds storage budget, (2) 100% logging at current traffic volumes costs $40k/month — must use sampling, (3) sampling rate of 10% acceptable for info/debug logs, (4) PII stripping via middleware is already implemented so no PII should reach logs anyway."
    }
  },
  {
    "id": "adv_011",
    "question": "Create an API versioning and deprecation policy satisfying both the Platform team's maintenance constraints and external Partners' stability requirements. Output as: {support_versions_simultaneously, deprecation_notice_days, breaking_change_policy, sunset_path}.",
    "ground_truth": {
      "support_versions_simultaneously": 2,
      "deprecation_notice_days": 180,
      "breaking_change_policy": "new_version_only_never_in_place",
      "sunset_path": "v_current_plus_one_legacy_version"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_platform": "You represent Platform. Hard constraints: (1) cannot maintain more than 2 API versions simultaneously — operational overhead too high, (2) breaking changes must never happen in-place on an existing version, (3) old versions must be fully deprecated within 12 months of new version release, (4) deprecation notice minimum 6 months.",
      "agent_partners": "You represent external API Partners. Hard constraints: (1) minimum 6-month deprecation notice required — matches our release planning cycles, (2) breaking changes in-place are catastrophic — unacceptable, (3) happy with 2 simultaneous versions if the older one gets 6 months notice before sunset, (4) need clear sunset documentation before migration."
    }
  },
  {
    "id": "adv_012",
    "question": "Negotiate a bug triage SLA satisfying both the Support team's customer commitments and Engineering's capacity constraints. Output as: {sev1_response_hours, sev2_response_hours, sev3_response_hours, on_call_rotation_size}.",
    "ground_truth": {
      "sev1_response_hours": 1,
      "sev2_response_hours": 8,
      "sev3_response_hours": 72,
      "on_call_rotation_size": 4
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_support": "You represent Customer Support. Hard constraints: (1) SEV1 (production down) response must be under 1 hour — in customer contracts, (2) SEV2 response within 8 hours, (3) SEV3 within 72 hours, (4) support needs a single on-call contact number that always gets answered — no voicemail.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) on-call rotation must have minimum 4 engineers to avoid burnout — each engineer on call max 1 week per month, (2) SEV1 1-hour SLA is achievable with 4-person rotation, (3) SEV2 8-hour SLA feasible during business hours, (4) SEV3 72-hour SLA requires no after-hours response — acceptable."
    }
  },
  {
    "id": "adv_013",
    "question": "Design a feature flag governance policy satisfying both the Growth team's experimentation velocity and the Platform team's operational safety requirements. Output as: {max_concurrent_flags, flag_review_required_above_pct, auto_kill_on_error_rate, flag_lifetime_days}.",
    "ground_truth": {
      "max_concurrent_flags": 20,
      "flag_review_required_above_pct": 10,
      "auto_kill_on_error_rate": 2,
      "flag_lifetime_days": 30
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_growth": "You represent Growth. Hard constraints: (1) need to run minimum 10 concurrent A/B experiments at all times, (2) flag review process cannot take more than 24 hours — kills experiment velocity, (3) small experiments (<10% traffic) should not require platform review, (4) flags should not auto-expire in less than 30 days — some experiments run longer.",
      "agent_platform": "You represent Platform. Hard constraints: (1) maximum 20 concurrent feature flags — more causes config complexity and incident risk, (2) any flag affecting more than 10% of traffic requires platform review, (3) auto-kill switch must fire if error rate exceeds 2% on flagged cohort, (4) all flags must have a defined owner and expire after 30 days maximum."
    }
  },
  {
    "id": "adv_014",
    "question": "Create a third-party dependency approval policy satisfying both the Security team's vetting requirements and the Engineering team's development speed needs. Output as: {review_sla_days, auto_approve_criteria, banned_licenses, required_checks}.",
    "ground_truth": {
      "review_sla_days": 3,
      "auto_approve_criteria": "previously_approved_version_patch_update",
      "banned_licenses": ["GPL_v3", "AGPL", "SSPL"],
      "required_checks": ["cve_scan", "license_check", "maintainer_activity_check"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_security": "You represent Security. Hard constraints: (1) all new npm/pip/maven dependencies must be reviewed before merging, (2) GPL v3, AGPL, SSPL licenses are banned — incompatible with commercial product, (3) CVE scan required for every dependency, (4) review SLA must be under 5 business days.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) review SLA longer than 3 days blocks sprint work, (2) patch updates to already-approved packages should be auto-approved — reviewing semver patches is wasteful, (3) CVE scan and license check are acceptable — maintainer activity check is also useful but not currently in tooling, (4) MIT, Apache 2.0, BSD licenses are pre-approved."
    }
  },
  {
    "id": "adv_015",
    "question": "Negotiate a cost allocation model for shared infrastructure satisfying both Finance's chargeback requirements and Engineering's incentive design goals. Output as: {allocation_method, minimum_team_charge_pct, overage_penalty_pct, review_cadence_months}.",
    "ground_truth": {
      "allocation_method": "usage_based_with_reserved_floor",
      "minimum_team_charge_pct": 20,
      "overage_penalty_pct": 120,
      "review_cadence_months": 3
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_finance": "You represent Finance. Hard constraints: (1) every team must be charged for their cloud usage — no free-rider teams, (2) chargeback model must be auditable and usage-based, (3) teams that exceed reserved capacity should pay a premium (overage rate), (4) allocation model must be reviewed at least quarterly.",
      "agent_engineering": "You represent Engineering. Hard constraints: (1) usage-based allocation is acceptable but teams need a reserved floor so they can plan budgets, (2) minimum charge should not exceed 20% of total allocation to avoid penalizing small teams, (3) overage rate of more than 120% of base rate creates perverse incentives, (4) quarterly review cadence is fine."
    }
  }
]