[
  {
    "id": "coop_001",
    "question": "Agree on a JSON schema for the User Profile API response that satisfies both frontend rendering requirements and backend database constraints. Output the final agreed JSON schema.",
    "ground_truth": {
      "type": "object",
      "properties": {
        "user_id": {"type": "string"},
        "full_name": {"type": "string"},
        "email": {"type": "string", "format": "email"},
        "preferences": {
          "type": "object",
          "properties": {
            "theme": {"type": "string", "enum": ["light", "dark", "system"]},
            "notifications": {"type": "boolean"}
          },
          "required": ["theme", "notifications"]
        }
      },
      "required": ["user_id", "full_name", "email", "preferences"]
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_frontend": "You represent the Frontend. You need the following fields to render the profile: a unique user ID (string), full name, email address, and a preferences object containing 'theme' (light/dark/system) and a boolean 'notifications' toggle. All these must be guaranteed to be present (required).",
      "agent_backend": "You represent the Backend. You store the user ID as a UUID string, name as a single 'full_name' string, and email. You store preferences as a JSONB column. You need to agree on the exact schema structure, keys, and types with the frontend to ensure the API response validates correctly."
    }
  },
  {
    "id": "coop_002",
    "question": "Design a shared event payload for a pub/sub system handling 'Order Placed' events. Satisfy both the Order Service (publisher) and the Analytics Service (subscriber). Output the exact agreed JSON payload structure.",
    "ground_truth": {
      "event_type": "ORDER_PLACED",
      "timestamp_utc": "ISO8601_string",
      "order_id": "string",
      "customer_id": "string",
      "total_amount_cents": "integer",
      "currency": "string",
      "items": [
        {"sku": "string", "quantity": "integer", "price_cents": "integer"}
      ]
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_publisher": "You are the Order Service (publisher). You emit events when an order is placed. You can provide order_id, customer_id, total amount in cents, currency, and a list of items (sku, quantity, price in cents). You must include a standard 'event_type' field set to 'ORDER_PLACED'.",
      "agent_subscriber": "You are the Analytics Service (subscriber). You need to ingest order events. You require all financial amounts to be in cents (integers) to avoid float precision issues. You also absolutely need a 'timestamp_utc' field in ISO8601 format for time-series aggregation. Agree on the payload structure with the publisher."
    }
  },
  {
    "id": "coop_003",
    "question": "Agree on an interface definition (GraphQL or TypeScript) for a Paginated List of Products. Both the mobile client and the catalog service must agree on the pagination strategy.",
    "ground_truth": {
      "edges": [
        {"node": {"product_id": "string", "name": "string"}, "cursor": "string"}
      ],
      "page_info": {
        "has_next_page": "boolean",
        "end_cursor": "string"
      }
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_client": "You are the Mobile Client. You implement infinite scrolling for the product catalog. You prefer cursor-based pagination (Relay standard) because offset-based pagination causes duplicate items when new products are inserted at the top. You need 'edges' (with 'node' and 'cursor') and 'page_info' (with 'has_next_page' and 'end_cursor').",
      "agent_service": "You are the Catalog Service. You currently support simple limit/offset pagination, but you can implement cursor-based pagination if required. Your product model has 'product_id' and 'name'. You need to negotiate the exact response structure with the client to ensure it matches their infinite scroll implementation."
    }
  },
  {
    "id": "coop_004",
    "question": "Define a standard configuration file structure (YAML or JSON) for deployment environments. Dev and Ops must agree. Output the exact structure.",
    "ground_truth": {
      "environment": "string",
      "database": {
        "host_env_var": "string",
        "port": "integer",
        "pool_size": "integer"
      },
      "features": {
        "enable_cache": "boolean",
        "maintenance_mode": "boolean"
      }
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_dev": "You are Development. You need the config to specify the 'environment' name, and feature flags like 'enable_cache' and 'maintenance_mode'. For the database, you need to know the 'port' and the connection 'pool_size'.",
      "agent_ops": "You are Operations. For security reasons, you cannot hardcode database hosts or passwords in the config file. The database host must be referenced by an environment variable name (e.g., 'host_env_var'). Agree on a structure that includes Dev's requirements but respects this security constraint."
    }
  },
  {
    "id": "coop_005",
    "question": "Establish a shared caching strategy and Redis key naming convention for user sessions. Output the agreed key format, TTL, and data payload structure.",
    "ground_truth": {
      "key_format": "session:{user_id}:{device_id}",
      "ttl_seconds": 86400,
      "payload": {
        "auth_token": "string",
        "last_active": "integer_timestamp"
      }
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_auth": "You are the Auth Service. You generate session tokens. A user can have multiple active sessions on different devices. You need the Redis key to include both 'user_id' and 'device_id'. The payload must store the 'auth_token'.",
      "agent_gateway": "You are the API Gateway. You validate sessions on every request. You need to know the exact Redis key format to look up the session. You also require a 'last_active' timestamp in the payload to implement idle timeouts, and the session must have a TTL of exactly 24 hours (86400 seconds) in Redis."
    }
  },
  {
    "id": "coop_006",
    "question": "Agree on a standardized error response payload for REST APIs across the organization. Output the JSON schema.",
    "ground_truth": {
      "error": {
        "code": "string",
        "message": "string",
        "target": "string",
        "details": [
          {"code": "string", "message": "string", "target": "string"}
        ]
      }
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_api_guild": "You represent the API Guidelines Guild. You mandate that all error responses must be wrapped in an 'error' object. Inside, there must be a machine-readable 'code', a human-readable 'message', and an optional 'target' indicating the field that caused the error.",
      "agent_client_team": "You represent the Frontend Client teams. You agree with the guild's structure, but for forms with multiple validation errors, you need a way to receive multiple errors at once. You require a 'details' array inside the 'error' object, where each element has its own 'code', 'message', and 'target'."
    }
  },
  {
    "id": "coop_007",
    "question": "Design a webhook signature validation mechanism. Both the webhook sender (Payment Gateway) and receiver (Merchant Backend) must agree on the headers and hashing algorithm. Output: {header_name, hash_algorithm, payload_format}.",
    "ground_truth": {
      "header_name": "X-Signature-256",
      "hash_algorithm": "HMAC-SHA256",
      "payload_format": "timestamp.json_body"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_sender": "You are the Payment Gateway. You send webhooks. You prefer to use HMAC-SHA256 for signatures. To prevent replay attacks, you want to include the current Unix timestamp in the signature calculation, so the signed string should be the timestamp concatenated with a dot ('.') and then the raw JSON body.",
      "agent_receiver": "You are the Merchant Backend. You need to validate webhooks. You agree to use HMAC-SHA256, but you need the signature to be sent in a specific header named 'X-Signature-256'. You need to agree on exactly what string is being hashed so your validation logic matches."
    }
  },
  {
    "id": "coop_008",
    "question": "Define the gRPC Protobuf message definition for a 'Search Users' RPC. Must support filtering and pagination. Output the exact message fields and types.",
    "ground_truth": {
      "request": {"query": "string", "limit": "int32", "offset": "int32"},
      "response": {"users": "repeated User", "total_count": "int32"}
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_search_service": "You build the Search Service in Go. You need the request to include a 'query' string, 'limit' (int32), and 'offset' (int32). You will return a repeated list of 'User' messages.",
      "agent_admin_dashboard": "You build the Admin Dashboard. You need to display the total number of pages, so the response must include a 'total_count' (int32) of all matching users, independent of the pagination limit. Agree on the exact Request and Response message definitions."
    }
  },
  {
    "id": "coop_009",
    "question": "Agree on a metric tagging strategy for Prometheus. Output the mandated labels for all HTTP server metrics.",
    "ground_truth": {
      "required_labels": ["service_name", "environment", "method", "status_code", "endpoint"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_sre": "You are SRE. For Prometheus metrics, you mandate that all metrics globally have 'service_name' and 'environment' labels. For HTTP metrics specifically, you also need 'status_code' to track error rates.",
      "agent_devops": "You are DevOps. You agree with SRE, but to build meaningful dashboards for developers, HTTP metrics must also include the HTTP 'method' (GET/POST) and the normalized routing 'endpoint' (e.g., '/users/:id', not the raw URL). Agree on the final list of required labels."
    }
  },
  {
    "id": "coop_010",
    "question": "Design a shared database schema (SQL DDL) for a 'comments' table that supports nested replies (threaded comments).",
    "ground_truth": {
      "columns": ["id", "post_id", "user_id", "parent_id", "content", "created_at"],
      "foreign_keys": ["parent_id_references_comments_id"]
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_backend": "You are the Backend Developer. You need a 'comments' table with 'id', 'post_id', 'user_id', 'content', and 'created_at'. To support replies, you want to use the Adjacency List model by adding a 'parent_id' column that self-references the 'comments' table.",
      "agent_dba": "You are the DBA. You agree with the Adjacency List model. You must ensure that the 'parent_id' column has a proper foreign key constraint referencing the 'id' column of the same table to maintain referential integrity. Agree on the exact columns and the required foreign key."
    }
  },
  {
    "id": "coop_011",
    "question": "Agree on a standard log format for structured JSON logging. Output the required root-level JSON keys.",
    "ground_truth": {
      "required_keys": ["timestamp", "level", "message", "trace_id", "context"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_app_dev": "You write application code. Your structured logs currently output 'time', 'level', 'msg', and a 'context' object for arbitrary key-value pairs.",
      "agent_observability": "You run the ELK stack. You need standardized keys: 'timestamp' (not 'time'), 'level', and 'message' (not 'msg'). You also mandate that every log line includes a 'trace_id' for distributed tracing. You are fine keeping the 'context' object. Agree on the final list of root keys."
    }
  },
  {
    "id": "coop_012",
    "question": "Design a contract for a rate-limiting API response. Output the required HTTP headers.",
    "ground_truth": {
      "headers": ["X-RateLimit-Limit", "X-RateLimit-Remaining", "X-RateLimit-Reset", "Retry-After"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_api_gateway": "You manage the API Gateway. When a client is rate-limited, you return a 429 Too Many Requests status. You provide headers indicating the total quota ('X-RateLimit-Limit') and how many requests are left ('X-RateLimit-Remaining').",
      "agent_sdk_team": "You build the official SDKs. To implement automatic retries efficiently, your SDKs need to know exactly when the quota resets. You require an 'X-RateLimit-Reset' header (epoch timestamp) and, specifically for 429 responses, a 'Retry-After' header indicating seconds to wait. Agree on the full set of headers."
    }
  },
  {
    "id": "coop_013",
    "question": "Agree on a feature flag evaluation payload format sent from the backend to the frontend. Output the JSON schema.",
    "ground_truth": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "flag_key": {"type": "string"},
          "enabled": {"type": "boolean"},
          "variant": {"type": "string", "nullable": true}
        },
        "required": ["flag_key", "enabled"]
      }
    },
    "evaluator": "schema_match",
    "agent_contexts": {
      "agent_backend": "You evaluate feature flags. You can return a dictionary mapping flag names to boolean values: {'new_ui': true, 'beta_feature': false}. Some flags are multivariate and return a string variant instead of a boolean.",
      "agent_frontend": "You consume feature flags. A dynamic dictionary makes type-checking hard. You prefer an array of objects, where each object has 'flag_key', 'enabled' (boolean), and an optional 'variant' (string). Agree on this array-of-objects structure."
    }
  },
  {
    "id": "coop_014",
    "question": "Design a message queue topic naming convention. Output the agreed format string.",
    "ground_truth": {
      "format": "{domain}.{service}.{event_type}.v{version}"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_architect": "You are the Enterprise Architect. You want Kafka topics to follow a domain-driven design structure: '{domain}.{service}.{event_type}' (e.g., 'finance.billing.invoice_created').",
      "agent_data_eng": "You are the Data Engineer. You build pipelines consuming these topics. You mandate that schema evolution must be handled by topic versioning. You require a '.v{version}' suffix appended to the architect's format (e.g., '...invoice_created.v1'). Agree on the final format string."
    }
  },
  {
    "id": "coop_015",
    "question": "Establish a standard for representing monetary values in the shared database and APIs. Output the data type and format constraints.",
    "ground_truth": {
      "data_type": "integer",
      "unit": "minor_units",
      "currency_code": "ISO_4217_3_letter"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_frontend": "You display prices. You receive values like 10.50 as floats. You want to keep using floats because it's easy to format with standard libraries, but you need a currency code (e.g., 'USD', 'EUR') to know the symbol.",
      "agent_backend": "You handle billing. Floats cause rounding errors in calculations. You mandate that all monetary values must be represented as integers in the smallest minor unit (e.g., cents). You agree on needing the ISO 4217 3-letter currency code. Convince the frontend to accept the integer/minor_units standard."
    }
  }
]
