[
  {
    "id": "dpip_001",
    "question": "Which microservice is causing the elevated p99 latency seen by end users?",
    "ground_truth": "payment-gateway",
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "API gateway logs: all requests arrive healthy, avg latency 12ms. Upstream services respond within SLA except for /checkout endpoint which shows 1800ms p99 since 14:30.",
      "agent_b": "Auth service logs: token validation averaging 8ms. No anomalies. All downstream calls to user-profile complete in under 20ms.",
      "agent_c": "Payment-gateway logs: external Stripe API calls timing out at 1750ms since 14:28. Internal retry logic adding 3 attempts per request. No alerts fired because success rate stays above 95%.",
      "agent_d": "User-profile service logs: all reads from Redis cache hitting successfully. No slow queries. Completely isolated from payment flow."
    }
  },
  {
    "id": "dpip_002",
    "question": "Which data center region should be shut down to stop the cascading DNS failure, and why?",
    "ground_truth": "us-east-2",
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "us-east-1 network logs: all DNS resolvers healthy. Receiving unusual flood of recursive queries from us-east-2 peers since 09:15. NXDOMAIN rate normal.",
      "agent_b": "us-east-2 network logs: primary DNS resolver restarted at 09:12. Backup resolver misconfigured — forwarding all unresolved queries to us-east-1 in infinite loop. Zone file intact.",
      "agent_c": "us-west-1 network logs: elevated query latency starting 09:18. Tracing shows query chains originating from us-east-2 resolver. No local misconfigurations.",
      "agent_d": "Global traffic manager logs: us-east-2 health checks failing since 09:14. Failover not triggered because DNS itself is needed for failover routing — circular dependency detected."
    }
  },
  {
    "id": "dpip_003",
    "question": "Which employee leaked the confidential merger document, based on access logs and communication metadata?",
    "ground_truth": "employee_id_EMP-4471",
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Document access logs: merger_draft_v3.pdf accessed by EMP-4471 at 11:42, EMP-2209 at 13:05, EMP-8801 at 15:30 on Monday. File was forwarded externally at 17:55 Monday.",
      "agent_b": "Email gateway logs: EMP-4471 sent 3 external emails between 17:50-18:00 Monday. Recipients are personal Gmail accounts. Attachment sizes match merger document size (2.3MB).",
      "agent_c": "Badge access logs: EMP-2209 badged out at 14:00 Monday and did not return. EMP-8801 was in a recorded all-hands until 18:30. EMP-4471 was at desk until 18:15.",
      "agent_d": "VPN logs: only EMP-4471 had an active VPN session to the document server between 17:40 and 18:05 on Monday. EMP-2209 and EMP-8801 had no VPN activity after 15:00."
    }
  },
  {
    "id": "dpip_004",
    "question": "What is the exact SQL query causing the production database deadlock, and which table is the contention point?",
    "ground_truth": {"query_pattern": "UPDATE orders SET status WHERE user_id IN (SELECT...)", "table": "orders"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "App server A logs: transaction TXN-9921 started at 10:04:33, locked rows in 'orders' table for user_id batch 1000-1500. Waiting on lock held by TXN-9944 since 10:04:35.",
      "agent_b": "App server B logs: transaction TXN-9944 started at 10:04:34, locked rows in 'orders' table for user_id batch 1400-1900. Waiting on lock held by TXN-9921. Deadlock victim chosen at 10:04:37.",
      "agent_c": "Query analyzer logs: both transactions originated from the nightly-batch job running UPDATE orders SET status='archived' WHERE user_id IN (SELECT user_id FROM users WHERE last_login < '2024-01-01'). Overlapping user_id ranges not handled.",
      "agent_d": "DBA monitoring: 'inventory' and 'sessions' tables show zero contention. 'orders' table row-lock wait time spiked to 4200ms at 10:04. Index on user_id exists but batch job not using it."
    }
  },
  {
    "id": "dpip_005",
    "question": "Which third-party vendor's API change broke the nightly ETL pipeline, and what changed?",
    "ground_truth": {"vendor": "Salesforce", "change": "deprecated_oauth1_endpoint"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "ETL orchestrator logs: pipeline 'crm_sync' failed at step 3 of 7 at 02:14. Error: HTTP 401 Unauthorized from endpoint https://login.salesforce.com/services/oauth/token. Steps 1-2 (internal DB reads) succeeded.",
      "agent_b": "Salesforce changelog feed (monitored by vendor-ops agent): Salesforce deprecated OAuth 1.0 endpoints on March 1. Migration to OAuth 2.0 required. Announcement sent to registered admin email (unchecked alias).",
      "agent_c": "ETL pipeline code audit: crm_sync uses oauth_v1_client library version 1.2.3. No OAuth 2.0 client configured. Stripe and HubSpot connectors use OAuth 2.0 and are passing. Only Salesforce connector uses v1.",
      "agent_d": "Secrets manager logs: Salesforce OAuth 1.0 consumer key and secret are present and valid. Token refresh attempted 3 times, all returned 401. Other vendor tokens (Stripe, HubSpot, Zendesk) refreshed successfully at 02:00."
    }
  },
  {
    "id": "dpip_006",
    "question": "Which kubernetes pod is causing the cluster-wide memory pressure and what is the root cause?",
    "ground_truth": {"pod": "ml-inference-pod-7d9f", "root_cause": "unbounded_model_cache"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Node-1 metrics: ml-inference-pod-7d9f memory usage grew from 2GB to 14GB over 6 hours. No OOM kill yet because node has 16GB. Pod has no memory limit set in manifest.",
      "agent_b": "Node-2 metrics: all pods healthy, total memory at 60% utilization. No anomalies. Scheduler starting to avoid Node-1 for new pod placements due to memory pressure signals.",
      "agent_c": "Application logs from ml-inference-pod-7d9f: LRU cache for model embeddings has no max_size parameter set. Cache growing unboundedly as unique inference requests accumulate. 2.1M cache entries logged.",
      "agent_d": "Cluster autoscaler logs: scale-up event triggered at 11:30 but suppressed because existing nodes report available capacity. Node-1 memory pressure not visible to scheduler until eviction threshold."
    }
  },
  {
    "id": "dpip_007",
    "question": "Which server caused the 5pm outage and what was the root cause?",
    "ground_truth": {"culprit": "srv-B", "root_cause": "memory_leak_in_payment_service"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "srv-A logs: normal traffic all day. CPU 34%, RAM 41%. Incoming requests dropped 60% at 17:05 but no internal errors generated.",
      "agent_b": "srv-B logs: RAM climbed to 94% at 17:02. OOM killer fired, payment_service v2.3.1 crashed at 17:03. Known memory leak in v2.3.1 release notes.",
      "agent_c": "srv-C logs: DB connection timeouts started at 17:03 matching srv-B crash time. Cascade 503s returned to all users at 17:04. No internal errors — all failures are upstream.",
      "agent_d": "Load balancer logs: traffic routing normal until 17:03. srv-B removed from pool automatically at 17:03:12. Remaining servers could not absorb full traffic load."
    }
  },
  {
    "id": "dpip_008",
    "question": "Which feature flag deployment caused the A/B test data corruption, and which user cohort is affected?",
    "ground_truth": {"flag": "new_checkout_flow_v2", "cohort": "mobile_ios_users"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Feature flag service logs: 'new_checkout_flow_v2' rolled out to 50% of mobile_ios_users at 09:00. 'dark_mode_beta' rolled out to all users at 08:45. 'recommendation_engine_v3' active for web users only.",
      "agent_b": "Analytics pipeline logs: event schema mismatch errors starting 09:02. Events from mobile_ios_users missing 'session_currency' field. Web users and Android users event schemas intact. 47,000 corrupted events in last 2 hours.",
      "agent_c": "Mobile app release notes: new_checkout_flow_v2 introduced a refactored CheckoutEvent class. iOS implementation accidentally removed 'session_currency' from the serialized payload. Android implementation unaffected — different codebase.",
      "agent_d": "Data warehouse logs: A/B test tables for experiment 'checkout_conversion_q1' show NULL values in revenue column for mobile_ios rows since 09:02. Control group (mobile_ios users not in flag rollout) unaffected."
    }
  },
  {
    "id": "dpip_009",
    "question": "Which supply chain vendor missed the SLA and what is the downstream impact on production?",
    "ground_truth": {"vendor": "ChipCo_Taiwan", "impact": "GPU_assembly_line_halt_72h"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Procurement system logs: ChipCo_Taiwan shipment SHI-8821 (GPU memory modules, 4000 units) expected March 5, not received. SensorParts_Korea and CableMakers_Germany both delivered on time March 4.",
      "agent_b": "Warehouse receiving logs: GPU assembly line requires memory modules from SHI-8821 to continue. Current buffer stock depleted at 14:00 March 5. Assembly line paused. CPU and networking assembly lines unaffected.",
      "agent_c": "ChipCo_Taiwan vendor portal: shipment SHI-8821 delayed due to Taiwan port strike. New ETA March 8. Vendor did not proactively notify procurement team — found via portal polling.",
      "agent_d": "Production planning logs: GPU assembly halt propagates to 3 downstream OEM contracts due March 10. Penalty clauses activate after 48h delay. Air freight option exists at 4x cost — decision needed within 6h."
    }
  },
  {
    "id": "dpip_010",
    "question": "Which user account was compromised in the breach and what was the attack vector?",
    "ground_truth": {"account": "admin_svc_account_deploybot", "vector": "exposed_github_actions_secret"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "IAM audit logs: admin_svc_account_deploybot made 47 API calls between 03:00-03:45 including S3 bucket enumeration, RDS snapshot export, and IAM role listing. Normal usage for this account is zero calls outside business hours.",
      "agent_b": "GitHub Actions logs: workflow 'deploy-prod.yml' accidentally printed AWS_SECRET_ACCESS_KEY to build logs in commit abc1234 on Feb 28. Log was public for 6 hours before repo was made private. Secret belonged to admin_svc_account_deploybot.",
      "agent_c": "CloudTrail logs: API calls at 03:00 originated from IP 45.33.32.156 (known Tor exit node). admin_svc_account_deploybot has no MFA. No other accounts show unusual activity.",
      "agent_d": "Secrets manager audit: admin_svc_account_deploybot credentials were not rotated after the GitHub incident on Feb 28. Rotation policy set to 90 days. Security team was not alerted about the log exposure."
    }
  },
  {
    "id": "dpip_011",
    "question": "Which patient's medication dosage was incorrectly entered in the pharmacy system, and what is the correct dose?",
    "ground_truth": {"patient_id": "PAT-3341", "correct_dose": "500mg_twice_daily"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Prescribing physician notes: PAT-3341 prescribed Metformin 500mg twice daily on March 3. PAT-7892 prescribed Metformin 1000mg once daily. Both prescriptions signed and faxed to pharmacy at 10:30.",
      "agent_b": "Pharmacy intake logs: PAT-3341 entered as Metformin 1000mg twice daily — fax OCR misread '500mg x2' as '1000mg x2'. PAT-7892 entered correctly. Pharmacist approved without cross-referencing original.",
      "agent_c": "Dispensing logs: PAT-3341 picked up 60-tablet supply of 1000mg Metformin on March 4. PAT-7892 pickup pending. No adverse event reported yet — PAT-3341 only took first dose this morning.",
      "agent_d": "Insurance adjudication logs: PAT-3341 claim flagged by payer AI as unusual dosage for patient weight profile (62kg). Flag sent to pharmacy benefits manager but not routed to dispensing pharmacist."
    }
  },
  {
    "id": "dpip_012",
    "question": "Which trading algorithm caused the flash crash at 14:32 and what triggered it?",
    "ground_truth": {"algorithm": "momentum_arb_v4", "trigger": "spoofing_detection_false_positive"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Exchange order book logs: 847 sell orders for AAPL totaling 2.1M shares submitted within 340ms starting 14:32:00. Orders came from three broker IDs all registered to Apex Trading LLC.",
      "agent_b": "Apex Trading system logs: momentum_arb_v4 algorithm triggered sell cascade at 14:32 after its spoofing-detection module flagged incoming buy orders as manipulative. Algorithm designed to front-run and exit before manipulation resolves.",
      "agent_c": "Spoofing detection module logs: 400 large buy orders detected at 14:31:58 from institutional investor BlackRock rebalancing. These were legitimate orders. momentum_arb_v4 misclassified them as spoofing with 94% confidence.",
      "agent_d": "Market surveillance logs: price dropped 4.7% in 190ms. Circuit breaker activated at 14:32:02. Post-mortem: BlackRock rebalancing orders were within normal parameters. Three other algorithms also began selling in response to momentum_arb_v4's initial cascade."
    }
  },
  {
    "id": "dpip_013",
    "question": "Which country's regulatory filing is missing from the drug approval submission package, causing the rejection?",
    "ground_truth": "Brazil_ANVISA_Phase3_addendum",
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Regulatory affairs document index: submission package contains FDA_Phase3_report, EMA_Phase3_report, PMDA_Japan_Phase3_report, ANVISA_Phase2_report. Total 847 documents. Submission sent to WHO pre-qualification on March 1.",
      "agent_b": "WHO pre-qualification rejection letter: package incomplete — Brazil market requires ANVISA Phase 3 clinical data addendum in addition to Phase 2 report for novel drug classes. Rejection code REJ-4421.",
      "agent_c": "Clinical data warehouse: ANVISA_Phase3_addendum.pdf generated February 20, stored in /regulatory/brazil/phase3/. Not included in submission manifest. FDA, EMA, PMDA Phase 3 addenda all included correctly.",
      "agent_d": "Document management system logs: submission manifest was generated by script that queried /regulatory/*/phase2/ and /regulatory/*/phase3/ but excluded /regulatory/brazil/ due to a folder permission misconfiguration set on February 15."
    }
  },
  {
    "id": "dpip_014",
    "question": "Which IoT sensor is reporting false readings and causing incorrect automated irrigation decisions?",
    "ground_truth": {"sensor_id": "SOIL-447", "fault": "waterlogged_capacitive_probe"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Irrigation controller logs: Field Zone 3 received 4 irrigation cycles in 24 hours — 3x normal. Controller acting on soil moisture readings below 20% threshold. Zones 1, 2, 4 operating normally.",
      "agent_b": "Sensor telemetry — Zone 3: SOIL-447 reporting moisture at 12-15% consistently. SOIL-448 and SOIL-449 in same zone reporting 68-72%. Farmer visual inspection confirms Zone 3 soil is saturated.",
      "agent_c": "Hardware maintenance logs: SOIL-447 probe was submerged during heavy rain event March 2. Capacitive probe electronics not rated for submersion. Corrosion causes probe to read near-zero moisture regardless of actual conditions.",
      "agent_d": "Agronomist decision model: irrigation trigger fires when average of all zone sensors drops below 20%. SOIL-447 pulling Zone 3 average to 32% (below trigger) even when SOIL-448 and SOIL-449 alone average 70%."
    }
  },
  {
    "id": "dpip_015",
    "question": "Which contractor submitted a fraudulent invoice and for what amount?",
    "ground_truth": {"contractor": "BuildRight_LLC", "amount": "$284,000"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Accounts payable logs: Invoice INV-8821 from BuildRight_LLC for $284,000 submitted March 1 for 'Phase 2 concrete foundation work'. Invoice approved by site manager and queued for payment.",
      "agent_b": "Site inspection reports: Phase 2 concrete foundation work not started as of March 3. Site manager who approved INV-8821 is on leave — approval may have been forged. BuildRight_LLC completed Phase 1 ($140,000) legitimately.",
      "agent_c": "Contractor payment history: BuildRight_LLC paid $140,000 for Phase 1 on Feb 10. INV-8821 references PO-2241 but PO-2241 in procurement system is for Phase 1 ($140,000), not Phase 2. No Phase 2 PO exists.",
      "agent_d": "Digital signature audit: INV-8821 approval signature metadata shows it was created at 02:14 AM on a Saturday. Site manager's normal approval pattern is weekdays 08:00-17:00. IP address of approval is from a residential ISP not matching company VPN."
    }
  },
  {
    "id": "dpip_016",
    "question": "Which flight's baggage was loaded onto the wrong aircraft and what is the destination mismatch?",
    "ground_truth": {"flight": "UA-441", "mismatch": "bags_tagged_SFO_loaded_onto_ORD_flight"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Baggage handling system — Gate B12: 47 bags tagged for SFO (UA-441) scanned at B12 belt at 15:30. 12 bags routed to B14 belt by automated sorter. Sorter error log shows barcode misread on bag tag batch.",
      "agent_b": "Gate B14 loading logs: 12 unmanifested bags loaded onto UA-887 (Chicago ORD) at 15:45. Ramp agent flagged weight discrepancy but flight departed on time. Manifest shows 134 bags, system shows 146 loaded.",
      "agent_c": "UA-441 departure log: Flight departed SFO gate B12 at 16:00 with 35 bags. 12 bags short of manifest. Gate agent notified baggage office at 15:55 but trace system response time exceeded departure window.",
      "agent_d": "Baggage trace system: sorter error originated from label printer B12-P3 which produced barcodes with corrupted gate field — printed 'B14' in gate field due to firmware bug deployed March 3. B12-P1 and B12-P2 unaffected."
    }
  },
  {
    "id": "dpip_017",
    "question": "Which research lab's experimental data contains a calibration error invalidating the cross-lab study results?",
    "ground_truth": {"lab": "Lab_C_Mumbai", "error": "spectrophotometer_wavelength_offset_15nm"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Lab A (London) instrument logs: Spectrophotometer calibrated with NIST standard March 1. Absorbance readings at 540nm for compound X: 0.412, 0.418, 0.409. CV 1.1%. Within acceptable range.",
      "agent_b": "Lab B (Toronto) instrument logs: Spectrophotometer calibrated March 1. Absorbance readings at 540nm for same compound X batch: 0.408, 0.415, 0.411. CV 0.9%. Consistent with Lab A.",
      "agent_c": "Lab C (Mumbai) instrument logs: Spectrophotometer last calibrated January 15. Absorbance readings at 540nm: 0.287, 0.291, 0.284. CV 1.2%. Significantly lower than Labs A and B. Technician notes instrument 'repaired' Feb 20 — wavelength reset not verified post-repair.",
      "agent_d": "Cross-lab data analysis: meta-analysis assumes all labs measuring at identical wavelengths. Lab C readings 30% lower than Labs A and B for identical samples. A 15nm offset in Lab C's wavelength setting would produce exactly this discrepancy per the compound's absorption spectrum."
    }
  },
  {
    "id": "dpip_018",
    "question": "Which warehouse aisle has an inventory discrepancy causing the stock-out, and what is the missing SKU?",
    "ground_truth": {"aisle": "C-7", "sku": "SKU-882941"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "WMS system inventory: SKU-882941 (industrial pump gasket) shows 340 units on hand in aisle C-7, bin 14. Last cycle count March 1. System has not flagged shortage.",
      "agent_b": "Picking logs: 12 pick orders for SKU-882941 returned 'location empty' errors today. Pickers sent to C-7 bin 14 found zero units. Adjacent bins C-7/13 and C-7/15 have correct inventory.",
      "agent_c": "Receiving logs: SKU-882941 received 340 units Feb 28. Put-away task assigned to forklift operator ID FO-221. Put-away confirmed in WMS at C-7/14 but operator's RF scanner had intermittent connectivity — confirmation may have been duplicated.",
      "agent_d": "Physical audit triggered today: C-7/14 confirmed empty. C-9/22 found to contain 340 units of SKU-882941 with no WMS location assignment. Forklift operator FO-221 likely put stock in C-9/22 but WMS recorded C-7/14."
    }
  },
  {
    "id": "dpip_019",
    "question": "Which student's exam submission was corrupted in the LMS and what caused it?",
    "ground_truth": {"student_id": "STU-7731", "cause": "concurrent_autosave_race_condition"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "LMS submission logs: STU-7731 final exam submission received at 14:58:43. File size 2KB — abnormally small for a 3-hour exam. STU-7731 had 847 autosave events during exam. All other 243 students submitted normally.",
      "agent_b": "STU-7731 browser session logs: student had two browser tabs open for the exam from 12:00-14:58. Autosave triggered simultaneously from both tabs at 14:58:41. Both tabs attempted to write the 'final' version to the same submission record.",
      "agent_c": "LMS database logs: concurrent write conflict at 14:58:41 for submission record STU-7731-EXAM-4. Write from Tab 1 (full 47KB response) collided with write from Tab 2 (partially loaded, 2KB). Tab 2 write won the race — committed empty partial state.",
      "agent_d": "LMS application code: autosave endpoint lacks row-level locking. Last-write-wins with no conflict detection. Bug reported in issue tracker March 2024 but not patched. Affects only students with multiple tabs — estimated 0.4% of exam takers."
    }
  },
  {
    "id": "dpip_020",
    "question": "Which city's water treatment plant sensor malfunction led to an incorrect chlorine dosing decision?",
    "ground_truth": {"plant": "Riverside_WTP_Unit2", "sensor": "residual_chlorine_probe_RC-7"},
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_a": "Riverside WTP Unit 1 SCADA: all sensors nominal. Chlorine residual at distribution point: 0.8mg/L (within 0.2-1.0mg/L regulatory range). Dosing pump running at 42% capacity.",
      "agent_b": "Riverside WTP Unit 2 SCADA: residual chlorine probe RC-7 reading 0.05mg/L — below minimum threshold. Automated system increased dosing pump to 95% capacity at 06:00. Actual distribution readings from Unit 2 zones showing 1.8mg/L — above safe limit.",
      "agent_c": "Probe maintenance records: RC-7 last calibrated November 2023. Probe membrane fouled with biofilm causing artificially low readings. Unit 2 has backup probe RC-8 but it was taken offline for scheduled calibration.",
      "agent_d": "Consumer complaint log: 14 calls received this morning about strong chlorine taste and smell from Unit 2 distribution zones. Unit 1 zones have zero complaints. Over-chlorination confirmed by field test kits at 07:30."
    }
  }

]