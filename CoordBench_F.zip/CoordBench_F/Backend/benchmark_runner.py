"""
CoordBench — Full Benchmark Runner
===================================
Orchestrates the complete pipeline:
  1. Start interceptor proxy (subprocess)
  2. Load all tasks from all task files
  3. Run each task through the specified framework × model
  4. Evaluate each transcript (quick: programmatic only / full: all 19 detectors)
  5. Aggregate and save results to results/<framework>_<model>_<timestamp>.json

Usage (CLI):
    python benchmark_runner.py --framework langgraph --model gpt-4o
    python benchmark_runner.py --framework autogen  --model gpt-4o --full-eval

Usage (module):
    from benchmark_runner import run_benchmark
    results = run_benchmark("langgraph", "gpt-4o", progress_callback=my_cb)
"""

import argparse
import json
import logging
import os
import socket
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("BenchmarkRunner")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
TASK_FILES: Dict[str, Path] = {
    "role_locked":           ROOT / "tasks" / "role_locked.py",
    "sequential_handoff":    ROOT / "tasks" / "sequential_handoff.py",
    "verification_gauntlet": ROOT / "tasks" / "verification_gaunlet.py",
    "debate_deliberation":   ROOT / "tasks" / "debate_deliberation.py",
    "resource_contention":   ROOT / "tasks" / "resource_contention.py",
}
TRANSCRIPT_DIR = ROOT / "transcripts" / "raw"
RESULTS_DIR    = ROOT / "results"
ALL_TASK_TYPES = list(TASK_FILES.keys())

# ---------------------------------------------------------------------------
# Task loading
# ---------------------------------------------------------------------------

def load_all_tasks(task_types: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """Load every active (non-commented) task from the selected task files."""
    if task_types is None:
        task_types = ALL_TASK_TYPES

    tasks: List[Dict[str, Any]] = []
    for ttype in task_types:
        path = TASK_FILES.get(ttype)
        if not path or not path.exists():
            logger.warning("Task file not found for type: %s", ttype)
            continue
        with open(path, "r", encoding="utf-8") as fh:
            raw = "\n".join(ln for ln in fh if not ln.lstrip().startswith("#"))
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.error("Failed to parse %s: %s", path.name, exc)
            continue
        if isinstance(data, dict):
            data["_task_type"] = ttype
            tasks.append(data)
        elif isinstance(data, list):
            for item in data:
                item["_task_type"] = ttype
                tasks.append(item)
    return tasks

# ---------------------------------------------------------------------------
# Proxy management
# ---------------------------------------------------------------------------

def find_free_port(preferred: int = 8080) -> int:
    for port in range(preferred, preferred + 100):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise RuntimeError("No free port found near 8080")


def start_proxy(port: int) -> subprocess.Popen:
    """Launch the interceptor proxy as a managed subprocess."""
    TRANSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    env = {
        **os.environ,
        "TRANSCRIPT_DIR": str(TRANSCRIPT_DIR),
        "PROXY_PORT":     str(port),
        "OPENAI_BASE_URL": os.getenv("OPENAI_BASE_URL", "https://openrouter.ai/api/v1"),
    }
    cmd = [
        sys.executable, "-m", "uvicorn",
        "harness.interceptor_proxy:app",
        "--host", "0.0.0.0",
        "--port", str(port),
        "--log-level", "warning",
    ]
    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    logger.info("Proxy subprocess PID=%d  port=%d", proc.pid, port)
    return proc


def wait_for_proxy(port: int, timeout: float = 20.0) -> bool:
    """Poll until the proxy accepts TCP connections."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            if s.connect_ex(("127.0.0.1", port)) == 0:
                time.sleep(0.3)
                logger.info("Proxy ready on port %d", port)
                return True
        time.sleep(0.3)
    logger.error("Proxy did not start within %.0fs", timeout)
    return False

# ---------------------------------------------------------------------------
# Task execution
# ---------------------------------------------------------------------------

def run_single_task(
    task_def:  Dict[str, Any],
    framework: str,
    model:     str,
    proxy_url: str,
    run_id:    str,
) -> Dict[str, Any]:
    """Instantiate the adapter, run the task, return raw result."""
    from Backend.harness.adapters.autogen_adapter   import AutoGenAdapter
    from Backend.harness.adapters.crewai_adapter    import CrewAIAdapter
    from Backend.harness.adapters.langgraph_adapter import LangGraphAdapter

    ADAPTERS = {
        "autogen":   AutoGenAdapter,
        "crewai":    CrewAIAdapter,
        "langgraph": LangGraphAdapter,
    }

    task_id     = task_def.get("id", "unknown")
    adapter_cls = ADAPTERS.get(framework)
    if adapter_cls is None:
        return {"success": False, "error": f"Unknown framework: {framework}",
                "final_answer": "", "elapsed_s": 0.0}

    adapter = adapter_cls(model_name=model, proxy_url=proxy_url, run_id=run_id)
    t0 = time.time()
    try:
        adapter.setup_agents(task_def)
        final_answer = adapter.run_task(task_def)
        return {"success": True, "final_answer": str(final_answer), "elapsed_s": time.time() - t0}
    except Exception as exc:
        logger.error("Task %s failed: %s", task_id, exc)
        return {"success": False, "error": str(exc),
                "final_answer": "", "elapsed_s": time.time() - t0}

# ---------------------------------------------------------------------------
# Transcript evaluation
# ---------------------------------------------------------------------------

def _safe(fn, path: str) -> Dict[str, Any]:
    try:
        r = fn(path)
        return r if isinstance(r, dict) else {"detected": bool(r)}
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


def evaluate_transcript(
    transcript_path: Path,
    task_def:        Dict[str, Any],
    final_answer:    str,
    quick_mode:      bool = True,
) -> Dict[str, Any]:
    """
    Evaluate a single transcript.

    quick_mode=True  → only programmatic + rule detectors (seconds per transcript).
    quick_mode=False → all 19 detectors incl. LLM judges (~60s per transcript).
    """
    from Backend.harness.detectors.utils.transcript_loader          import get_last_agent_response
    from Backend.evaluators.role_locked_eval                import evaluate as rl_eval
    from Backend.evaluators.sequential_handoff_eval         import evaluate as sh_eval
    from Backend.evaluators.verification_gauntlet_eval      import evaluate as vg_eval
    from Backend.evaluators.debate_deliberation_eval        import evaluate as dd_eval
    from Backend.evaluators.resource_contention_eval        import evaluate as rc_eval

    ground_truth = task_def.get("ground_truth")
    eval_type    = task_def.get("evaluator", "exact_match")
    task_type    = task_def.get("id", "").split("_")[0]   # "rl" | "sh" | "vg" | "dd" | "rc"

    # ── Read transcript metrics ───────────────────────────────────────────
    prompt_tokens = completion_tokens = latency_ms = turns = 0
    path_str = str(transcript_path)

    if transcript_path.exists():
        with open(transcript_path, "r", encoding="utf-8") as fh:
            for ln in fh:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    t = json.loads(ln)
                    turns             += 1
                    prompt_tokens     += t.get("prompt_tokens", 0)
                    completion_tokens += t.get("completion_tokens", 0)
                    latency_ms        += t.get("latency_ms", 0)
                except json.JSONDecodeError:
                    pass
        last_resp = final_answer or get_last_agent_response(path_str) or ""
    else:
        last_resp = final_answer or ""

    # ── Task success ─────────────────────────────────────────────────────
    if task_type == "rl":
        is_success = rl_eval(ground_truth, last_resp, eval_type)
    elif task_type == "sh":
        is_success = sh_eval(ground_truth, last_resp)
    elif task_type == "vg":
        is_success = vg_eval(ground_truth, last_resp)
    elif task_type == "dd":
        is_success = dd_eval(ground_truth, last_resp, eval_type)
    elif task_type == "rc":
        is_success = rc_eval(ground_truth, last_resp, eval_type)
    else:
        is_success = bool(ground_truth) and str(ground_truth).lower() in last_resp.lower()

    result: Dict[str, Any] = {
        "turns":             turns,
        "prompt_tokens":     prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens":      prompt_tokens + completion_tokens,
        "latency_ms":        latency_ms,
        "task_success":      is_success,
        "failure_modes":     [],
        "high_confidence":   [],
        "medium_confidence": [],
        "coordination_cost": {
            "total_turns":          turns,
            "talk_to_action_ratio": 0.0,
            "token_overhead_ratio": 0.0,
        },
    }

    if not transcript_path.exists():
        return result

    # ── Detection ─────────────────────────────────────────────────────────
    if quick_mode:
        from Backend.harness.detectors.programmatic.loop_detector        import run as loop_run
        from Backend.harness.detectors.programmatic.termination_detector  import run as term_run
        from Backend.harness.detectors.programmatic.coordination_overhead import run as overhead_run
        from Backend.harness.detectors.programmatic.context_degradation   import run as ctx_run
        from Backend.harness.detectors.programmatic.task_disobedience     import run as disobey_run
        from Backend.harness.detectors.rule_detectors.dominance            import run as dom_run
        from Backend.harness.detectors.rule_detectors.stagnation           import run as stag_run
        from Backend.harness.detectors.rule_detectors.handoff_corruption   import run as handoff_run

        loop_r     = _safe(loop_run,     path_str)
        term_r     = _safe(term_run,     path_str)
        overhead_r = _safe(overhead_run, path_str)
        ctx_r      = _safe(ctx_run,      path_str)
        dis_r      = _safe(disobey_run,  path_str)
        dom_r      = _safe(dom_run,      path_str)
        stag_r     = _safe(stag_run,     path_str)
        handoff_r  = _safe(handoff_run,  path_str)

        failure_modes: List[str] = []
        if loop_r.get("detected"):              failure_modes.append("loop")
        if term_r.get("premature_termination"): failure_modes.append("premature_termination")
        if term_r.get("termination_blindness"): failure_modes.append("termination_blindness")
        if overhead_r.get("detected"):          failure_modes.append("coordination_overhead")
        if ctx_r.get("detected"):               failure_modes.append("context_degradation")
        if dis_r.get("detected"):               failure_modes.append("task_disobedience")
        if dom_r.get("detected"):               failure_modes.append("agent_dominance")
        if stag_r.get("detected"):              failure_modes.append("stagnation")
        if handoff_r.get("detected"):           failure_modes.append("handoff_corruption")

        result["failure_modes"]     = failure_modes
        result["high_confidence"]   = failure_modes
        result["coordination_cost"] = {
            "total_turns":          turns,
            "talk_to_action_ratio": overhead_r.get("talk_to_action_ratio", 0.0),
            "token_overhead_ratio": overhead_r.get("token_overhead_ratio", 0.0),
        }
    else:
        from Backend.harness.detectors.aggregator import run as aggregate_run
        report = aggregate_run(path_str, task_success=is_success)
        result["failure_modes"]     = report.get("failure_modes_detected", [])
        result["high_confidence"]   = report.get("high_confidence", [])
        result["medium_confidence"] = report.get("medium_confidence", [])
        result["coordination_cost"] = report.get("coordination_cost", result["coordination_cost"])

    return result

# ---------------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------------

def run_benchmark(
    framework:         str,
    model:             str,
    task_types:        Optional[List[str]] = None,
    quick_mode:        bool = True,
    progress_callback: Optional[Callable[[int, int, str], None]] = None,
) -> Dict[str, Any]:
    """
    Run the full benchmark for one framework × model combination.

    Args:
        framework:         "autogen" | "crewai" | "langgraph"
        model:             Model name accepted by OpenRouter (e.g. "gpt-4o")
        task_types:        Subset of ALL_TASK_TYPES; None = all three.
        quick_mode:        True → programmatic detectors only (fast).
                           False → all 19 detectors incl. LLM judges (slow).
        progress_callback: Called as cb(current_idx, total, status_msg) after each task.

    Returns:
        Aggregated results dict (also written to results/<name>.json).
    """
    if task_types is None:
        task_types = ALL_TASK_TYPES

    tasks = load_all_tasks(task_types)
    if not tasks:
        raise ValueError(f"No tasks found for types: {task_types}")

    TRANSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    port      = find_free_port(8080)
    proxy_url = f"http://127.0.0.1:{port}/v1"

    logger.info("=" * 62)
    logger.info("CoordBench  framework=%s  model=%s  tasks=%d  quick=%s",
                framework, model, len(tasks), quick_mode)
    logger.info("=" * 62)

    proxy_proc = start_proxy(port)
    if not wait_for_proxy(port):
        proxy_proc.kill()
        raise RuntimeError(
            f"Proxy failed to start on port {port}. "
            "Ensure uvicorn is installed and the 'harness' package is importable."
        )

    task_results: List[Dict[str, Any]] = []
    run_ts = time.strftime("%Y%m%d_%H%M%S")

    try:
        for idx, task_def in enumerate(tasks):
            task_id   = task_def.get("id", f"task_{idx}")
            task_type = task_def.get("_task_type", "unknown")
            run_id    = (
                f"{framework}_{model.replace('/', '_').replace(':', '_')}"
                f"_{task_id}_{uuid.uuid4().hex[:8]}"
            )

            msg = f"[{idx + 1}/{len(tasks)}] {task_id} ({task_type})"
            logger.info(msg)
            if progress_callback:
                progress_callback(idx, len(tasks), msg)

            # Tell the proxy which run_id to use — needed for frameworks whose
            # HTTP clients don't forward custom headers (e.g. AutoGen).
            try:
                import urllib.request
                req = urllib.request.Request(
                    f"http://127.0.0.1:{port}/admin/run/{run_id}",
                    method="PUT",
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception as _e:
                logger.warning("Could not set proxy run_id: %s", _e)

            run_result = run_single_task(task_def, framework, model, proxy_url, run_id)
            time.sleep(0.8)   # let proxy flush transcript to disk

            transcript_path = TRANSCRIPT_DIR / f"{run_id}.jsonl"
            eval_result = evaluate_transcript(
                transcript_path,
                task_def,
                run_result.get("final_answer", ""),
                quick_mode,
            )

            task_rec: Dict[str, Any] = {
                "task_id":   task_id,
                "task_type": task_type,
                "run_id":    run_id,
                "framework": framework,
                "model":     model,
                "elapsed_s": round(run_result.get("elapsed_s", 0.0), 2),
                "run_error": run_result.get("error"),
                **eval_result,
            }
            task_results.append(task_rec)

            status = "SUCCESS" if eval_result["task_success"] else "FAIL"
            logger.info(
                "  → %s | turns=%d | tokens=%d | failures=%s",
                status,
                eval_result["turns"],
                eval_result["total_tokens"],
                eval_result["failure_modes"] or "none",
            )

    finally:
        proxy_proc.terminate()
        try:
            proxy_proc.wait(timeout=5)
        except Exception:
            proxy_proc.kill()

    # ── Aggregate ─────────────────────────────────────────────────────────
    total     = len(task_results)
    successes = sum(1 for r in task_results if r["task_success"])

    failure_mode_counts: Dict[str, int] = {}
    for rec in task_results:
        for fm in rec.get("failure_modes", []):
            failure_mode_counts[fm] = failure_mode_counts.get(fm, 0) + 1

    def _avg(key: str) -> float:
        vals = [r.get(key, 0) for r in task_results]
        return sum(vals) / max(1, len(vals))

    avg_talk_action = (
        sum(r.get("coordination_cost", {}).get("talk_to_action_ratio", 0.0)
            for r in task_results)
        / max(1, total)
    )

    aggregated: Dict[str, Any] = {
        "framework":               framework,
        "model":                   model,
        "timestamp":               run_ts,
        "quick_mode":              quick_mode,
        "total_tasks":             total,
        "tasks_succeeded":         successes,
        "tasks_failed":            total - successes,
        "success_rate":            round(successes / max(1, total), 4),
        "avg_turns":               round(_avg("turns"), 2),
        "avg_total_tokens":        round(_avg("total_tokens"), 0),
        "avg_latency_ms":          round(_avg("latency_ms"), 0),
        "avg_elapsed_s":           round(_avg("elapsed_s"), 2),
        "avg_talk_to_action_ratio": round(avg_talk_action, 4),
        "failure_mode_counts":     failure_mode_counts,
        "task_results":            task_results,
    }

    model_slug = model.replace("/", "_").replace(":", "_")
    out_path   = RESULTS_DIR / f"{framework}_{model_slug}_{run_ts}.json"
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(aggregated, fh, indent=2, default=str)

    logger.info("=" * 62)
    logger.info(
        "DONE  success=%d/%d (%.0f%%)  saved → %s",
        successes, total, aggregated["success_rate"] * 100, out_path.name,
    )
    logger.info("=" * 62)

    if progress_callback:
        progress_callback(total, total, "Complete")

    return aggregated

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cli() -> None:
    parser = argparse.ArgumentParser(
        description="CoordBench — run the full benchmark for one framework × model.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--framework", required=True,
                        choices=["autogen", "crewai", "langgraph"])
    parser.add_argument("--model", default="gpt-4o",
                        help="Model name for OpenRouter (e.g. gpt-4o, anthropic/claude-3-5-sonnet)")
    parser.add_argument("--task-types", nargs="+", default=ALL_TASK_TYPES,
                        choices=ALL_TASK_TYPES, metavar="TYPE")
    parser.add_argument("--full-eval", action="store_true",
                        help="Use all 19 detectors incl. LLM judges (slow, ~60s/task)")
    args = parser.parse_args()

    results = run_benchmark(
        framework=args.framework,
        model=args.model,
        task_types=args.task_types,
        quick_mode=not args.full_eval,
    )

    print(f"\n{'=' * 60}")
    print(f"  CoordBench Results — {args.framework} × {args.model}")
    print(f"{'=' * 60}")
    print(f"  Success rate  : {results['tasks_succeeded']}/{results['total_tasks']} "
          f"({results['success_rate'] * 100:.1f}%)")
    print(f"  Avg turns     : {results['avg_turns']:.1f}")
    print(f"  Avg tokens    : {results['avg_total_tokens']:.0f}")
    print(f"  Failure modes : {results['failure_mode_counts']}")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    _cli()