import json
import logging
import re
from typing import Any

logger = logging.getLogger("DebateDeliberationEval")


def extract_json(text: str) -> Any:
    match = re.search(r'```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```', text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    try:
        start_idx = text.find('{')
        end_idx = text.rfind('}') + 1
        if start_idx != -1 and end_idx != -1:
            return json.loads(text[start_idx:end_idx])
    except json.JSONDecodeError:
        pass
    return None


def evaluate(ground_truth: Any, final_answer: str, eval_type: str = "exact_match") -> bool:
    """
    Evaluates Debate/Deliberation tasks.

    All dd_ tasks use exact_match: the parsed JSON output must equal the
    ground_truth dict exactly (including nested lists and numeric fields).
    """
    parsed_answer = extract_json(final_answer)
    if parsed_answer is None:
        logger.error("Could not parse JSON from final answer")
        return False

    return parsed_answer == ground_truth
