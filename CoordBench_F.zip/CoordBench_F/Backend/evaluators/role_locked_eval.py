import json
import logging
import re
from typing import Any

logger = logging.getLogger("RoleLockedEval")


def extract_json(text: str) -> Any:
    match = re.search(r'```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```', text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    try:
        start_idx = text.find('{')
        end_idx = text.rfind('}') + 1
        if start_idx != -1 and end_idx != -1:
            return json.loads(text[start_idx:end_idx])
    except json.JSONDecodeError:
        pass
    return None


def evaluate(ground_truth: Any, final_answer: str, eval_type: str = "exact_match") -> bool:
    """
    Evaluates Role Locked tasks.

    eval_type options:
      - exact_match: parsed JSON must equal ground_truth exactly
      - ordered_list_and_exact_match: dict fields compared exactly; list fields
        compared in order (Python == already enforces this, so same as exact_match)
    """
    parsed_answer = extract_json(final_answer)
    if parsed_answer is None:
        logger.error("Could not parse JSON from final answer")
        return False

    if eval_type in ("exact_match", "ordered_list_and_exact_match"):
        return parsed_answer == ground_truth

    logger.warning(f"Unknown eval_type '{eval_type}', falling back to exact_match")
    return parsed_answer == ground_truth
