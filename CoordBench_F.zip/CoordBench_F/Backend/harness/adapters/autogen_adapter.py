"""
AutoGen adapter — supports both the legacy pyautogen 0.2.x API and the modern
autogen-agentchat 0.4.x API.  The right implementation is selected at import time.
"""
import asyncio
import logging
from typing import Any, Dict, List, Union

from .base_adapter import BaseAdapter

logger = logging.getLogger("AutoGenAdapter")

# ---------------------------------------------------------------------------
# Detect which autogen API is available
# ---------------------------------------------------------------------------
try:
    # Modern autogen-agentchat 0.4+
    from autogen_agentchat.agents import AssistantAgent as AGAssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat
    from autogen_ext.models.openai import OpenAIChatCompletionClient
    _AUTOGEN_NEW = True
    logger.info("Using autogen-agentchat 0.4+ (modern) API")
except ImportError:
    _AUTOGEN_NEW = False

try:
    if not _AUTOGEN_NEW:
        # Legacy pyautogen 0.2.x
        import autogen as _ag
        _AUTOGEN_LEGACY = True
        logger.info("Using pyautogen 0.2.x (legacy) API")
    else:
        _AUTOGEN_LEGACY = False
except ImportError:
    _AUTOGEN_LEGACY = False


# ── Modern adapter (autogen-agentchat 0.4+) ──────────────────────────────

class _NewAutoGenAdapter(BaseAdapter):
    """
    Uses autogen_agentchat 0.4+ with a RoundRobinGroupChat and an
    OpenAI-compatible model client pointed at the interceptor proxy.
    """

    def __init__(self, model_name: str, proxy_url: str, run_id: str = "default"):
        super().__init__(model_name, proxy_url, run_id)
        self._agents: List[Any] = []
        self._team: Any = None

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        from autogen_agentchat.agents import AssistantAgent as AGAssistantAgent
        from autogen_agentchat.teams import RoundRobinGroupChat
        from autogen_ext.models.openai import OpenAIChatCompletionClient

        agent_contexts = task_def.get("agent_contexts", {})
        isolation_note = (
            "\n\nIMPORTANT: Your memory is ISOLATED from other agents. "
            "To pass information, address another agent explicitly: '@agent_name Your message.'\n"
            "When your section of the task is fully complete (no placeholders), output 'TERMINATE'."
        )

        self._agents = []
        for agent_name, context in agent_contexts.items():
            client = OpenAIChatCompletionClient(
                model=self.model_name,
                base_url=self.proxy_url,
                api_key="dummy",
                extra_headers={
                    "x-mac-agent-name": agent_name,
                    "x-mac-run-id": self.run_id,
                },
            )
            agent = AGAssistantAgent(
                name=agent_name,
                model_client=client,
                system_message=context + isolation_note,
            )
            self._agents.append(agent)

        self._team = RoundRobinGroupChat(
            self._agents,
            max_turns=20,
            termination_condition=None,   # agents self-terminate with TERMINATE
        )

    def run_task(self, task_def: Dict[str, Any]) -> str:
        if not self._team:
            raise ValueError("Agents not setup.")

        question = task_def.get("question", "Solve the task.")

        async def _run():
            result = await self._team.run(task=question)
            # Extract last message content
            if result and result.messages:
                for msg in reversed(result.messages):
                    content = getattr(msg, "content", "") or ""
                    if content and "TERMINATE" not in content:
                        return content
            return ""

        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    future = pool.submit(asyncio.run, _run())
                    return future.result(timeout=300)
            else:
                return loop.run_until_complete(_run())
        except Exception:
            return asyncio.run(_run())


# ── Legacy adapter (pyautogen 0.2.x) ─────────────────────────────────────

class _LegacyAutoGenAdapter(BaseAdapter):
    """Original pyautogen 0.2.x GroupChat implementation."""

    def __init__(self, model_name: str, proxy_url: str, run_id: str = "default"):
        super().__init__(model_name, proxy_url, run_id)
        self.agents = []
        self.user_proxy = None
        self.llm_config = {
            "config_list": [{
                "model":    self.model_name,
                "base_url": self.proxy_url,
                "api_key":  "dummy",
            }],
            "temperature": 0.0,
        }

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        import autogen as _ag

        agent_contexts = task_def.get("agent_contexts", {})
        self.agents = []
        interrupt_prompt = (
            "\n\nCRITICAL: Memory is partitioned. Agents DO NOT see your messages by default. "
            "Address others explicitly with '@<AgentName>'. "
            "When the task is solved, output 'TERMINATE'."
        )
        for agent_name, system_message in agent_contexts.items():
            cfg = {
                "config_list": [{
                    **self.llm_config["config_list"][0],
                    "default_headers": {
                        "x-mac-agent-name": agent_name,
                        "x-mac-run-id": self.run_id,
                    },
                }],
                "temperature": 0.0,
            }
            agent = _ag.AssistantAgent(
                name=agent_name,
                system_message=system_message + interrupt_prompt,
                llm_config=cfg,
            )
            self.agents.append(agent)

        self.user_proxy = _ag.UserProxyAgent(
            name="orchestrator",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=15,
            is_termination_msg=lambda x: "TERMINATE" in x.get("content", ""),
            code_execution_config=False,
        )

    def run_task(self, task_def: Dict[str, Any]) -> str:
        import autogen as _ag

        if not self.agents or not self.user_proxy:
            raise ValueError("Agents not setup.")

        question = task_def.get("question", "Solve the task.")

        class _PartitionedGCM(_ag.GroupChatManager):
            def send(self_inner, message: Union[Dict, str], recipient: _ag.Agent,
                     request_reply: bool = None, silent: bool = False):
                content = message.get("content", "") if isinstance(message, dict) else str(message)
                if recipient.name == "orchestrator":
                    super().send(message, recipient, request_reply, silent)
                    return
                if len(self_inner.groupchat.messages) <= 1 or f"@{recipient.name}" in content:
                    super().send(message, recipient, request_reply, silent)

        groupchat = _ag.GroupChat(
            agents=[self.user_proxy] + self.agents,
            messages=[],
            max_round=20,
            speaker_selection_method="auto",
        )
        manager = _PartitionedGCM(groupchat=groupchat, llm_config=self.llm_config)
        self.user_proxy.initiate_chat(manager, message=question)

        history = self.user_proxy.chat_messages[manager]
        for msg in reversed(history):
            if msg.get("content") and "TERMINATE" not in msg.get("content", ""):
                return msg.get("content")
        return ""


# ── Public class — picks the right implementation ─────────────────────────

class AutoGenAdapter(
    _NewAutoGenAdapter if _AUTOGEN_NEW else
    (_LegacyAutoGenAdapter if _AUTOGEN_LEGACY else BaseAdapter)
):
    """
    AutoGen adapter.  Automatically uses the available autogen library:
      - autogen-agentchat 0.4+ (modern, preferred)
      - pyautogen 0.2.x      (legacy fallback)
    Raises ImportError at instantiation if neither is installed.
    """
    def __init__(self, model_name: str, proxy_url: str, run_id: str = "default"):
        if not _AUTOGEN_NEW and not _AUTOGEN_LEGACY:
            raise ImportError(
                "No autogen library found. Install one of:\n"
                "  pip install autogen-agentchat autogen-ext[openai]\n"
                "  pip install pyautogen>=0.2.0b1"
            )
        super().__init__(model_name, proxy_url, run_id)

    # If neither library is present, provide stubs so the class is importable
    if not _AUTOGEN_NEW and not _AUTOGEN_LEGACY:
        def setup_agents(self, task_def):
            raise ImportError("No autogen library installed.")

        def run_task(self, task_def):
            raise ImportError("No autogen library installed.")