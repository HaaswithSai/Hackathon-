import abc
from typing import Dict, Any

class BaseAdapter(abc.ABC):
    """
    Abstract base class for all framework adapters.
    Adapters are responsible for taking a MAC-Bench task definition,
    translating it into the framework's native agent abstractions,
    and executing the run.
    """

    def __init__(self, model_name: str, proxy_url: str, run_id: str = "default"):
        """
        :param model_name: The name of the LLM to use (e.g., 'gpt-4o', 'claude-3-opus-20240229')
        :param proxy_url: The URL of the MAC-Bench interceptor proxy to route traffic through
        :param run_id: Unique run identifier forwarded to the proxy via x-mac-run-id header
        """
        self.model_name = model_name
        self.proxy_url = proxy_url
        self.run_id = run_id

    @abc.abstractmethod
    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        """
        Initialize the framework's agents based on the agent_contexts in the task definition.
        """
        pass

    @abc.abstractmethod
    def run_task(self, task_def: Dict[str, Any]) -> str:
        """
        Execute the multi-agent conversation to solve the task.
        :param task_def: The full task JSON payload.
        :return: The final answer extracted from the framework's output.
        """
        pass
