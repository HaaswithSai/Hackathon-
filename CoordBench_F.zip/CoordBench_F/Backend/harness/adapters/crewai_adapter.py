import os
from typing import Dict, Any
from crewai import Agent, Task, Crew, Process
from langchain_openai import ChatOpenAI
from .base_adapter import BaseAdapter

class CrewAIAdapter(BaseAdapter):
    def __init__(self, model_name: str, proxy_url: str, run_id: str = "default"):
        super().__init__(model_name, proxy_url, run_id)
        self.crew = None
        
        # Configure LiteLLM/LangChain to point to our proxy
        self.llm = ChatOpenAI(
            model_name=self.model_name,
            openai_api_base=self.proxy_url,
            openai_api_key="dummy",
            temperature=0.0,
            default_headers={"x-mac-run-id": self.run_id},
        )

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        agent_contexts = task_def.get("agent_contexts", {})
        question = task_def.get("question", "Solve the task.")
        agent_items = list(agent_contexts.items())

        crew_agents = []
        for agent_name, context in agent_items:
            agent = Agent(
                role=agent_name,
                goal="Complete only the part of the task that falls within your designated role.",
                backstory=context,
                verbose=True,
                allow_delegation=False,
                llm=self.llm,
            )
            crew_agents.append(agent)

        # One task per agent. Each task receives the outputs of all prior tasks as
        # context so agents build on each other's work rather than working in isolation.
        tasks = []
        for i, (agent_name, _) in enumerate(agent_items):
            if i == 0:
                description = (
                    f"{question}\n\n"
                    "Complete only the part of this task that falls within your designated role."
                )
            else:
                description = (
                    "Review the work completed by the agents before you and contribute "
                    "only the part of the task that falls within your designated role. "
                    "Do not repeat work already done."
                )
            task = Task(
                description=description,
                expected_output="Your role's specific contribution to the final answer.",
                agent=crew_agents[i],
                context=list(tasks),
            )
            tasks.append(task)

        # Final synthesis task: the last agent assembles all contributions into
        # the exact output format requested by the question.
        agent_names = [name for name, _ in agent_items]
        synthesis_task = Task(
            description=(
                f"Synthesize the contributions from all agents ({', '.join(agent_names)}) "
                f"into the complete final answer for:\n{question}\n\n"
                "Output ONLY the final answer in the exact format specified by the question."
            ),
            expected_output="The complete synthesized final answer in the exact requested format.",
            agent=crew_agents[-1],
            context=list(tasks),
        )
        tasks.append(synthesis_task)

        self.crew = Crew(
            agents=crew_agents,
            tasks=tasks,
            process=Process.sequential,
            verbose=True,
        )

    def run_task(self, task_def: Dict[str, Any]) -> str:
        if not self.crew:
            raise ValueError("Crew not setup.")
            
        result = self.crew.kickoff()
        return str(result)
