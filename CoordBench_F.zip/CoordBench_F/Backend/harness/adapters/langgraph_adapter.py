import logging
from typing import Dict, Any, List, TypedDict

logger = logging.getLogger("LangGraphAdapter")

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, AIMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from .base_adapter import BaseAdapter

MAX_TURNS = 20
_RECURSION_LIMIT = MAX_TURNS * 2 + 10


class AgentState(TypedDict):
    agent_memories: Dict[str, List[BaseMessage]]
    current_agent: str
    final_answer: str
    routing_history: List[str]
    # Supervisor-only turn summaries for routing; capped so it never grows unbounded.
    supervisor_log: List[Dict[str, str]]
    turn_count: int
    agents_spoken: List[str]


class LangGraphAdapter(BaseAdapter):
    def __init__(self, model_name: str, proxy_url: str, run_id: str = "default"):
        super().__init__(model_name, proxy_url, run_id)
        self.graph = None
        self.agent_names = []

    def _make_llm(self, agent_name: str) -> ChatOpenAI:
        return ChatOpenAI(
            model_name=self.model_name,
            openai_api_base=self.proxy_url,
            openai_api_key="dummy",
            temperature=0.0,
            default_headers={
                "x-mac-agent-name": agent_name,
                "x-mac-run-id": self.run_id,
            },
        )

    def setup_agents(self, task_def: Dict[str, Any]) -> None:
        agent_contexts = task_def.get("agent_contexts", {})
        task_question = task_def.get("question", "")
        self.agent_names = list(agent_contexts.keys())

        supervisor_llm = self._make_llm("supervisor")
        agent_llms = {name: self._make_llm(name) for name in self.agent_names}

        workflow = StateGraph(AgentState)

        def _synthesize(agent_memories: dict) -> str:
            logger.info("[supervisor] Synthesizing final answer...")
            contributions = "\n\n".join(
                f"=== {name} ===\n{mem[-1].content}"
                for name, mem in agent_memories.items()
                if mem and isinstance(mem[-1], AIMessage)
            )
            compile_msg = (
                f"Task: {task_question}\n\n"
                "The agents below have each completed their section:\n\n"
                f"{contributions}\n\n"
                "Combine their outputs into ONE complete final answer in the EXACT "
                "output format specified by the task. Output ONLY the answer."
            )
            try:
                return supervisor_llm.invoke([HumanMessage(content=compile_msg)]).content
            except Exception:
                return contributions

        def supervisor_node(state: AgentState):
            turn = state.get("turn_count", 0)
            agents_spoken = state.get("agents_spoken", [])
            all_spoken = set(agents_spoken) >= set(self.agent_names)

            def _finish():
                return {
                    "current_agent": "FINISH",
                    "final_answer": _synthesize(state["agent_memories"]),
                    "turn_count": turn,
                }

            if all_spoken:
                for memory in state["agent_memories"].values():
                    if memory and isinstance(memory[-1], AIMessage) and \
                            "TERMINATE" in memory[-1].content:
                        return _finish()

            if turn >= MAX_TURNS:
                return _finish()

            sup_log = state.get("supervisor_log", [])
            history_str = " -> ".join(state.get("routing_history", []))
            log_str = "\n".join(f"{e['agent']}: {e['summary']}" for e in sup_log)
            sys_prompt = (
                f"You are a supervisor coordinating these agents: {self.agent_names}.\n"
                "Agents have ISOLATED memories — they only know what has been explicitly "
                "@addressed to them. They do NOT automatically see other agents' work.\n"
                "Select the next agent to speak so that dependencies are resolved in order.\n"
                "Output ONLY the exact agent name."
            )
            user_prompt = (
                f"Routing history: {history_str if history_str else 'Start'}\n"
                f"Recent activity:\n{log_str if log_str else 'None yet'}\n"
                "Who should speak next?"
            )
            try:
                response = supervisor_llm.invoke([
                    SystemMessage(content=sys_prompt),
                    HumanMessage(content=user_prompt),
                ])
                next_agent = response.content.strip()
                if next_agent not in self.agent_names:
                    next_agent = self.agent_names[0]
            except Exception:
                next_agent = self.agent_names[0]

            logger.info("[supervisor] Routing to: %s (turn %d)", next_agent, turn + 1)
            return {
                "current_agent": next_agent,
                "routing_history": state.get("routing_history", []) + [next_agent],
                "turn_count": turn + 1,
            }

        for agent_name, context in agent_contexts.items():
            llm = agent_llms[agent_name]

            def agent_node(
                state: AgentState,
                name=agent_name,
                ctx=context,
                agent_llm=llm,
            ):
                logger.info("[%s] Speaking...", name)
                memories = state.get("agent_memories", {}).copy()
                my_memory = list(memories.get(name, []))

                isolation_instruction = (
                    "\n\nIMPORTANT: Your memory is ISOLATED. You only know what has been "
                    "explicitly sent to you. To share your output with another agent, "
                    "address them directly: '@agent_name Your message here'.\n"
                    "End your message with 'TERMINATE' ONLY when your section is fully "
                    "complete with real values (no placeholders like 'TBD')."
                )
                response = agent_llm.invoke(
                    [SystemMessage(content=ctx + isolation_instruction)] + my_memory
                )

                logger.info("[%s] Done. TERMINATE=%s", name, "TERMINATE" in response.content)

                memories[name] = my_memory + [AIMessage(content=response.content)]

                for other in self.agent_names:
                    if other != name and f"@{other}" in response.content:
                        other_mem = list(memories.get(other, []))
                        other_mem.append(
                            HumanMessage(content=f"Message from {name}: {response.content}")
                        )
                        memories[other] = other_mem
                        logger.info("[%s] -> cross-talk delivered to %s", name, other)

                # Keep only the last 6 summaries — supervisor never reads further back.
                sup_log = state.get("supervisor_log", [])[-5:] + [{
                    "agent": name,
                    "summary": response.content[:120].replace("\n", " "),
                }]

                agents_spoken = list(state.get("agents_spoken", []))
                if name not in agents_spoken:
                    agents_spoken.append(name)

                return {
                    "agent_memories": memories,
                    "supervisor_log": sup_log,
                    "agents_spoken": agents_spoken,
                }

            workflow.add_node(agent_name, agent_node)
            workflow.add_edge(agent_name, "supervisor")

        workflow.add_node("supervisor", supervisor_node)

        def route(state: AgentState):
            if state["current_agent"] == "FINISH":
                return END
            return state["current_agent"]

        workflow.add_conditional_edges("supervisor", route)
        workflow.set_entry_point("supervisor")
        self.graph = workflow.compile()

    def run_task(self, task_def: Dict[str, Any]) -> str:
        if not self.graph:
            raise ValueError("Graph not setup.")

        question = task_def.get("question", "Solve the task.")
        initial_state = {
            "agent_memories": {
                name: [HumanMessage(content=question)] for name in self.agent_names
            },
            "current_agent": "",
            "final_answer": "",
            "routing_history": [],
            "supervisor_log": [],
            "turn_count": 0,
            "agents_spoken": [],
        }
        final_state = self.graph.invoke(
            initial_state, {"recursion_limit": _RECURSION_LIMIT}
        )
        return final_state.get("final_answer", "")
