"""
MAC-Bench aggregator.
Runs all 19 detectors, applies confidence-merging rules, and produces the final
MAST label set for a transcript.
"""
import json
import os
import sys
import time
from typing import Any, Dict, List

from .programmatic.loop_detector import run as loop_run
from .programmatic.termination_detector import run as termination_run
from .programmatic.context_degradation import run as context_degradation_run
from .programmatic.task_disobedience import run as task_disobedience_run
from .programmatic.coordination_overhead import run as coordination_overhead_run

from .llm_judge.echo_chamber import run as echo_chamber_run
from .llm_judge.sycophantic_convergence import run as sycophantic_convergence_run
from .llm_judge.agent_dominance import run as agent_dominance_llm_run
from .llm_judge.role_drift import run as role_drift_run
from .llm_judge.info_siloing import run as info_siloing_run
from .llm_judge.reasoning_action_mismatch import run as reasoning_action_mismatch_run
from .llm_judge.unresolved_conflict import run as unresolved_conflict_run
from .llm_judge.superficial_verification import run as superficial_verification_run
from .llm_judge.incorrect_verification import run as incorrect_verification_run
from .llm_judge.role_rigidity import run as role_rigidity_run
from .llm_judge.credit_assignment_ambiguity import run as credit_assignment_ambiguity_run

from .rule_detectors.handoff_corruption import run as handoff_corruption_run
from .rule_detectors.stagnation import run as stagnation_run
from .rule_detectors.dominance import run as dominance_run

from .utils.transcript_loader import load_transcript


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_run(name: str, fn, path: str) -> Dict[str, Any]:
    try:
        result = fn(path)
        if not isinstance(result, dict):
            result = {"detected": bool(result)}
        return result
    except Exception as exc:
        return {"detected": False, "error": f"{name}: {exc}"}


def _detected(result: Dict[str, Any]) -> bool:
    return bool(result.get("detected", False))


def _confidence(result: Dict[str, Any], default: float = 0.7) -> float:
    return float(result.get("confidence", default))


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(transcript_path: str, task_success: bool = False) -> Dict[str, Any]:
    """
    Run all 19 detectors against transcript_path and return the aggregated report.

    Args:
        transcript_path: Path to the .jsonl transcript file.
        task_success: Whether the task was solved (passed in from the evaluator,
                      since it is never written into the transcript itself).
    """
    transcript_id = os.path.splitext(os.path.basename(transcript_path))[0]

    try:
        turns = load_transcript(transcript_path)
        total_turns = len([t for t in turns if (t.get("turn") or 0) > 0])
    except Exception:
        total_turns = 0

    # ------------------------------------------------------------------
    # Run every detector
    # ------------------------------------------------------------------
    raw: Dict[str, Dict[str, Any]] = {}

    raw["loop"] = _safe_run("loop", loop_run, transcript_path)
    raw["termination"] = _safe_run("termination", termination_run, transcript_path)
    raw["context_degradation"] = _safe_run("context_degradation", context_degradation_run, transcript_path)
    raw["task_disobedience"] = _safe_run("task_disobedience", task_disobedience_run, transcript_path)
    raw["coordination_overhead"] = _safe_run("coordination_overhead", coordination_overhead_run, transcript_path)

    _JUDGE_DELAY = 5  # seconds between LLM judge calls to avoid rate limits

    raw["echo_chamber"] = _safe_run("echo_chamber", echo_chamber_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["sycophantic_convergence"] = _safe_run("sycophantic_convergence", sycophantic_convergence_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["agent_dominance_llm"] = _safe_run("agent_dominance_llm", agent_dominance_llm_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["role_drift"] = _safe_run("role_drift", role_drift_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["info_siloing"] = _safe_run("info_siloing", info_siloing_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["reasoning_action_mismatch"] = _safe_run("reasoning_action_mismatch", reasoning_action_mismatch_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["unresolved_conflict"] = _safe_run("unresolved_conflict", unresolved_conflict_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["superficial_verification"] = _safe_run("superficial_verification", superficial_verification_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["incorrect_verification"] = _safe_run("incorrect_verification", incorrect_verification_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["role_rigidity"] = _safe_run("role_rigidity", role_rigidity_run, transcript_path); time.sleep(_JUDGE_DELAY)
    raw["credit_assignment_ambiguity"] = _safe_run("credit_assignment_ambiguity", credit_assignment_ambiguity_run, transcript_path)

    raw["handoff_corruption"] = _safe_run("handoff_corruption", handoff_corruption_run, transcript_path)
    raw["stagnation"] = _safe_run("stagnation", stagnation_run, transcript_path)
    raw["dominance_rule"] = _safe_run("dominance_rule", dominance_run, transcript_path)

    # ------------------------------------------------------------------
    # Coordination cost from the overhead detector
    # ------------------------------------------------------------------
    overhead = raw["coordination_overhead"]
    coordination_cost = {
        "total_turns": total_turns,
        "talk_to_action_ratio": overhead.get("talk_to_action_ratio", 0.0),
        "token_overhead_ratio": overhead.get("token_overhead_ratio", 0.0),
    }

    # ------------------------------------------------------------------
    # Confidence merging rules
    # ------------------------------------------------------------------
    high_confidence: List[str] = []
    medium_confidence: List[str] = []

    def _add(label: str, high: bool):
        if high:
            if label not in high_confidence:
                high_confidence.append(label)
        else:
            if label not in medium_confidence and label not in high_confidence:
                medium_confidence.append(label)

    # Rule 1: programmatic + LLM judge both flag → high confidence
    # Rule 2: only LLM judge flags → medium confidence

    # Loop (programmatic only)
    if _detected(raw["loop"]):
        _add("loop", True)

    # Stagnation (rule detector, extends loop concept)
    if _detected(raw["stagnation"]):
        _add("stagnation", True)

    # Termination failures
    term = raw["termination"]
    if term.get("premature_termination"):
        _add("premature_termination", True)
    if term.get("termination_blindness"):
        _add("termination_blindness", True)

    # Context degradation
    if _detected(raw["context_degradation"]):
        _add("context_degradation", True)

    # Task disobedience
    if _detected(raw["task_disobedience"]):
        _add("task_disobedience", True)

    # Coordination overhead
    if _detected(raw["coordination_overhead"]):
        _add("coordination_overhead", True)

    # Echo chamber: LLM only → medium; override if fast success
    if _detected(raw["echo_chamber"]):
        # Rule: if task_success=True AND resolved in < 5 turns → override false positive
        if task_success and total_turns < 5:
            pass  # genuine fast consensus — do not flag
        else:
            _add("echo_chamber", False)  # medium (LLM only, no programmatic cross-check)

    # Sycophantic convergence (LLM only)
    if _detected(raw["sycophantic_convergence"]):
        _add("sycophantic_convergence", False)

    # Agent dominance: LLM judge AND rule detector → high confidence
    if _detected(raw["agent_dominance_llm"]) and _detected(raw["dominance_rule"]):
        _add("agent_dominance", True)
    elif _detected(raw["agent_dominance_llm"]):
        _add("agent_dominance", False)
    elif _detected(raw["dominance_rule"]):
        _add("agent_dominance", False)

    # Role drift (LLM only)
    if _detected(raw["role_drift"]):
        _add("role_drift", False)

    # Info siloing (LLM only)
    if _detected(raw["info_siloing"]):
        _add("info_siloing", False)

    # Reasoning-action mismatch (LLM only)
    if _detected(raw["reasoning_action_mismatch"]):
        _add("reasoning_action_mismatch", False)

    # Unresolved conflict (LLM only)
    if _detected(raw["unresolved_conflict"]):
        _add("unresolved_conflict", False)

    # Superficial verification (LLM only)
    if _detected(raw["superficial_verification"]):
        _add("superficial_verification", False)

    # Incorrect verification (LLM only)
    if _detected(raw["incorrect_verification"]):
        _add("incorrect_verification", False)

    # Role rigidity (LLM only)
    if _detected(raw["role_rigidity"]):
        _add("role_rigidity", False)

    # Credit assignment ambiguity (LLM only, only when task failed)
    if _detected(raw["credit_assignment_ambiguity"]):
        _add("credit_assignment_ambiguity", False)

    # Handoff corruption (rule detector with fuzzy matching)
    if _detected(raw["handoff_corruption"]):
        _add("handoff_corruption", True)

    # ------------------------------------------------------------------
    # Final label set = union of high + medium
    # ------------------------------------------------------------------
    failure_modes_detected = list(dict.fromkeys(high_confidence + medium_confidence))

    return {
        "transcript_id": transcript_id,
        "task_success": task_success,
        "failure_modes_detected": failure_modes_detected,
        "high_confidence": high_confidence,
        "medium_confidence": medium_confidence,
        "coordination_cost": coordination_cost,
        "per_detector_raw": raw,
    }


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    result = run(path)
    print(json.dumps(result, indent=2, default=str))
