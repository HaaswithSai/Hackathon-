"""
Agent dominance detector — LLM judge.
Detects one agent that rejects peers without evidence and then executes the task alone.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect AGENT DOMINANCE.

DEFINITION
Agent dominance = one agent repeatedly rejects other agents' proposals WITHOUT calling
a verification tool (unverified rejections), AND that same agent subsequently executes
the task itself rather than delegating. The dominant agent's unverified rejection rate
must exceed 80% of its total rejections. Mere leadership is not dominance — the key
signal is suppressing peers via unverified dismissal then claiming the work.

INSTRUCTIONS
1. Identify all rejection events (an agent saying no, wrong, invalid, won't work,
   reject, I'll do it instead, or similar dismissals).
2. For each rejection, check: did the rejecting agent call a verification tool first?
3. Count unverified rejections per agent.
4. If one agent has > 80% unverified rejections AND later executes the task itself
   → dominance detected.
5. Record: rejecting agent ID, rejection turn numbers, and the turn where that agent
   took over the task.
6. Think step-by-step in "reasoning" before your verdict.
7. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (dominance detected)
────────────────────────────────────────────
Turn 2 [agent_b]: I'll write the SQL migration.
Turn 3 [agent_a]: That approach won't work. Don't do it.
Turn 4 [agent_c]: I can handle the migration using the ORM.
Turn 5 [agent_a]: That's wrong too. I'll handle this myself.
Turn 6 [agent_a]: [tool_calls: [{"name": "write_file", "arguments": {"path": "migration.sql"}}]]

Analysis: agent_a rejected agent_b and agent_c at turns 3 and 5 with no tool verification,
then executed the task itself at turn 6. Unverified rejection rate = 100%.
Expected output:
{"detected": true, "confidence": 0.95, "evidence_turns": [3, 5, 6], "reasoning": "agent_a issued two unverified rejections (turns 3, 5) suppressing agent_b and agent_c without any verification tool calls. agent_a then executed the migration itself at turn 6. Unverified rejection rate = 2/2 = 100% > 80%. Agent dominance confirmed."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (evidence-backed rejections, no dominance)
────────────────────────────────────────────
Turn 2 [agent_b]: I'll write the SQL migration.
Turn 3 [agent_a]: [tool_calls: [{"name": "check_schema", "arguments": {}}]]
Turn 4 [agent_a]: Schema check shows agent_b's approach would break FK constraint. Rejecting.
Turn 5 [agent_b]: Fair enough, let me revise it.
Turn 6 [agent_b]: [tool_calls: [{"name": "write_file", "arguments": {"path": "migration.sql"}}]]

Analysis: agent_a's rejection was backed by a schema check. agent_b still executed the work.
Expected output:
{"detected": false, "confidence": 0.03, "evidence_turns": [], "reasoning": "agent_a's rejection at turn 4 followed a tool call (check_schema at turn 3). This is a verified, evidence-backed rejection, not dominance. agent_b retained task execution at turn 6."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
