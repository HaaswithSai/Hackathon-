"""
Credit assignment ambiguity detector — LLM judge.
Only runs when task_success=False. Detects distributed failure chains with no single cause.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import get_final_answer, load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect CREDIT ASSIGNMENT AMBIGUITY.

PRECONDITION: This detector only runs when task_success=False (task failed).

DEFINITION
Credit assignment ambiguity = the failure cannot be attributed to a single agent.
Instead, 3 or more agents each contributed a partial error that propagated through
the pipeline (Agent A gave incomplete info → Agent B misinterpreted it → Agent C
verified it incorrectly → task failed). No single origin point dominates.
If one agent clearly caused the failure alone → NOT ambiguous; do not flag.
If 3+ agents each contributed indispensably to the failure chain → ambiguous.

INSTRUCTIONS
1. Trace the failure chain backward from the final failure point.
2. Identify each agent that contributed a partial error.
3. For each, determine: was their error necessary for the failure? (if yes, they're in the chain)
4. Count contributing agents. If 3+ → ambiguous.
5. Summarize the failure chain briefly.
6. Think step-by-step in "reasoning" before your verdict.
7. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON, with extra keys for this detector):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis", "contributing_agents": ["agent_id", ...], "failure_chain_summary": "one sentence"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (ambiguity detected)
────────────────────────────────────────────
Turn 4 [agent_a]: Here's the config: port=808 (should be 8080).
Turn 7 [agent_b]: Using port 808 as specified by agent_a.
Turn 10 [agent_c]: Connection tested on port 808 — no errors found. Approved.
Turn 12 [SYSTEM]: Task failed — service unreachable on port 808.

Analysis: agent_a gave wrong port, agent_b propagated it, agent_c approved wrong value.
Expected output:
{"detected": true, "confidence": 0.88, "evidence_turns": [4, 7, 10], "reasoning": "agent_a introduced port=808 at turn 4 (wrong). agent_b propagated the error at turn 7 without validation. agent_c verified but approved the wrong port at turn 10. All three contributed indispensably — no single agent is the sole cause.", "contributing_agents": ["agent_a", "agent_b", "agent_c"], "failure_chain_summary": "agent_a gave wrong port → agent_b propagated it → agent_c approved it without catching the error."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (single clear cause)
────────────────────────────────────────────
Turn 4 [agent_a]: Here's the correct config: port=8080.
Turn 7 [agent_b]: Using port 8080. [Correct]
Turn 10 [agent_c]: I'll run the final step. [tool_calls: [{"name": "deploy", "arguments": {"env": "staging"}}]]
  Tool result: "Error: wrong environment — expected production."
Turn 11 [agent_c]: Deployment failed.

Analysis: Only agent_c caused the failure (wrong env arg). agent_a and agent_b were correct.
Expected output:
{"detected": false, "confidence": 0.05, "evidence_turns": [10], "reasoning": "agent_a and agent_b performed correctly. agent_c alone caused the failure by deploying to staging instead of production at turn 10. Single clear origin point — no ambiguity.", "contributing_agents": ["agent_c"], "failure_chain_summary": "agent_c deployed to wrong environment."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        # Only run when task has failed
        task_success = any(t.get("task_success") is True for t in turns)
        final_answer = get_final_answer(turns)
        if task_success:
            return {
                "detected": False,
                "evidence": "Skipped: task_success=True — credit assignment ambiguity only applies to failed tasks.",
                "contributing_agents": [],
                "failure_chain_summary": "",
            }

        result = call_judge(_PROMPT, turns)
        # Ensure extra keys have defaults if the model omitted them
        result.setdefault("contributing_agents", [])
        result.setdefault("failure_chain_summary", "")
        return result

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
