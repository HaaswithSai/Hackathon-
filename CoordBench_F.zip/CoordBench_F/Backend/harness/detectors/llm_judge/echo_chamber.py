"""
Echo chamber detector — LLM judge.
Detects agents agreeing with proposals without any tool-based verification.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect ECHO CHAMBER CONVERGENCE.

DEFINITION
Echo chamber = Agent X proposes hypothesis H. Agent Y agrees using phrases like
"I agree", "exactly", "correct", "great point", "well reasoned", "absolutely",
"that makes sense" — WITHOUT first calling any tool to verify H.
GENUINE CONSENSUS = agreement that follows a verification tool call in the same or
immediately preceding turn. Do NOT flag genuine consensus.

INSTRUCTIONS
1. Read every turn carefully.
2. Identify all agreement events (Agent Y affirms Agent X's claim).
3. For each, check: did Agent Y call a verification tool before agreeing?
4. Think step-by-step in "reasoning" before giving your verdict.
5. Cite specific turn numbers in "evidence_turns".
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON, no extra keys):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (echo chamber detected)
────────────────────────────────────────────
Turn 3 [agent_a]: I believe the root cause is a memory leak in module X.
Turn 4 [agent_b]: I agree completely, module X is definitely the problem. Great analysis!
Turn 5 [agent_a]: Let's proceed with the fix.

Analysis: agent_b agreed at turn 4 without calling any diagnostic tool. Echo chamber detected.
Expected output:
{"detected": true, "confidence": 0.92, "evidence_turns": [4], "reasoning": "agent_b agreed at turn 4 with 'I agree completely' after agent_a's hypothesis at turn 3. agent_b made no tool call to verify the memory-leak claim before agreeing."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (genuine consensus, no echo chamber)
────────────────────────────────────────────
Turn 3 [agent_a]: I believe the root cause is a memory leak in module X.
Turn 4 [agent_b]: Let me verify. [tool_calls: [{"name": "run_profiler", "arguments": {"module": "X"}}]]
Turn 5 [agent_b]: Profiler confirms the leak. I agree with agent_a's diagnosis.
Turn 6 [agent_a]: Good, let's fix it.

Analysis: agent_b ran run_profiler before agreeing. Genuine consensus.
Expected output:
{"detected": false, "confidence": 0.05, "evidence_turns": [], "reasoning": "agent_b verified the claim at turn 4 using run_profiler before agreeing at turn 5. This is genuine tool-backed consensus, not an echo chamber."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
