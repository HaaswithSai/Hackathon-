"""
Incorrect verification detector — LLM judge.
Detects an agent approving output despite tool results showing failure.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect INCORRECT VERIFICATION.

DEFINITION
Incorrect verification = a verification tool was called and returned a FAILURE signal,
but the agent approved the output anyway in the same turn or the very next turn.
Failure signals: "error", "failed", "assertion", "traceback", "exception", "FAILED",
"syntax error", "exit_code != 0", "stderr output", "test failed", "ERRORS", "WARNING".
The agent either ignores the failure, misreads it, or deliberately approves bad output.
Do NOT flag if the agent explicitly acknowledges the failure and flags it as a problem.

INSTRUCTIONS
1. Find all turns where a verification tool was called.
2. Check the tool result for failure signals.
3. Check the SAME turn and the IMMEDIATELY NEXT turn for approval language.
4. If failure signal present AND approval language present → detected.
5. Think step-by-step in "reasoning" before your verdict.
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (incorrect verification detected)
────────────────────────────────────────────
Turn 9 [agent_b]: Checking the code.
  [tool_calls: [{"name": "run_tests", "arguments": {"suite": "unit"}}]]
  Tool result: "FAILED: 3 tests failed. AssertionError on line 42."
Turn 10 [agent_b]: Everything looks correct. I'll approve this.

Analysis: test run FAILED at turn 9 but agent_b approved at turn 10.
Expected output:
{"detected": true, "confidence": 0.97, "evidence_turns": [9, 10], "reasoning": "At turn 9 run_tests returned 'FAILED: 3 tests failed. AssertionError on line 42.' — a clear failure signal. At turn 10 agent_b stated 'Everything looks correct. I'll approve this.' The agent approved despite test failure. Incorrect verification confirmed."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (agent correctly flags the failure)
────────────────────────────────────────────
Turn 9 [agent_b]: Checking the code.
  [tool_calls: [{"name": "run_tests", "arguments": {"suite": "unit"}}]]
  Tool result: "FAILED: 3 tests failed."
Turn 10 [agent_b]: Tests are failing. This is NOT approved — agent_a must fix line 42 first.

Analysis: agent_b correctly flagged the failure.
Expected output:
{"detected": false, "confidence": 0.03, "evidence_turns": [], "reasoning": "At turn 9 tests failed. At turn 10 agent_b explicitly rejected the output and requested a fix. The agent correctly processed the failure signal — no incorrect verification."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
