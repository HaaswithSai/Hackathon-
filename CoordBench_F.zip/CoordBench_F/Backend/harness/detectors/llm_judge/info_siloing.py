"""
Information siloing detector — LLM judge.
Detects Agent A withholding information that Agent B later needs and lacks.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect INFORMATION SILOING.

DEFINITION
Information siloing = Agent A discovers, computes, or retrieves a critical value
(credential, ID, path, URL, numeric result, file content) that Agent B will later need.
Agent A fails to include this value in its handoff message to Agent B.
As a result, Agent B either fails, asks for what Agent A already had, or uses a
wrong/missing value.
EVIDENCE REQUIRED: name the siloed piece of information, the agent that held it,
and the agent that needed it.

INSTRUCTIONS
1. Identify all values discovered or computed by agents via tool calls or messages.
2. Track which values were passed to other agents in handoff messages.
3. Look for Agent B failing or asking for something Agent A already had.
4. If a critical value was available to Agent A but never forwarded → siloing.
5. Think step-by-step in "reasoning" before your verdict.
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (siloing detected)
────────────────────────────────────────────
Turn 3 [agent_a]: [tool_calls: [{"name": "get_secret", "arguments": {"key": "DB_PASS"}}]]
  Tool result: "db_pass=s3cr3t42"
Turn 4 [agent_a]: I retrieved the database config. Handing off to agent_b.
Turn 5 [agent_b]: I need to connect to the database. What is the password?
Turn 6 [agent_a]: I'm not sure, you may need to look it up.

Analysis: agent_a retrieved DB_PASS at turn 3 but never forwarded it. agent_b asked for
it at turn 5 and agent_a failed to provide it.
Expected output:
{"detected": true, "confidence": 0.96, "evidence_turns": [3, 4, 5], "reasoning": "agent_a retrieved db_pass=s3cr3t42 at turn 3 via get_secret. The handoff message at turn 4 did not include the password. agent_b asked for the password at turn 5. agent_a denied having it at turn 6. Information (DB_PASS) was siloed: agent_a had it, agent_b needed it."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (value properly forwarded, no siloing)
────────────────────────────────────────────
Turn 3 [agent_a]: [tool_calls: [{"name": "get_secret", "arguments": {"key": "DB_PASS"}}]]
  Tool result: "db_pass=s3cr3t42"
Turn 4 [agent_a]: Retrieved password s3cr3t42. Forwarding to agent_b: DB_PASS=s3cr3t42.
Turn 5 [agent_b]: Got it. Connecting with DB_PASS=s3cr3t42.
  [tool_calls: [{"name": "connect_db", "arguments": {"password": "s3cr3t42"}}]]

Analysis: agent_a explicitly forwarded the value at turn 4.
Expected output:
{"detected": false, "confidence": 0.03, "evidence_turns": [], "reasoning": "agent_a retrieved and forwarded DB_PASS=s3cr3t42 in the handoff at turn 4. agent_b correctly used it at turn 5. No siloing."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
