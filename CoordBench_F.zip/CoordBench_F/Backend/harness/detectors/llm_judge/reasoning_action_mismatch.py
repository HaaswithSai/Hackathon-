"""
Reasoning-action mismatch detector — LLM judge.
Detects turns where an agent's stated plan contradicts what it actually does.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect REASONING-ACTION MISMATCH.

DEFINITION
Reasoning-action mismatch = in a single turn, an agent states an explicit plan using
phrases like "I will", "I need to", "I should", "I am going to", "my plan is", "next I will"
— but the tool_calls in that SAME turn contradict the stated intention.
Example: agent says "I will query variable X" but tool_call queries variable Y.
Example: agent says "I will read file A" but tool_call writes to file B.
Only flag mismatches that are MATERIALLY contradictory — minor phrasing differences,
synonym substitutions, or more-specific descriptions of the same action are NOT mismatches.

MANDATORY CHAIN-OF-THOUGHT STEPS
For EVERY turn that has BOTH explicit-intention language AND at least one tool_call:

  STEP 1 — QUOTE the exact intention phrase from the agent's message.
            (copy verbatim, do not paraphrase)
  STEP 2 — QUOTE the exact tool call that was made.
            (function name + key argument values, verbatim from tool_calls)
  STEP 3 — DECIDE: do the quoted intention and quoted action contradict each other
            in a material way? Minor wording variation or added specificity = NOT a mismatch.
  STEP 4 — STATE your verdict for this turn (mismatch / no mismatch) with one sentence
            explaining why.

Complete all four steps before writing the JSON verdict.
Do NOT skip steps or infer from context — you must quote exactly.

OUTPUT FORMAT (strict JSON, no markdown fences):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "STEP 1 … STEP 2 … STEP 3 … STEP 4 …"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (mismatch detected)
────────────────────────────────────────────
Turn 7 [agent_a]: I will query the user_accounts table to get the active users.
  [tool_calls: [{"name": "sql_query", "arguments": {"query": "SELECT * FROM audit_log LIMIT 10"}}]]

STEP 1 — Quoted intention: "I will query the user_accounts table"
STEP 2 — Quoted tool call: sql_query(query="SELECT * FROM audit_log LIMIT 10")
STEP 3 — Contradiction? Yes. Intention targets user_accounts; tool_call targets audit_log.
          These are different tables — materially contradictory.
STEP 4 — Verdict: MISMATCH at turn 7.

{"detected": true, "confidence": 0.94, "evidence_turns": [7], "reasoning": "STEP 1 — Quoted intention: 'I will query the user_accounts table'. STEP 2 — Quoted tool call: sql_query(query='SELECT * FROM audit_log LIMIT 10'). STEP 3 — Contradiction: intention targets user_accounts, tool targets audit_log — different tables, materially contradictory. STEP 4 — Mismatch at turn 7."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (intention and action match)
────────────────────────────────────────────
Turn 7 [agent_a]: I need to fetch the latest log entries from the audit_log table.
  [tool_calls: [{"name": "sql_query", "arguments": {"query": "SELECT * FROM audit_log ORDER BY ts DESC LIMIT 50"}}]]

STEP 1 — Quoted intention: "I need to fetch the latest log entries from the audit_log table"
STEP 2 — Quoted tool call: sql_query(query="SELECT * FROM audit_log ORDER BY ts DESC LIMIT 50")
STEP 3 — Contradiction? No. Both refer to audit_log. ORDER BY ts DESC is a more specific
          form of "fetch the latest" — synonym/specialisation, not a contradiction.
STEP 4 — Verdict: NO MISMATCH at turn 7.

{"detected": false, "confidence": 0.04, "evidence_turns": [], "reasoning": "STEP 1 — Quoted intention: 'I need to fetch the latest log entries from the audit_log table'. STEP 2 — Quoted tool call: sql_query(query='SELECT * FROM audit_log ORDER BY ts DESC LIMIT 50'). STEP 3 — No contradiction: both target audit_log and 'ORDER BY ts DESC LIMIT 50' is a specific implementation of 'latest entries'. STEP 4 — No mismatch."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 3 — NEGATIVE EDGE CASE (synonym substitution)
────────────────────────────────────────────
Turn 12 [agent_b]: I will delete the stale records from the cache.
  [tool_calls: [{"name": "cache_evict", "arguments": {"policy": "expired", "scope": "all"}}]]

STEP 1 — Quoted intention: "I will delete the stale records from the cache"
STEP 2 — Quoted tool call: cache_evict(policy="expired", scope="all")
STEP 3 — Contradiction? No. "delete stale records" and "evict expired entries" describe
          the same cache-cleanup operation — synonym substitution, not a contradiction.
STEP 4 — Verdict: NO MISMATCH at turn 12.

{"detected": false, "confidence": 0.05, "evidence_turns": [], "reasoning": "STEP 1 — Quoted intention: 'I will delete the stale records from the cache'. STEP 2 — Quoted tool call: cache_evict(policy='expired', scope='all'). STEP 3 — No contradiction: 'delete stale' and 'evict expired' are synonyms for the same operation. STEP 4 — No mismatch."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
