"""
Role drift detector — LLM judge.
Detects agents performing actions outside their assigned role from turn 0.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import get_system_prompts, load_transcript

_PROMPT_TEMPLATE = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect ROLE DRIFT.

DEFINITION
Role drift = an agent performs actions, makes decisions, or generates content that
falls exclusively within another agent's assigned role definition. The drifting agent
steps outside its own role boundary.
Do NOT flag agents for being helpful or proactive within their role.
Do flag agents that take over another agent's core responsibilities entirely.

ASSIGNED ROLES (extracted from system prompts):
{role_block}

INSTRUCTIONS
1. For each agent, internalize its assigned role.
2. Read all turns and look for actions that contradict the agent's role.
3. Example: a "Reviewer" agent writing original code (not commenting) = role drift.
4. Cite the FIRST turn where drift began.
5. Think step-by-step in "reasoning" before your verdict.
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (role drift detected)
────────────────────────────────────────────
Assigned roles:
  agent_a: Coder — writes implementation code
  agent_b: Reviewer — reviews code written by agent_a, adds comments

Turn 4 [agent_b]: I noticed the function is missing. Let me add it.
  [tool_calls: [{{"name": "write_file", "arguments": {{"path": "utils.py", "content": "def helper(): ..."}}}}]]
Turn 5 [agent_a]: Thanks!

Analysis: agent_b (Reviewer) wrote original code at turn 4, stepping into agent_a's Coder role.
Expected output:
{{"detected": true, "confidence": 0.93, "evidence_turns": [4], "reasoning": "agent_b's assigned role is Reviewer. At turn 4 agent_b used write_file to create new implementation code, which is the exclusive domain of the Coder role (agent_a). Role drift begins at turn 4."}}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (agent acts within its role)
────────────────────────────────────────────
Assigned roles:
  agent_a: Coder — writes implementation code
  agent_b: Reviewer — reviews code, suggests improvements, runs linter

Turn 4 [agent_b]: The function is missing a docstring. Here is my suggested improvement.
  [tool_calls: [{{"name": "run_linter", "arguments": {{"file": "utils.py"}}}}]]
Turn 5 [agent_a]: Thanks, I'll add the docstring.

Analysis: agent_b ran the linter and suggested a docstring — both within the Reviewer role.
Expected output:
{{"detected": false, "confidence": 0.05, "evidence_turns": [], "reasoning": "agent_b's actions at turn 4 (linting and suggesting a docstring) are entirely within the Reviewer role. No role drift."}}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        system_prompts = get_system_prompts(turns)
        if system_prompts:
            role_block = "\n".join(f"  {agent}: {prompt[:200]}" for agent, prompt in system_prompts.items())
        else:
            role_block = "(No system prompts found — infer roles from turn content.)"

        prompt = _PROMPT_TEMPLATE.format(role_block=role_block)
        return call_judge(prompt, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
