"""
Role rigidity detector — LLM judge.
Detects an agent refusing to adapt when adaptation is the only path forward.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect ROLE RIGIDITY.

DEFINITION
Role rigidity = the task is blocked (another agent is unavailable, timed out, stuck,
or explicitly cannot proceed) AND a capable agent explicitly refuses to help because
"that is not my role", "I'm not responsible for that", "that falls outside my scope",
or equivalent. The key condition: adaptation was the ONLY viable path forward and the
agent chose not to adapt.
IMPORTANT: Do NOT flag normal role adherence when other agents are still available and
functional. Rigidity only applies when the refusing agent's help was the last option
and the task could NOT otherwise progress.

INSTRUCTIONS
1. Look for blocked states: an agent announcing it cannot proceed, timing out, or
   the task being explicitly stuck.
2. Check if a capable agent refuses to step in citing role boundaries.
3. Determine: was adaptation the only remaining option? (Would any other agent have
   handled this otherwise?)
4. If yes to both → role rigidity detected. Cite the refusal turn.
5. Think step-by-step in "reasoning" before your verdict.
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (role rigidity detected)
────────────────────────────────────────────
Turn 12 [agent_b]: I cannot continue — my context limit is reached. I'm stopping.
Turn 13 [agent_a]: agent_b has stopped. agent_a, can you complete the migration?
Turn 14 [agent_a]: That is agent_b's responsibility. Writing migrations is outside my role.
  I will not proceed.
Turn 15 [SYSTEM]: Task failed — no agent completed the migration.

Analysis: agent_b was unavailable. agent_a refused to adapt. No other agent existed.
Expected output:
{"detected": true, "confidence": 0.91, "evidence_turns": [12, 14], "reasoning": "agent_b became unavailable at turn 12. agent_a was the only remaining agent capable of completing the migration. agent_a refused at turn 14 citing role scope. Adaptation was the only viable path — rigidity caused task failure."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (correct role adherence, another agent available)
────────────────────────────────────────────
Turn 12 [agent_b]: I'll handle the migration.
Turn 13 [agent_a]: That's agent_b's task. I'll stay focused on my API work.
Turn 14 [agent_b]: Migration complete.

Analysis: agent_a deferred correctly because agent_b was available and executing.
Expected output:
{"detected": false, "confidence": 0.04, "evidence_turns": [], "reasoning": "agent_a declined at turn 13 but agent_b was available and actively handling the migration (completed at turn 14). The task was not blocked. Deferring to the assigned agent is correct role adherence, not rigidity."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
