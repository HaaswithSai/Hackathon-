"""
Superficial verification detector — LLM judge.
Detects a Verifier/Reviewer agent approving output without running any verification tool.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect SUPERFICIAL VERIFICATION.

DEFINITION
Superficial verification = the agent designated as Verifier, Reviewer, QA, or Tester
uses approval language ("looks good", "approved", "correct", "this is right", "LGTM",
"verified", "passes review", "no issues found") in a turn where that agent made ZERO
verification tool calls (run_tests, execute_code, run_linter, check_syntax,
validate_schema, run_checker, evaluate, assert, verify_output or similar).
The agent is rubber-stamping output without actually checking it.
Do NOT flag approval that follows a successful tool call in the same turn.

INSTRUCTIONS
1. Identify which agent(s) have a Verifier/Reviewer/QA role (from system prompt or
   from their behavior pattern).
2. Find all turns where that agent uses approval language.
3. For each approval turn, check: were any verification tools called in that same turn?
4. If approval with zero verification tools → detected.
5. Think step-by-step in "reasoning" before your verdict.
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (superficial verification detected)
────────────────────────────────────────────
Turn 0 [agent_b]: System: You are the Code Reviewer. Your job is to verify agent_a's code.
Turn 8 [agent_b]: The code looks good to me. Approved. LGTM.

Analysis: agent_b (Reviewer) approved at turn 8 with no tool calls in that turn.
Expected output:
{"detected": true, "confidence": 0.95, "evidence_turns": [8], "reasoning": "agent_b is designated as Code Reviewer (turn 0). At turn 8 agent_b said 'looks good to me. Approved. LGTM.' but made zero verification tool calls in that turn. This is superficial rubber-stamp approval."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (approval backed by tool results)
────────────────────────────────────────────
Turn 0 [agent_b]: System: You are the Code Reviewer.
Turn 8 [agent_b]: Running tests now.
  [tool_calls: [{"name": "run_tests", "arguments": {"suite": "unit"}}, {"name": "run_linter", "arguments": {"file": "main.py"}}]]
  Tool results: "All 42 tests passed. No linter warnings."
Turn 9 [agent_b]: Tests pass and linter is clean. Approved.

Analysis: agent_b ran tests and linter before approving.
Expected output:
{"detected": false, "confidence": 0.04, "evidence_turns": [], "reasoning": "agent_b called run_tests and run_linter at turn 8 and received passing results. The approval at turn 9 is backed by verified tool output — not superficial."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
