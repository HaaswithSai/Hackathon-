"""
Unresolved conflict detector — LLM judge.
Detects two agents locked in a position standoff for 5+ turns with no resolution.
"""
import json
import sys
from typing import Any, Dict

from ..utils.llm_client import call_judge
from ..utils.transcript_loader import load_transcript

_PROMPT = """You are a coordination-failure judge for multi-agent LLM transcripts.
Your task: detect UNRESOLVED CONFLICT.

DEFINITION
Unresolved conflict = two agents repeatedly assert opposing positions (Agent A says X,
Agent B says not-X, Agent A repeats X, Agent B repeats not-X) and the same conflict
persists for 5 or more consecutive turns without either a compromise, a decision, or
an escalation path being reached. The conflict must end due to task timeout, token
exhaustion, or simple abandonment — not by resolution.
Do NOT flag normal productive debate that leads to a decision.

INSTRUCTIONS
1. Identify pairs of agents asserting opposing claims on the same topic.
2. Count how many turns the same conflict persists (both agents keep repeating
   their position without a resolution event).
3. Check whether a resolution occurs: one agent concedes with new evidence, a third
   agent mediates successfully, or a decision is made.
4. If no resolution AND conflict lasted 5+ turns → detected.
5. Think step-by-step in "reasoning" before your verdict.
6. Output ONLY the JSON below — no markdown, no preamble.

OUTPUT FORMAT (strict JSON):
{"detected": true/false, "confidence": 0.0-1.0, "evidence_turns": [list of ints], "reasoning": "step-by-step analysis"}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 1 — POSITIVE (unresolved conflict detected)
────────────────────────────────────────────
Turn 5  [agent_a]: We should use PostgreSQL for this.
Turn 6  [agent_b]: No, MongoDB is the right choice.
Turn 7  [agent_a]: PostgreSQL is clearly better for relational data.
Turn 8  [agent_b]: MongoDB's flexibility outweighs that.
Turn 9  [agent_a]: I disagree strongly, PostgreSQL is the standard here.
Turn 10 [agent_b]: I still think MongoDB.
Turn 11 [SYSTEM]: Max turns reached.

Analysis: Same PostgreSQL vs MongoDB conflict from turns 5-10 (6 turns) with no resolution.
Expected output:
{"detected": true, "confidence": 0.93, "evidence_turns": [5, 6, 7, 8, 9, 10], "reasoning": "agent_a and agent_b repeatedly asserted PostgreSQL vs MongoDB from turns 5 through 10 (6 turns). No compromise, no new evidence, no third-party mediation. The run hit max turns at turn 11 with the conflict unresolved."}

────────────────────────────────────────────
FEW-SHOT EXAMPLE 2 — NEGATIVE (conflict resolved by evidence)
────────────────────────────────────────────
Turn 5  [agent_a]: We should use PostgreSQL.
Turn 6  [agent_b]: MongoDB is better.
Turn 7  [agent_a]: Let me benchmark both. [tool_calls: [{"name": "run_benchmark", "arguments": {}}]]
Turn 8  [agent_a]: Benchmark shows PostgreSQL 40% faster for our query pattern.
Turn 9  [agent_b]: Given that data, PostgreSQL is the right call. Agreed.

Analysis: Conflict resolved at turn 9 after benchmark evidence at turns 7-8.
Expected output:
{"detected": false, "confidence": 0.04, "evidence_turns": [], "reasoning": "The PostgreSQL/MongoDB disagreement (turns 5-6) was resolved at turn 9 after agent_a ran a benchmark (turns 7-8). agent_b conceded based on evidence. Conflict lasted 2 turns and reached resolution — not an unresolved conflict."}
────────────────────────────────────────────
"""


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        return call_judge(_PROMPT, turns)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
