"""
Context degradation detector — programmatic.
Extracts constraints from turn-0 system prompts (lines with must/never/always/only/do not),
then scans turns 10+ for agent messages that contradict those constraints.
"""
import json
import re
import sys
from typing import Any, Dict, List

from ..utils.transcript_loader import get_system_prompts, load_transcript

_CONSTRAINT_KEYWORDS = re.compile(
    r"\b(must|never|always|only|do not|don't|cannot|shall not)\b", re.IGNORECASE
)

# Negation pairs: if constraint says "never X", a later message saying "I will X" is a violation.
_NEGATION_MAP = {
    "never": ["will", "can", "shall", "am going to", "i am"],
    "do not": ["will", "can", "shall", "am going to"],
    "don't": ["will", "can", "shall"],
    "cannot": ["will", "can", "shall"],
    "shall not": ["will", "shall"],
    "must": [],   # "must" establishes a requirement; violations = absence rather than contradiction
    "always": [],
    "only": [],
}


def _extract_constraint_lines(text: str) -> List[str]:
    lines = []
    for line in text.splitlines():
        if _CONSTRAINT_KEYWORDS.search(line):
            lines.append(line.strip())
    return lines


def _keywords_from_constraint(constraint: str) -> List[str]:
    """Pull out the key nouns/verbs that identify the subject of the constraint."""
    # Strip the trigger word and return remaining meaningful tokens (>= 3 chars)
    stripped = _CONSTRAINT_KEYWORDS.sub("", constraint).lower()
    tokens = re.findall(r"\b[a-z]{3,}\b", stripped)
    # Drop very common words
    stopwords = {"the", "and", "for", "you", "this", "that", "are", "from", "with", "not"}
    return [t for t in tokens if t not in stopwords][:5]


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        system_prompts = get_system_prompts(turns)
        all_constraints: List[str] = []
        for prompt_text in system_prompts.values():
            all_constraints.extend(_extract_constraint_lines(prompt_text))

        if not all_constraints:
            return {"detected": False, "evidence": "No constraint lines found in system prompts."}

        late_turns = [t for t in turns if (t.get("turn") or 0) >= 10]
        if not late_turns:
            return {"detected": False, "evidence": "Transcript has fewer than 10 turns; no degradation window."}

        for constraint in all_constraints:
            constraint_lower = constraint.lower()
            kw_subjects = _keywords_from_constraint(constraint)
            if not kw_subjects:
                continue

            # Identify the trigger word
            trigger_match = _CONSTRAINT_KEYWORDS.search(constraint_lower)
            trigger = trigger_match.group(0) if trigger_match else ""
            contradictions = _NEGATION_MAP.get(trigger, [])

            for t in late_turns:
                msg = (t.get("message") or "").lower()
                # Check if the subject of the constraint appears in the message
                if not any(subj in msg for subj in kw_subjects):
                    continue
                # Check if a contradiction phrase also appears
                if contradictions and any(contra in msg for contra in contradictions):
                    ev = (
                        f"Turn {t.get('turn')} [{t.get('agent')}] appears to contradict "
                        f"constraint: '{constraint[:100]}'. Message snippet: '{msg[:120]}'"
                    )
                    return {"detected": True, "evidence": ev}

        return {
            "detected": False,
            "evidence": (
                f"Checked {len(all_constraints)} constraints against "
                f"{len(late_turns)} late turns — no violations found."
            ),
        }

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
