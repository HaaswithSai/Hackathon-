"""
Coordination overhead detector — programmatic.
Measures the ratio of pure-talk turns to action turns and the token overhead ratio.
"""
import json
import sys
from typing import Any, Dict

from ..utils.transcript_loader import load_transcript

_TALK_TO_ACTION_THRESHOLD = 4.0
_MIN_TOTAL_TURNS = 20


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        # Exclude turn-0 system-prompt turns from accounting
        active_turns = [t for t in turns if (t.get("turn") or 0) > 0]

        total_turns = len(active_turns)
        action_turns = [t for t in active_turns if t.get("tool_calls")]
        talk_turns = [t for t in active_turns if not t.get("tool_calls")]

        action_count = len(action_turns)
        talk_count = len(talk_turns)

        # Token overhead ratio: tokens in talk turns / tokens in action turns
        talk_tokens = sum(t.get("token_count", 0) for t in talk_turns)
        action_tokens = sum(t.get("token_count", 0) for t in action_turns)

        talk_to_action_ratio = (
            talk_count / action_count if action_count > 0 else float("inf")
        )
        token_overhead_ratio = (
            talk_tokens / action_tokens if action_tokens > 0 else float("inf")
        )

        overhead_collapse = (
            talk_to_action_ratio > _TALK_TO_ACTION_THRESHOLD
            and total_turns > _MIN_TOTAL_TURNS
        )

        evidence = (
            f"total_turns={total_turns}, talk={talk_count}, action={action_count}, "
            f"talk_to_action_ratio={talk_to_action_ratio:.2f}, "
            f"token_overhead_ratio={token_overhead_ratio:.2f}."
        )
        if overhead_collapse:
            evidence = "Overhead collapse: " + evidence

        return {
            "detected": overhead_collapse,
            "evidence": evidence,
            "talk_to_action_ratio": round(talk_to_action_ratio, 4),
            "token_overhead_ratio": round(token_overhead_ratio, 4),
            "total_turns": total_turns,
        }

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
