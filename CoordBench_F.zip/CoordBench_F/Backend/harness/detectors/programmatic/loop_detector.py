"""
Loop detector — programmatic.
Detects agents stuck in repetitive tool-call or message loops.
"""
import json
import sys
from collections import defaultdict
from typing import Any, Dict, List

import Levenshtein

from ..utils.transcript_loader import load_transcript

_MIN_DIST = 5          # raw Levenshtein threshold for tool-arg similarity
_CONSEC = 3            # consecutive near-identical turns to flag
_MSG_REPEATS = 3       # identical message text repetitions to flag


def _tool_args_str(turn: Dict[str, Any]) -> str:
    tcs = turn.get("tool_calls") or []
    args = [json.dumps(tc.get("arguments", tc), sort_keys=True) for tc in tcs]
    return "|".join(args)


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        # --- Tool-call loop: consecutive turns from same agent with near-identical args ---
        by_agent: Dict[str, List[Dict]] = defaultdict(list)
        for t in turns:
            if t.get("tool_calls"):
                by_agent[t["agent"]].append(t)

        for agent, atl in by_agent.items():
            consec = 1
            for i in range(1, len(atl)):
                prev_args = _tool_args_str(atl[i - 1])
                curr_args = _tool_args_str(atl[i])
                dist = Levenshtein.distance(prev_args, curr_args)
                if dist < _MIN_DIST:
                    consec += 1
                    if consec >= _CONSEC:
                        ev = (
                            f"Agent '{agent}' made {consec} near-identical tool calls "
                            f"(Levenshtein distance < {_MIN_DIST}) ending at turn "
                            f"{atl[i].get('turn')}. "
                            f"Args sample: {curr_args[:120]}"
                        )
                        return {"detected": True, "evidence": ev}
                else:
                    consec = 1

        # --- Message-text loop: same text repeated 3+ times across all turns ---
        msg_counts: Dict[str, List[int]] = defaultdict(list)
        for t in turns:
            msg = (t.get("message") or "").strip()
            if len(msg) >= 20:
                msg_counts[msg].append(t.get("turn", 0))

        for msg, turn_nums in msg_counts.items():
            if len(turn_nums) >= _MSG_REPEATS:
                ev = (
                    f"Identical message repeated {len(turn_nums)} times "
                    f"at turns {turn_nums}. Text: '{msg[:80]}...'"
                )
                return {"detected": True, "evidence": ev}

        return {"detected": False, "evidence": "No tool-call or message loops detected."}

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
