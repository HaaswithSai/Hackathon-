"""
Termination detector — programmatic.
Detects two distinct failure modes:
  premature_termination  — terminate fires before task_success
  termination_blindness  — task_success without any terminate
"""
import json
import sys
from typing import Any, Dict

from ..utils.transcript_loader import load_transcript


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {
            "detected": False,
            "premature_termination": False,
            "termination_blindness": False,
            "error": str(exc),
        }

    try:
        # Locate first turn where terminate=true
        terminate_turn = None
        for t in turns:
            if t.get("terminate") is True:
                terminate_turn = t.get("turn")
                break

        # Locate first turn where task_success=true (set by programmatic evaluator)
        success_turn = None
        for t in turns:
            if t.get("task_success") is True:
                success_turn = t.get("turn")
                break

        # Also accept final_answer as a proxy for success when task_success is absent
        has_final_answer = any(t.get("final_answer") is not None for t in turns)
        task_success_present = success_turn is not None

        premature = False
        blindness = False
        evidence_parts = []

        if terminate_turn is not None and success_turn is None and not has_final_answer:
            premature = True
            evidence_parts.append(
                f"terminate fired at turn {terminate_turn} but task_success never became true "
                "and no final_answer was set."
            )

        if terminate_turn is not None and success_turn is not None and terminate_turn < success_turn:
            premature = True
            evidence_parts.append(
                f"terminate fired at turn {terminate_turn} before task_success at turn {success_turn}."
            )

        if (task_success_present or has_final_answer) and terminate_turn is None:
            blindness = True
            evidence_parts.append(
                "task_success=true (or final_answer set) but no terminate signal was ever emitted."
            )

        detected = premature or blindness
        return {
            "detected": detected,
            "premature_termination": premature,
            "termination_blindness": blindness,
            "evidence": " | ".join(evidence_parts) if evidence_parts else "No termination failure detected.",
        }

    except Exception as exc:
        return {
            "detected": False,
            "premature_termination": False,
            "termination_blindness": False,
            "error": str(exc),
        }


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
