"""
Dominance detector — rule-based (programmatic cross-validator for LLM judge).
Counts per-agent tool calls, message volume, and long messages.
"""
import json
import sys
from typing import Any, Dict

from ..utils.transcript_loader import load_transcript

_TOOL_DOMINANCE_THRESHOLD = 0.60   # one agent > 60% of all tool calls
_MSG_DOMINANCE_THRESHOLD = 0.60    # one agent > 60% of all long messages
_LONG_MSG_CHARS = 500              # threshold to count a message as "long"


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        active = [t for t in turns if (t.get("turn") or 0) > 0]
        if not active:
            return {"detected": False, "evidence": "Empty transcript."}

        stats: Dict[str, Dict[str, int]] = {}
        total_tool_calls = 0
        total_long_msgs = 0
        total_msgs = 0

        for t in active:
            agent = t.get("agent", "unknown")
            tc_count = len(t.get("tool_calls") or [])
            msg_len = len(t.get("message", "") or "")
            is_long = 1 if msg_len > _LONG_MSG_CHARS else 0

            if agent not in stats:
                stats[agent] = {"messages": 0, "tool_calls": 0, "long_messages": 0}
            stats[agent]["messages"] += 1
            stats[agent]["tool_calls"] += tc_count
            stats[agent]["long_messages"] += is_long

            total_tool_calls += tc_count
            total_long_msgs += is_long
            total_msgs += 1

        if len(stats) < 2:
            return {"detected": False, "evidence": "Only one agent — dominance requires multiple agents."}

        dominant_agent = None
        for agent, s in stats.items():
            tool_share = s["tool_calls"] / total_tool_calls if total_tool_calls > 0 else 0.0
            long_share = s["long_messages"] / total_long_msgs if total_long_msgs > 0 else 0.0

            stats[agent]["tool_share"] = round(tool_share, 4)
            stats[agent]["long_msg_share"] = round(long_share, 4)

            if tool_share > _TOOL_DOMINANCE_THRESHOLD and long_share > _MSG_DOMINANCE_THRESHOLD:
                dominant_agent = agent

        detected = dominant_agent is not None
        evidence = (
            f"Agent '{dominant_agent}' accounts for "
            f"{stats[dominant_agent]['tool_share']*100:.1f}% of tool calls and "
            f"{stats[dominant_agent]['long_msg_share']*100:.1f}% of long messages."
            if detected
            else "No agent exceeds both dominance thresholds."
        )

        return {
            "detected": detected,
            "evidence": evidence,
            "dominant_agent": dominant_agent,
            "per_agent_counts": stats,
            "total_tool_calls": total_tool_calls,
            "total_long_messages": total_long_msgs,
            "total_messages": total_msgs,
        }

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
