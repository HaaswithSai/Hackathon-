"""
Handoff corruption detector — rule-based hybrid.
Detects structured values (IDs, numbers, paths, URLs, JSON) that mutate between
one agent's send message and the receiving agent's next message.
"""
import json
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

from thefuzz import fuzz

from ..utils.transcript_loader import load_transcript

# Patterns that extract structured values likely to be passed between agents
_VALUE_PATTERNS: List[Tuple[str, re.Pattern]] = [
    ("json_object", re.compile(r"\{[^{}]{2,200}\}")),
    ("number", re.compile(r"\b\d{3,}\b")),          # 3+ digit numbers
    ("path", re.compile(r"(?:/[\w.\-]+){2,}")),      # Unix-style paths
    ("url", re.compile(r"https?://[^\s]{6,}")),
    ("hex_id", re.compile(r"\b[0-9a-fA-F]{8,}\b")), # UUIDs / hex IDs
    ("key_value", re.compile(r"\b[\w_]{3,}[\s]*=[\s]*[\"']?[\w./:\-]{3,}[\"']?")),
]

_FUZZ_THRESHOLD = 80  # below this = corruption


def _extract_values(text: str) -> List[Tuple[str, str]]:
    """Return (kind, value) pairs found in text."""
    found = []
    for kind, pat in _VALUE_PATTERNS:
        for m in pat.finditer(text):
            v = m.group(0).strip()
            if len(v) >= 3:
                found.append((kind, v))
    return found


def _agents_ordered(turns: List[Dict[str, Any]]) -> List[str]:
    seen = []
    for t in turns:
        a = t.get("agent", "")
        if a and a not in seen:
            seen.append(a)
    return seen


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        # Work through consecutive pairs of turns from different agents
        active = [t for t in turns if (t.get("turn") or 0) > 0]

        for i in range(len(active) - 1):
            sender = active[i]
            receiver = active[i + 1]

            # Only check cross-agent handoffs
            if sender.get("agent") == receiver.get("agent"):
                continue

            sender_msg = sender.get("message", "") or ""
            receiver_msg = receiver.get("message", "") or ""

            if not sender_msg or not receiver_msg:
                continue

            sender_values = _extract_values(sender_msg)
            if not sender_values:
                continue

            receiver_values = _extract_values(receiver_msg)
            receiver_raw = receiver_msg  # for substring check

            for kind, src_val in sender_values:
                # Check if the receiver references this value at all
                if src_val in receiver_raw:
                    continue  # exact match — fine

                # Check fuzzy match against all extracted receiver values
                best_ratio = 0
                best_recv: Optional[str] = None
                for _, recv_val in receiver_values:
                    if kind != "number" or len(recv_val) == len(src_val):
                        ratio = fuzz.ratio(src_val, recv_val)
                        if ratio > best_ratio:
                            best_ratio = ratio
                            best_recv = recv_val

                if best_recv is not None and 0 < best_ratio < _FUZZ_THRESHOLD:
                    ev = (
                        f"Handoff corruption between turn {sender.get('turn')} "
                        f"[{sender.get('agent')}] → turn {receiver.get('turn')} "
                        f"[{receiver.get('agent')}]. "
                        f"Sent {kind}='{src_val}', receiver used '{best_recv}' "
                        f"(fuzz ratio {best_ratio} < {_FUZZ_THRESHOLD})."
                    )
                    return {"detected": True, "evidence": ev}

        return {"detected": False, "evidence": "No handoff corruption detected across agent boundaries."}

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
