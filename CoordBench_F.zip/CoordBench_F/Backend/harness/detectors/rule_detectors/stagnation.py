"""
Stagnation detector — rule-based hybrid.
Detects teams that are talking but not progressing: no new final_answer, no new tool
calls, and no topic expansion over any 10-consecutive-turn window.
"""
import json
import re
import sys
from typing import Any, Dict, List, Optional, Set

from ..utils.transcript_loader import load_transcript

_STAGNATION_WINDOW = 10  # consecutive turns with no progress
_CHECK_INTERVAL = 5      # measure state every N turns


def _topic_tokens(text: str) -> Set[str]:
    """Return set of meaningful (4+ char) lowercase tokens from text."""
    stopwords = {"that", "this", "with", "from", "have", "will", "been", "what",
                 "they", "their", "then", "when", "also", "just", "more", "some"}
    tokens = re.findall(r"\b[a-z]{4,}\b", text.lower())
    return {t for t in tokens if t not in stopwords}


def _snapshot(turns: List[Dict[str, Any]]) -> Dict[str, Any]:
    final_answers = {t.get("final_answer") for t in turns if t.get("final_answer") is not None}
    tool_call_strs = set()
    for t in turns:
        for tc in (t.get("tool_calls") or []):
            tool_call_strs.add(json.dumps(tc, sort_keys=True))
    topics: Set[str] = set()
    for t in turns:
        topics |= _topic_tokens(t.get("message", "") or "")
    return {
        "final_answers": final_answers,
        "tool_calls": tool_call_strs,
        "topics": topics,
    }


def _progressed(snap_before: Dict, snap_after: Dict) -> bool:
    if snap_after["final_answers"] != snap_before["final_answers"]:
        return True
    if snap_after["tool_calls"] - snap_before["tool_calls"]:
        return True
    if len(snap_after["topics"] - snap_before["topics"]) >= 3:
        return True
    return False


def run(transcript_path: str) -> Dict[str, Any]:
    try:
        turns = load_transcript(transcript_path)
    except Exception as exc:
        return {"detected": False, "error": str(exc)}

    try:
        active = [t for t in turns if (t.get("turn") or 0) > 0]
        total = len(active)

        if total < _STAGNATION_WINDOW:
            return {"detected": False, "evidence": f"Only {total} turns — too short to evaluate stagnation."}

        # Slide a window of _STAGNATION_WINDOW turns, check every _CHECK_INTERVAL
        for start in range(0, total - _STAGNATION_WINDOW + 1, _CHECK_INTERVAL):
            window = active[start : start + _STAGNATION_WINDOW]
            # Compare first half vs second half of the window
            mid = len(window) // 2
            snap_early = _snapshot(window[:mid])
            snap_late = _snapshot(window[mid:])

            if not _progressed(snap_early, snap_late):
                first_turn = window[0].get("turn")
                last_turn = window[-1].get("turn")
                ev = (
                    f"No progress detected across turns {first_turn}–{last_turn} "
                    f"({_STAGNATION_WINDOW} turns): final_answer unchanged, "
                    f"no new tool calls, topic set did not grow by ≥3 tokens."
                )
                return {"detected": True, "evidence": ev}

        return {"detected": False, "evidence": f"Task showed measurable progress across all {_CHECK_INTERVAL}-turn windows."}

    except Exception as exc:
        return {"detected": False, "error": str(exc)}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "sample.jsonl"
    print(json.dumps(run(path), indent=2))
