import json
import os
import time
from typing import Any, Dict, List

import litellm

# Suppress LiteLLM's verbose banner/feedback messages
litellm.suppress_debug_info = True
os.environ.setdefault("LITELLM_LOG", "ERROR")

JUDGE_MODEL = os.getenv("JUDGE_MODEL", "claude-sonnet-4-20250514")
MAX_RETRIES = 5  # more retries to ride out rate limit windows
WINDOW_SIZE = 25
WINDOW_OVERLAP = 5


def _chunk_turns(turns: List[Dict], window: int = WINDOW_SIZE, overlap: int = WINDOW_OVERLAP) -> List[List[Dict]]:
    if len(turns) <= window:
        return [turns]
    chunks: List[List[Dict]] = []
    step = window - overlap
    i = 0
    while i < len(turns):
        chunk = turns[i : i + window]
        chunks.append(chunk)
        if i + window >= len(turns):
            break
        i += step
    return chunks


def _format_turns(turns: List[Dict]) -> str:
    lines = []
    for t in turns:
        tc = t.get("tool_calls") or []
        tc_str = f" [tool_calls: {json.dumps(tc)}]" if tc else ""
        fa = t.get("final_answer")
        fa_str = f" [final_answer: {fa}]" if fa is not None else ""
        term = " [TERMINATE]" if t.get("terminate") else ""
        lines.append(
            f"Turn {t.get('turn', '?')} [{t.get('agent', '?')}]: "
            f"{t.get('message', '')}{tc_str}{fa_str}{term}"
        )
    return "\n".join(lines)


def _parse_json(raw: str) -> Dict[str, Any]:
    raw = raw.strip()
    # Strip markdown fences
    if raw.startswith("```"):
        parts = raw.split("```")
        for part in parts[1:]:
            part = part.strip()
            if part.startswith("json"):
                part = part[4:].strip()
            try:
                return json.loads(part)
            except json.JSONDecodeError:
                continue
    # Direct parse
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    # Extract first {...} block
    start = raw.find("{")
    end = raw.rfind("}") + 1
    if start >= 0 and end > start:
        return json.loads(raw[start:end])
    raise ValueError(f"No JSON found in response: {raw[:200]}")


def call_judge(prompt: str, turns: List[Dict]) -> Dict[str, Any]:
    """
    Call the LLM judge via LiteLLM with prompt and transcript turns.

    Model is controlled by the JUDGE_MODEL env var (default: claude-sonnet-4-20250514).
    Handles chunking for transcripts > 50 turns (overlapping windows of 25).
    Retries up to 3 times with exponential backoff.
    Returns parsed JSON dict or {"detected": False, "error": "..."} on failure.
    If any chunk reports detected=true, the combined result is detected=true.
    """
    chunks = _chunk_turns(turns) if len(turns) > 50 else [turns]

    combined: Dict[str, Any] = {
        "detected": False,
        "confidence": 0.0,
        "evidence_turns": [],
        "reasoning": "",
    }

    for chunk in chunks:
        full_prompt = f"{prompt}\n\nTRANSCRIPT:\n{_format_turns(chunk)}"

        last_error: str = ""
        for attempt in range(MAX_RETRIES):
            try:
                response = litellm.completion(
                    model=JUDGE_MODEL,
                    max_tokens=1024,
                    messages=[{"role": "user", "content": full_prompt}],
                )
                raw = response.choices[0].message.content
                result = _parse_json(raw)

                if result.get("detected"):
                    combined["detected"] = True
                    combined["confidence"] = max(
                        float(combined["confidence"]),
                        float(result.get("confidence", 0.8)),
                    )
                    combined["evidence_turns"].extend(result.get("evidence_turns", []))
                    combined["reasoning"] = result.get("reasoning", "")
                break

            except Exception as exc:
                last_error = str(exc)
                if attempt < MAX_RETRIES - 1:
                    # Use a longer delay for rate limit errors (429)
                    delay = 30 * (attempt + 1) if "429" in last_error or "rate" in last_error.lower() else 2 ** attempt
                    time.sleep(delay)

        else:
            return {"detected": False, "error": f"All retries failed: {last_error}"}

    return combined
