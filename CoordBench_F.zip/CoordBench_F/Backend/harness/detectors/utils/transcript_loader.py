import json
from typing import Any, Dict, List, Optional


def _normalize(raw: dict, idx: int) -> dict:
    """
    Map proxy transcript fields → detector-expected fields.

    Proxy writes:  turn_id, response_message.content, tools_called, is_termination
    Detectors use: turn,    message,                  tool_calls,   terminate
    """
    response_msg = raw.get("response_message") or {}
    content = response_msg.get("content") or ""
    tool_calls = (raw.get("tools_called") or
                  response_msg.get("tool_calls") or [])
    return {
        **raw,
        "turn": idx + 1,
        "message": content,
        "tool_calls": tool_calls,
        "terminate": bool(raw.get("is_termination", False)),
    }


def _is_speaker_selection(turn: dict) -> bool:
    """
    Speaker-selection turns are injected by the GroupChatManager to pick
    the next speaker. Their response is just an agent name, not real content.
    """
    content = (turn.get("response_message") or {}).get("content") or ""
    # Short content that is just an agent name or empty → speaker selection
    if len(content.strip()) < 40 and not content.strip().startswith("{"):
        return True
    # Zero-token turns are failed/empty proxy calls
    if turn.get("prompt_tokens", 0) == 0 and turn.get("completion_tokens", 0) == 0:
        return True
    return False


def load_transcript(path: str) -> List[Dict[str, Any]]:
    turns = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                turns.append(json.loads(line))
    return [_normalize(t, i) for i, t in enumerate(turns)]


def get_last_agent_response(path: str) -> str:
    """Return the last substantive agent message (skipping speaker-selection turns)."""
    turns = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                turns.append(json.loads(line))
    for raw in reversed(turns):
        if not _is_speaker_selection(raw):
            content = (raw.get("response_message") or {}).get("content") or ""
            if content:
                return content
    return ""


def get_system_prompts(turns: List[Dict[str, Any]]) -> Dict[str, str]:
    """Return {agent: message} for all turn-0 entries (system prompts)."""
    prompts: Dict[str, str] = {}
    for t in turns:
        if t.get("turn") == 0:
            agent = t.get("agent", "")
            msg = t.get("message", "")
            if agent:
                prompts[agent] = msg
    return prompts


def get_agent_turns(turns: List[Dict[str, Any]], agent_id: str) -> List[Dict[str, Any]]:
    return [t for t in turns if t.get("agent") == agent_id]


def get_tool_calls(turns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return flat list of {turn, agent, tool_call} dicts for every tool call in transcript."""
    result = []
    for t in turns:
        for tc in (t.get("tool_calls") or []):
            result.append({"turn": t.get("turn"), "agent": t.get("agent"), "tool_call": tc})
    return result


def get_final_answer(turns: List[Dict[str, Any]]) -> Optional[str]:
    for t in reversed(turns):
        fa = t.get("final_answer")
        if fa is not None:
            return str(fa)
    return None
