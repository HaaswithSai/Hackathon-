import json
import os
import typer
from dotenv import load_dotenv
load_dotenv()
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from detectors.aggregator import run as aggregate_failures
from detectors.utils.transcript_loader import get_last_agent_response
from evaluators.role_locked_eval import evaluate as role_locked_evaluate
from evaluators.sequential_handoff_eval import evaluate as sequential_handoff_evaluate
from evaluators.verification_gauntlet_eval import evaluate as verification_gauntlet_evaluate
from evaluators.debate_deliberation_eval import evaluate as debate_deliberation_evaluate
from evaluators.resource_contention_eval import evaluate as resource_contention_evaluate

app = typer.Typer(help="Evaluate a MAC-Bench transcript")
console = Console()

def load_task(task_path: str, task_id: str = None) -> dict:
    with open(task_path, "r", encoding="utf-8") as f:
        raw = "\n".join(line for line in f if not line.lstrip().startswith("#"))
    data = json.loads(raw)
    if isinstance(data, list):
        if task_id:
            for t in data:
                if t.get("id") == task_id:
                    return t
        return data[0]
    return data

@app.command()
def evaluate(
    transcript_path: str = typer.Argument(..., help="Path to the .jsonl transcript"),
    task_file: str = typer.Argument(..., help="Path to the task definition file"),
    task_id: str = typer.Option(None, help="Specific task ID if file is a list"),
    final_answer: str = typer.Option(None, help="Final answer string if available")
):
    if not os.path.exists(transcript_path):
        console.print(f"[bold red]Transcript not found:[/bold red] {transcript_path}")
        raise typer.Exit(1)

    task_def = load_task(task_file, task_id)
    ground_truth = task_def.get("ground_truth")

    # Calculate transcript metrics
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_latency_ms = 0
    turns = 0

    with open(transcript_path, 'r') as f:
        for line in f:
            if line.strip():
                turn = json.loads(line)
                turns += 1
                total_prompt_tokens += turn.get("prompt_tokens", 0)
                total_completion_tokens += turn.get("completion_tokens", 0)
                total_latency_ms += turn.get("latency_ms", 0)

    # Extract the last substantive agent response (skipping speaker-selection turns
    # which contain only a short agent name like "agent_security")
    last_response = final_answer or get_last_agent_response(transcript_path)

    # Determine task success
    task_type = task_def.get("id", "").split("_")[0]
    eval_type = task_def.get("evaluator", "exact_match")
    is_success = False

    if task_type == "rl":
        is_success = role_locked_evaluate(ground_truth, last_response, eval_type)
    elif task_type == "sh":
        is_success = sequential_handoff_evaluate(ground_truth, last_response)
    elif task_type == "vg":
        is_success = verification_gauntlet_evaluate(ground_truth, last_response)
    elif task_type == "dd":
        is_success = debate_deliberation_evaluate(ground_truth, last_response, eval_type)
    elif task_type == "rc":
        is_success = resource_contention_evaluate(ground_truth, last_response, eval_type)
    else:
        # Fallback to simple inclusion
        is_success = str(ground_truth).lower() in last_response.lower()

    # Run MAST Swarm — pass is_success so the aggregator's confidence-merging
    # rules (e.g. echo-chamber fast-consensus override) have the correct value
    console.print(f"[bold yellow]Running MAST Evaluator Swarm on {turns} turns...[/bold yellow]")
    report = aggregate_failures(transcript_path, task_success=is_success)

    # Display Results
    console.print(Panel.fit(
        f"[bold green]Task Success:[/bold green] {is_success}\n"
        f"[bold blue]Total Turns:[/bold blue] {turns}\n"
        f"[bold cyan]Total Tokens:[/bold cyan] {total_prompt_tokens + total_completion_tokens} "
        f"(Prompt: {total_prompt_tokens}, Completion: {total_completion_tokens})\n"
        f"[bold magenta]Total Latency:[/bold magenta] {total_latency_ms / 1000:.2f}s",
        title="[bold]Run Metrics[/bold]"
    ))

    # Failure Modes Table
    table = Table(title="MAST Failure Modes")
    table.add_column("Confidence", style="cyan")
    table.add_column("Failure Mode", style="magenta")

    high = report.get("high_confidence", [])
    medium = report.get("medium_confidence", [])

    for mode in high:
        table.add_row("[bold red]HIGH[/bold red]", mode.replace("_", " ").title())
    for mode in medium:
        table.add_row("[yellow]MEDIUM[/yellow]", mode.replace("_", " ").title())
    if not high and not medium:
        table.add_row("[dim green]none[/dim green]", "[dim]No failure modes detected[/dim]")

    console.print(table)

    cost = report.get("coordination_cost", {})
    console.print(
        f"\n[bold]Coordination Cost:[/bold] "
        f"talk/action ratio={cost.get('talk_to_action_ratio', 0):.2f}  "
        f"token overhead={cost.get('token_overhead_ratio', 0):.2f}"
    )

if __name__ == "__main__":
    app()
