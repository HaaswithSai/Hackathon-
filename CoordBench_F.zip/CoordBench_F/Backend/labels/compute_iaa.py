"""
Compute inter-annotator agreement and produce majority-vote gold labels.

Metrics:
  - Fleiss' κ   — agreement across all raters simultaneously (no missing values)
  - Krippendorff's α — nominal, handles missing values (raters who skipped items)

Usage:
    python -m labels.compute_iaa
    python -m labels.compute_iaa --labels-dir labels --min-raters 2
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import typer
from rich.console import Console
from rich.table import Table

BASE_DIR = Path(__file__).parent.parent
app = typer.Typer(help="Compute IAA metrics and produce gold_labels.json.")
console = Console()

FAILURE_MODES: List[str] = [
    "task_disobedience",
    "role_drift",
    "loop",
    "context_degradation",
    "termination_blindness",
    "stagnation",
    "info_siloing",
    "echo_chamber",
    "agent_dominance",
    "reasoning_action_mismatch",
    "unresolved_conflict",
    "handoff_corruption",
    "premature_termination",
    "superficial_verification",
    "incorrect_verification",
    "hallucinated_verification",
    "coordination_overhead",
]

# Labels with Fleiss κ below this are flagged as unreliable for detector validation
IAA_RELIABLE_THRESHOLD = 0.60


# ---------------------------------------------------------------------------
# Fleiss' κ
# ---------------------------------------------------------------------------

def fleiss_kappa(ratings: List[List[Optional[bool]]]) -> float:
    """
    Compute Fleiss' κ for binary labels across n_raters on n_units.

    ratings[r][i] = True | False | None
    Only units where ALL raters provided a non-None label are included.
    Returns nan when fewer than 2 valid units exist.
    """
    n_raters = len(ratings)
    if n_raters < 2:
        return float("nan")
    n_units = len(ratings[0]) if ratings else 0

    # Restrict to units rated by every rater
    matrix: List[Tuple[int, int]] = []  # (count_false, count_true) per unit
    for i in range(n_units):
        row = [ratings[r][i] for r in range(n_raters)]
        if any(v is None for v in row):
            continue
        n_true = sum(1 for v in row if v)
        matrix.append((n_raters - n_true, n_true))

    N = len(matrix)
    if N < 2:
        return float("nan")

    n = n_raters  # raters per unit (fixed)

    # Marginal proportions
    total = N * n
    p_true = sum(m[1] for m in matrix) / total
    p_false = 1.0 - p_true
    P_e = p_true ** 2 + p_false ** 2

    # Mean per-subject agreement
    P_bar = sum(
        (m[0] ** 2 + m[1] ** 2 - n) / (n * (n - 1))
        for m in matrix
    ) / N

    if P_e >= 1.0:
        return 1.0
    return (P_bar - P_e) / (1.0 - P_e)


# ---------------------------------------------------------------------------
# Krippendorff's α  (nominal, handles missing values)
# ---------------------------------------------------------------------------

def krippendorff_alpha(ratings: List[List[Optional[bool]]]) -> float:
    """
    Compute Krippendorff's α for nominal binary data, tolerating missing values.

    ratings[r][i] = True | False | None (None = rater did not label this unit)
    Uses the coincidence-matrix formulation (Krippendorff 2004).
    """
    n_raters = len(ratings)
    if n_raters < 2:
        return float("nan")
    n_units = len(ratings[0]) if ratings else 0

    # Coincidence matrix o[c][k] for categories {0=False, 1=True}
    o = [[0.0, 0.0], [0.0, 0.0]]

    for i in range(n_units):
        valid_vals = [
            (1 if ratings[r][i] else 0)
            for r in range(n_raters)
            if ratings[r][i] is not None
        ]
        n_u = len(valid_vals)
        if n_u < 2:
            continue
        # All ordered pairs (r1, r2) with r1 ≠ r2
        for r1 in range(n_raters):
            v1 = ratings[r1][i]
            if v1 is None:
                continue
            for r2 in range(n_raters):
                if r1 == r2:
                    continue
                v2 = ratings[r2][i]
                if v2 is None:
                    continue
                c = 1 if v1 else 0
                k = 1 if v2 else 0
                o[c][k] += 1.0 / (n_u - 1)

    n = sum(o[c][k] for c in range(2) for k in range(2))
    if n == 0:
        return float("nan")

    # Marginal counts per category
    n_c = [sum(o[c][k] for k in range(2)) for c in range(2)]

    # Observed disagreement (nominal: δ=1 when c≠k)
    D_o = sum(o[c][k] for c in range(2) for k in range(2) if c != k) / n

    # Expected disagreement
    D_e_denom = n * (n - 1)
    if D_e_denom == 0:
        return float("nan")
    D_e = sum(n_c[c] * n_c[k] for c in range(2) for k in range(2) if c != k) / D_e_denom

    if D_e == 0.0:
        return 1.0 if D_o == 0.0 else float("nan")
    return 1.0 - D_o / D_e


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_rater_files(labels_dir: Path) -> Dict[str, Dict[str, Dict]]:
    """Return {rater_id: {transcript_id: {mode: bool|None}}}."""
    raters: Dict[str, Dict[str, Dict]] = {}
    for f in sorted(labels_dir.glob("labels_*.json")):
        with open(f, encoding="utf-8") as fh:
            data = json.load(fh)
        rater = data.get("rater") or f.stem
        raters[rater] = data.get("labels", {})
    return raters


def _majority_vote(votes: List[Optional[bool]]) -> Optional[bool]:
    """True/False majority; None if no valid votes."""
    valid = [v for v in votes if v is not None]
    if not valid:
        return None
    return sum(valid) > len(valid) / 2


# ---------------------------------------------------------------------------
# Main command
# ---------------------------------------------------------------------------

@app.command()
def compute(
    labels_dir: Path = typer.Option(BASE_DIR / "labels", help="Directory with labels_*.json files"),
    out: Path = typer.Option(BASE_DIR / "labels" / "gold_labels.json", help="Output path"),
    min_raters: int = typer.Option(2, help="Minimum raters required per transcript"),
) -> None:
    """Compute Fleiss' κ + Krippendorff's α, then write majority-vote gold labels."""
    raters = load_rater_files(labels_dir)

    if len(raters) < 2:
        console.print(
            f"[red]Need ≥2 rater files in {labels_dir}; found {len(raters)}.[/red]\n"
            "[yellow]Create them with: python -m labels.label_transcripts --rater rater_N[/yellow]"
        )
        raise typer.Exit(1)

    rater_ids = list(raters.keys())

    # Transcripts covered by ≥ min_raters raters
    all_tids: set[str] = set()
    for rd in raters.values():
        all_tids |= set(rd.keys())

    eligible = sorted(
        tid for tid in all_tids
        if sum(1 for rd in raters.values() if tid in rd) >= min_raters
    )

    console.print(f"\n[bold]Raters:[/bold]  {', '.join(rater_ids)}")
    console.print(f"[bold]Eligible transcripts (>={min_raters} raters):[/bold]  {len(eligible)}\n")

    iaa_summary: Dict[str, dict] = {}
    gold: Dict[str, Dict[str, Optional[bool]]] = {tid: {} for tid in eligible}

    tbl = Table(title="Inter-Annotator Agreement", show_header=True)
    tbl.add_column("Failure Mode", style="cyan", min_width=28)
    tbl.add_column("Fleiss κ", justify="right", min_width=9)
    tbl.add_column("Krippendorff α", justify="right", min_width=14)
    tbl.add_column("Reliable?", justify="center", min_width=10)
    tbl.add_column("Prevalence", justify="right", min_width=10)
    tbl.add_column("N units", justify="right", min_width=8)

    for mode in FAILURE_MODES:
        # Build ratings matrix: ratings[r][i]
        ratings_matrix: List[List[Optional[bool]]] = []
        for rid in rater_ids:
            rd = raters[rid]
            row: List[Optional[bool]] = []
            for tid in eligible:
                val = rd.get(tid, {}).get(mode)
                if val is None:
                    row.append(None)
                else:
                    row.append(bool(val))
            ratings_matrix.append(row)

        fk = fleiss_kappa(ratings_matrix)
        ka = krippendorff_alpha(ratings_matrix)
        reliable = (not math.isnan(fk)) and fk >= IAA_RELIABLE_THRESHOLD

        # Prevalence (proportion of True across all valid labels)
        all_vals = [v for row in ratings_matrix for v in row if v is not None]
        prevalence = sum(all_vals) / len(all_vals) if all_vals else 0.0

        # Majority-vote gold labels
        for i, tid in enumerate(eligible):
            votes = [ratings_matrix[r][i] for r in range(len(rater_ids))]
            gold[tid][mode] = _majority_vote(votes)

        iaa_summary[mode] = {
            "fleiss_kappa": round(fk, 4) if not math.isnan(fk) else None,
            "krippendorff_alpha": round(ka, 4) if not math.isnan(ka) else None,
            "reliable": reliable,
            "prevalence": round(prevalence, 4),
            "n_units": len(eligible),
        }

        fk_str = f"{fk:.3f}" if not math.isnan(fk) else "N/A"
        ka_str = f"{ka:.3f}" if not math.isnan(ka) else "N/A"
        rel_cell = "[green]YES[/green]" if reliable else "[red]NO[/red]"
        tbl.add_row(mode, fk_str, ka_str, rel_cell, f"{prevalence:.1%}", str(len(eligible)))

    console.print(tbl)

    reliable_count = sum(1 for v in iaa_summary.values() if v["reliable"])
    console.print(
        f"\n[bold]{reliable_count}/{len(FAILURE_MODES)} failure modes[/bold] "
        f"have reliable human labels (Fleiss κ ≥ {IAA_RELIABLE_THRESHOLD})\n"
    )

    output = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "n_raters": len(rater_ids),
        "rater_ids": rater_ids,
        "n_transcripts": len(eligible),
        "iaa_reliable_threshold": IAA_RELIABLE_THRESHOLD,
        "iaa_summary": iaa_summary,
        "labels": gold,
    }

    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, default=str)

    console.print(f"[green]Gold labels saved → {out}[/green]")


if __name__ == "__main__":
    app()
