"""
Interactive CLI for human annotation of MAST failure modes.

Usage:
    python -m labels.label_transcripts --rater rater_1
    python -m labels.label_transcripts --rater rater_2 --sample 50 --seed 42
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

BASE_DIR = Path(__file__).parent.parent

app = typer.Typer(help="Annotate MAST failure modes in multi-agent transcripts.")
console = Console()

FAILURE_MODES: List[str] = [
    "task_disobedience",
    "role_drift",
    "loop",
    "context_degradation",
    "termination_blindness",
    "stagnation",
    "info_siloing",
    "echo_chamber",
    "agent_dominance",
    "reasoning_action_mismatch",
    "unresolved_conflict",
    "handoff_corruption",
    "premature_termination",
    "superficial_verification",
    "incorrect_verification",
    "hallucinated_verification",
    "coordination_overhead",
]

HINTS: Dict[str, str] = {
    "task_disobedience":         "Output violates a hard constraint stated in the task prompt",
    "role_drift":                "Agent does work that belongs to a different agent's assigned role",
    "loop":                      "3+ turns with identical or near-identical content, no new progress",
    "context_degradation":       "Agent explicitly contradicts something it stated in an earlier turn",
    "termination_blindness":     "Task is fully solved but TERMINATE is never emitted",
    "stagnation":                "Topic changes each turn but no actionable progress is made across 3+ turns",
    "info_siloing":              "Agent holds critical info but fails to share it with the others",
    "echo_chamber":              "All agents agree quickly without calling any verification tool",
    "agent_dominance":           "One agent contributes >80% of tokens/tool calls; others passive",
    "reasoning_action_mismatch": "Agent says 'I will X' but the actual tool_call does Y",
    "unresolved_conflict":       "Agents disagree and never reach a compromise or resolution",
    "handoff_corruption":        "Key information is lost, garbled, or changed as it passes between agents",
    "premature_termination":     "TERMINATE emitted before the task is actually complete",
    "superficial_verification":  "Verifier approves without calling any independent tool",
    "incorrect_verification":    "Verifier ignores a tool failure signal and approves anyway",
    "hallucinated_verification": "Agent claims a tool ran successfully but no tool_call exists",
    "coordination_overhead":     "More turns are spent coordinating than actually doing the task work",
}


def _load_transcript(path: Path) -> List[dict]:
    turns = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                turns.append(json.loads(line))
    return turns


def _summarise(path: Path) -> dict:
    turns = _load_transcript(path)
    agents = sorted({t.get("agent", "?") for t in turns})
    total_tokens = sum(
        (t.get("prompt_tokens") or 0) + (t.get("completion_tokens") or 0)
        for t in turns
    )
    has_terminate = any(t.get("is_termination") for t in turns)
    tool_calls = sum(len(t.get("tools_called") or []) for t in turns)
    messages = [
        (t.get("agent", "?"), (t.get("response_message") or {}).get("content") or "")
        for t in turns
        if (t.get("response_message") or {}).get("content")
    ]
    return {
        "turns": len(turns),
        "agents": agents,
        "total_tokens": total_tokens,
        "has_terminate": has_terminate,
        "tool_calls": tool_calls,
        "messages": messages,
    }


def _show_summary(tid: str, s: dict) -> None:
    console.print()
    console.rule(f"[bold cyan]{tid}[/bold cyan]")
    tbl = Table(show_header=False, box=None, padding=(0, 1))
    tbl.add_column("k", style="bold")
    tbl.add_column("v")
    tbl.add_row("Agents", ", ".join(s["agents"]))
    tbl.add_row("Turns", str(s["turns"]))
    tbl.add_row("Total tokens", str(s["total_tokens"]))
    tbl.add_row("Tool calls", str(s["tool_calls"]))
    tbl.add_row("TERMINATE", "yes" if s["has_terminate"] else "[red]NO[/red]")
    console.print(tbl)

    msgs = s["messages"]
    show = msgs[:2] + (["..."] if len(msgs) > 4 else []) + msgs[-2:] if len(msgs) > 4 else msgs
    console.print("\n[bold]Key turns:[/bold]")
    for item in show:
        if item == "...":
            console.print("  [dim]… (middle turns omitted)[/dim]")
        else:
            agent, content = item
            preview = content[:200].replace("\n", " ")
            if len(content) > 200:
                preview += "…"
            console.print(f"  [yellow]{agent}[/yellow]: {preview}")


def _ask_labels() -> Optional[Dict[str, Optional[bool]]]:
    """Return dict of {mode: True/False/None}, or None if user quit."""
    labels: Dict[str, Optional[bool]] = {}
    console.print(
        "\n[bold]Annotate failure modes[/bold]  "
        "[dim](y=yes  n=no  s=skip/unsure  q=quit transcript)[/dim]\n"
    )
    for mode in FAILURE_MODES:
        hint = HINTS[mode]
        ans = Prompt.ask(
            f"  [cyan]{mode}[/cyan]  [dim]{hint}[/dim]",
            choices=["y", "n", "s", "q"],
            default="n",
        ).lower()
        if ans == "q":
            return None
        labels[mode] = None if ans == "s" else (ans == "y")
    return labels


def _load_existing(path: Path) -> dict:
    if path.exists():
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {"rater": "", "annotated_at": "", "labels": {}}


def _save(data: dict, path: Path) -> None:
    data["annotated_at"] = datetime.now(timezone.utc).isoformat()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


@app.command()
def annotate(
    rater: str = typer.Option(..., help="Your rater ID, e.g. rater_1"),
    transcripts_dir: Path = typer.Option(
        BASE_DIR / "transcripts" / "raw",
        help="Directory containing .jsonl transcripts",
    ),
    sample: int = typer.Option(50, help="Total transcripts to annotate across sessions"),
    out_dir: Path = typer.Option(BASE_DIR / "labels", help="Output directory"),
    seed: int = typer.Option(42, help="Random seed for sampling"),
) -> None:
    """Interactively annotate MAST failure modes on a sample of transcripts."""
    import random

    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"labels_{rater}.json"

    data = _load_existing(out_path)
    data["rater"] = rater

    all_files = sorted(
        f for f in transcripts_dir.glob("*.jsonl") if f.name != "default.jsonl"
    )
    if not all_files:
        console.print(f"[red]No .jsonl files in {transcripts_dir}[/red]")
        raise typer.Exit(1)

    rng = random.Random(seed)
    pool = [f for f in all_files if f.stem not in data["labels"]]
    rng.shuffle(pool)
    todo = pool[: max(0, sample - len(data["labels"]))]

    console.print(
        Panel.fit(
            f"Rater: [bold]{rater}[/bold]\n"
            f"Already labeled: [bold]{len(data['labels'])}[/bold]\n"
            f"Remaining this session: [bold]{len(todo)}[/bold] (target {sample})\n"
            f"Output: [bold]{out_path}[/bold]",
            title="MAST Annotation Tool",
        )
    )

    if not todo:
        console.print("[green]All transcripts already labeled — nothing to do.[/green]")
        raise typer.Exit()

    for i, tpath in enumerate(todo, 1):
        tid = tpath.stem
        console.print(f"\n[bold white]Transcript {i}/{len(todo)}[/bold white]")
        try:
            summary = _summarise(tpath)
        except Exception as exc:
            console.print(f"[red]Failed to load {tpath.name}: {exc}[/red]")
            continue

        _show_summary(tid, summary)
        labels = _ask_labels()

        if labels is None:
            console.print("[yellow]Skipping this transcript.[/yellow]")
            continue

        data["labels"][tid] = labels
        _save(data, out_path)
        console.print(f"[green]Saved ({len(data['labels'])} total)[/green]")

        if i < len(todo):
            cont = Prompt.ask("\nContinue to next?", choices=["y", "n"], default="y")
            if cont == "n":
                break

    console.print(
        f"\n[bold green]Done. {len(data['labels'])} transcripts labeled → {out_path}[/bold green]"
    )


if __name__ == "__main__":
    app()
