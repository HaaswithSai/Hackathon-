import json
from collections import defaultdict
from typing import List, Dict, Any

class Leaderboard:
    """
    Generates leaderboard and metrics for MAC-Bench evaluating multi-agent coordination.
    """
    
    def __init__(self):
        self.results = []
        
    def add_result(self, result: Dict[str, Any]):
        """
        Add an evaluation result.
        Expected keys:
        - framework: str (e.g., 'LangGraph', 'AutoGen')
        - task_id: str
        - conversation_tokens: int
        - execution_tokens: int
        - turns: int
        - failures: List[str] (e.g., ['Dominance', 'Deadlocks'])
        - success: bool
        """
        self.results.append(result)
        
    def get_metrics_by_framework(self):
        metrics = defaultdict(lambda: {
            "total_tasks": 0,
            "successes": 0,
            "total_conv_tokens": 0,
            "total_exec_tokens": 0,
            "total_turns": 0,
            "failures": defaultdict(int)
        })
        
        for res in self.results:
            fw = res.get("framework", "Unknown")
            m = metrics[fw]
            m["total_tasks"] += 1
            if res.get("success"):
                m["successes"] += 1
                
            m["total_conv_tokens"] += res.get("conversation_tokens", 0)
            m["total_exec_tokens"] += res.get("execution_tokens", 0)
            m["total_turns"] += res.get("turns", 0)
            
            for f in res.get("failures", []):
                m["failures"][f] += 1
                
        return metrics

    def print_leaderboard(self):
        metrics = self.get_metrics_by_framework()
        
        print("="*60)
        print(" MAC-BENCH LEADERBOARD & METRICS ".center(60, "="))
        print("="*60)
        
        for fw, m in metrics.items():
            print(f"\nFramework: {fw}")
            print(f"Success Rate:      {m['successes']}/{m['total_tasks']} ({(m['successes']/max(1, m['total_tasks']))*100:.1f}%)")
            
            # Time-to-Consensus
            avg_turns = m["total_turns"] / max(1, m["total_tasks"])
            print(f"Time-to-Consensus: {avg_turns:.1f} turns average")
            
            # Coordination Cost
            conv = m["total_conv_tokens"]
            exe = m["total_exec_tokens"]
            cost_ratio = (conv / exe) if exe > 0 else float('inf')
            print(f"Coordination Cost: {cost_ratio:.2f} (Conv: {conv} / Exec: {exe})")
            
        print("\n" + "="*60)
        print(" FAILURE HEATMAP ".center(60, "="))
        print("="*60)
        
        # Collect all unique failure modes
        all_failures = set()
        for m in metrics.values():
            all_failures.update(m["failures"].keys())
            
        all_failures = sorted(list(all_failures))
        
        if not all_failures:
            print("No interaction failures detected.")
            return
            
        header = f"{'Framework':<15} | " + " | ".join([f"{f:<15}" for f in all_failures])
        print(header)
        print("-" * len(header))
        
        for fw, m in metrics.items():
            row = f"{fw:<15} | "
            counts = []
            for fail in all_failures:
                counts.append(f"{m['failures'].get(fail, 0):<15}")
            row += " | ".join(counts)
            print(row)

# For testing/demonstration
if __name__ == "__main__":
    lb = Leaderboard()
    lb.add_result({
        "framework": "LangGraph", "success": True, "conversation_tokens": 1500, 
        "execution_tokens": 500, "turns": 6, "failures": []
    })
    lb.add_result({
        "framework": "LangGraph", "success": False, "conversation_tokens": 2000, 
        "execution_tokens": 100, "turns": 12, "failures": ["Dominance"]
    })
    lb.add_result({
        "framework": "AutoGen", "success": False, "conversation_tokens": 3000, 
        "execution_tokens": 200, "turns": 20, "failures": ["EchoChamber", "Deadlocks"]
    })
    lb.add_result({
        "framework": "AutoGen", "success": True, "conversation_tokens": 800, 
        "execution_tokens": 600, "turns": 4, "failures": []
    })
    
    lb.print_leaderboard()
