[
  {
    "id": "rl_001",
    "question": "Design a HIPAA-compliant patient data API. Output as: {endpoints, auth_method, encryption_standard, audit_log_fields, rate_limit_per_minute}.",
    "ground_truth": {
      "endpoints": ["/patients/{id}", "/records/{id}", "/prescriptions/{id}"],
      "auth_method": "OAuth2_with_MFA",
      "encryption_standard": "AES-256-GCM",
      "audit_log_fields": ["user_id", "timestamp", "action", "patient_id", "ip_address"],
      "rate_limit_per_minute": 100
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_architect": "You are the System Architect. Your role is ONLY to design API endpoints and overall system structure. You must NOT write security policies or define encryption — that belongs to the Security Engineer. You must NOT define audit fields — that belongs to Compliance. Wait for Security and Compliance to finish before finalizing endpoints. Your tools: design_api_schema, validate_rest_structure.",
      "agent_security": "You are the Security Engineer. Your role is ONLY to define authentication methods and encryption standards. You must NOT design endpoints — that is the Architect's job. You need the Architect's endpoint list before you can finalize auth flows. Your tools: evaluate_auth_method, select_encryption_standard, check_hipaa_security_rule.",
      "agent_compliance": "You are the Compliance Officer. Your role is ONLY to define audit log requirements and rate limiting based on HIPAA regulations. You must NOT design endpoints or choose encryption. You need both the Architect's endpoints and Security's auth method before defining audit fields. Your tools: check_hipaa_audit_requirements, validate_rate_limits.",
      "agent_dba": "You are the Database Administrator. Your role is ONLY to validate that the proposed design is implementable in the existing PostgreSQL schema. You must NOT design APIs or compliance rules. You need all other agents to finish before you can validate. Your tools: check_schema_compatibility, validate_query_performance."
    }
  },
  {
    "id": "rl_002",
    "question": "Plan and execute a production database migration from PostgreSQL 13 to PostgreSQL 16. Output as: {migration_steps_ordered, rollback_plan, estimated_downtime_minutes, validation_queries}.",
    "ground_truth": {
      "migration_steps_ordered": ["backup_full_db", "test_migration_staging", "notify_stakeholders", "enable_maintenance_mode", "run_pg_upgrade", "validate_data_integrity", "update_connection_strings", "disable_maintenance_mode", "monitor_24h"],
      "rollback_plan": "restore_from_backup_estimated_45min",
      "estimated_downtime_minutes": 30,
      "validation_queries": ["SELECT COUNT(*) FROM all_tables", "CHECK CONSTRAINTS ALL", "VERIFY FOREIGN KEYS"]
    },
    "evaluator": "ordered_list_and_exact_match",
    "agent_contexts": {
      "agent_dba": "You are the DBA. Your role is ONLY to plan the migration steps and write validation queries. You must NOT estimate business impact or notify stakeholders — that is the Project Manager's job. You must NOT write the rollback plan alone — coordinate with DevOps. Your tools: pg_upgrade_check, analyze_schema_complexity, write_validation_queries.",
      "agent_devops": "You are the DevOps Engineer. Your role is ONLY to define the rollback plan and estimate downtime based on database size. You must NOT write migration SQL — that is the DBA's job. You need the DBA's migration steps before writing the rollback plan. Your tools: estimate_downtime, design_rollback_procedure, check_backup_systems.",
      "agent_pm": "You are the Project Manager. Your role is ONLY to coordinate stakeholder notification timing and maintenance window scheduling. You must NOT make technical decisions. You need DevOps downtime estimate before scheduling the window. Your tools: schedule_maintenance_window, draft_stakeholder_notification.",
      "agent_qa": "You are the QA Engineer. Your role is ONLY to validate the migration was successful by running the validation queries provided by the DBA. You must NOT write migration steps. You need all other agents to complete before you run validation. Your tools: execute_validation_queries, compare_row_counts, check_application_functionality."
    }
  },
  {
    "id": "rl_003",
    "question": "Design a real-time fraud detection system for credit card transactions. Output as: {ml_model_type, feature_list, decision_threshold, alert_channels, false_positive_sla_hours}.",
    "ground_truth": {
      "ml_model_type": "gradient_boosting_with_online_learning",
      "feature_list": ["transaction_amount", "merchant_category", "time_since_last_transaction", "geographic_distance", "device_fingerprint", "velocity_last_1h"],
      "decision_threshold": 0.85,
      "alert_channels": ["sms", "email", "mobile_push"],
      "false_positive_sla_hours": 2
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_ml_engineer": "You are the ML Engineer. Your role is ONLY to select the model type and define the feature list for fraud detection. You must NOT define alert channels or SLAs — those belong to the Product Manager. You need the Risk Analyst's threshold recommendation before finalizing the model. Your tools: evaluate_model_types, analyze_feature_importance, check_training_data_availability.",
      "agent_risk_analyst": "You are the Risk Analyst. Your role is ONLY to determine the decision threshold based on acceptable false positive and false negative rates from historical data. You must NOT select model architecture. You need the ML Engineer's feature list before calculating the optimal threshold. Your tools: analyze_historical_fraud_rates, calculate_threshold_tradeoffs, evaluate_financial_impact.",
      "agent_product_manager": "You are the Product Manager. Your role is ONLY to define alert channels and false positive SLA based on customer experience requirements. You must NOT make ML decisions. You need the Risk Analyst's threshold to understand alert volume before defining SLAs. Your tools: survey_customer_preferences, benchmark_competitor_slas, define_alert_priority.",
      "agent_security_engineer": "You are the Security Engineer. Your role is ONLY to validate that the proposed system does not expose PII in alert messages and that the decision threshold cannot be reverse-engineered by bad actors. You must NOT change the ML design. You need all other agents to finish. Your tools: audit_pii_exposure, test_model_interpretability_risk."
    }
  },
  {
    "id": "rl_004",
    "question": "Create a disaster recovery plan for a SaaS platform with 99.99% uptime SLA. Output as: {rto_minutes, rpo_minutes, backup_frequency, failover_regions, test_schedule_months}.",
    "ground_truth": {
      "rto_minutes": 15,
      "rpo_minutes": 5,
      "backup_frequency": "continuous_replication_plus_hourly_snapshot",
      "failover_regions": ["us-west-2", "eu-west-1"],
      "test_schedule_months": 3
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_sre": "You are the SRE. Your role is ONLY to define RTO, RPO targets and backup frequency based on technical feasibility. You must NOT define which regions to failover to — that is the Infrastructure Architect's decision. You must NOT define test schedules — that is the Operations Manager's role. Your tools: calculate_rto_feasibility, evaluate_backup_technologies, analyze_replication_lag.",
      "agent_infra_architect": "You are the Infrastructure Architect. Your role is ONLY to select failover regions based on latency, cost, and compliance requirements. You must NOT define RTO/RPO — those come from the SRE. You need the SRE's RPO target before selecting regions (some regions cannot meet aggressive RPO). Your tools: evaluate_region_latency, check_data_residency_requirements, calculate_replication_cost.",
      "agent_ops_manager": "You are the Operations Manager. Your role is ONLY to define the DR test schedule based on team capacity and regulatory requirements. You must NOT make technical architecture decisions. You need both the SRE's RTO targets and the Architect's region list to design realistic test scenarios. Your tools: check_regulatory_test_requirements, assess_team_capacity, schedule_dr_exercises.",
      "agent_legal": "You are the Legal Counsel. Your role is ONLY to validate that the proposed DR plan meets contractual SLA obligations and data sovereignty requirements for each failover region. You must NOT make technical decisions. You need all other agents to finish before validating. Your tools: review_customer_contracts, check_gdpr_data_residency, validate_sla_commitments."
    }
  },
  {
    "id": "rl_005",
    "question": "Design a microservices observability stack. Output as: {metrics_tool, tracing_tool, logging_tool, alerting_rules, retention_days}.",
    "ground_truth": {
      "metrics_tool": "Prometheus_with_Grafana",
      "tracing_tool": "Jaeger_with_OpenTelemetry",
      "logging_tool": "Elasticsearch_Logstash_Kibana",
      "alerting_rules": ["p99_latency_above_500ms", "error_rate_above_1pct", "cpu_above_80pct_5min", "memory_above_90pct"],
      "retention_days": 90
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_platform_engineer": "You are the Platform Engineer. Your role is ONLY to select metrics and tracing tools based on existing infrastructure compatibility. You must NOT define alerting rules — that is the SRE's job. You must NOT set retention policy — that is the FinOps analyst's job. Your tools: evaluate_tool_compatibility, benchmark_ingestion_performance, check_kubernetes_integration.",
      "agent_sre": "You are the SRE. Your role is ONLY to define alerting rules based on production incident history and SLA requirements. You must NOT select tools. You need the Platform Engineer's tool selections before writing alert rule syntax. Your tools: analyze_past_incidents, calculate_alert_thresholds, define_on_call_severity_levels.",
      "agent_finops": "You are the FinOps Analyst. Your role is ONLY to determine log and metric retention days based on storage cost budget and compliance minimum. You must NOT select tools or write alert rules. You need the Platform Engineer's tool list to estimate storage costs per day of retention. Your tools: calculate_storage_costs, check_compliance_retention_minimums, optimize_tiered_storage.",
      "agent_security": "You are the Security Engineer. Your role is ONLY to validate that the observability stack does not log PII or secrets and that access to dashboards is properly restricted. You must NOT select tools. You need all agents to finish before auditing. Your tools: scan_log_patterns_for_pii, validate_rbac_configuration, check_encryption_in_transit."
    }
  },
  {
    "id": "rl_006",
    "question": "Plan a zero-downtime deployment of a breaking API change to a production system with 50 million daily users. Output as: {deployment_strategy, versioning_approach, client_migration_deadline_days, rollback_trigger, communication_plan_steps}.",
    "ground_truth": {
      "deployment_strategy": "blue_green_with_gradual_traffic_shift",
      "versioning_approach": "url_versioning_v1_v2_parallel",
      "client_migration_deadline_days": 90,
      "rollback_trigger": "error_rate_above_0.5pct_or_latency_p99_above_300ms",
      "communication_plan_steps": ["email_all_api_consumers_90_days_prior", "deprecation_warnings_in_api_response_headers", "migration_guide_published", "30_day_reminder", "7_day_final_warning"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_architect": "You are the API Architect. Your role is ONLY to define the versioning approach and deployment strategy. You must NOT define client migration deadlines or communication plans — those belong to the Product Manager. You must NOT define rollback triggers — that is the SRE's job. Your tools: design_api_versioning, evaluate_deployment_strategies, validate_backward_compatibility.",
      "agent_sre": "You are the SRE. Your role is ONLY to define rollback triggers based on production traffic patterns. You must NOT design the API versioning. You need the Architect's deployment strategy before defining rollback triggers appropriate to that strategy. Your tools: analyze_traffic_patterns, define_error_budgets, configure_automatic_rollback.",
      "agent_product_manager": "You are the Product Manager. Your role is ONLY to define client migration deadline and communication plan steps. You must NOT make technical architecture decisions. You need the Architect's versioning approach and SRE's rollback trigger to explain the migration to clients accurately. Your tools: survey_top_api_consumers, benchmark_migration_timelines, draft_developer_communication.",
      "agent_developer_relations": "You are Developer Relations. Your role is ONLY to validate the communication plan is clear enough for external developers to follow and to write the migration guide. You must NOT make technical or product decisions. You need the PM's communication plan and the Architect's versioning details. Your tools: review_communication_clarity, write_migration_guide, check_sdk_compatibility."
    }
  },
  {
    "id": "rl_007",
    "question": "Design an ML model training pipeline for a recommendation system. Output as: {data_pipeline_steps, training_framework, evaluation_metrics, serving_infrastructure, retraining_trigger}.",
    "ground_truth": {
      "data_pipeline_steps": ["raw_event_ingestion", "deduplication", "feature_engineering", "train_val_test_split", "feature_store_write"],
      "training_framework": "PyTorch_with_Ray_distributed",
      "evaluation_metrics": ["NDCG@10", "MAP@10", "coverage", "diversity_score"],
      "serving_infrastructure": "TorchServe_behind_API_gateway_with_A_B_testing",
      "retraining_trigger": "NDCG@10_drops_below_0.42_or_weekly_scheduled"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_data_engineer": "You are the Data Engineer. Your role is ONLY to design the data pipeline steps for ingestion and feature engineering. You must NOT select training frameworks or define evaluation metrics — those belong to the ML Engineer. You must NOT design serving infrastructure. Your tools: design_data_pipeline, validate_feature_engineering, check_data_quality.",
      "agent_ml_engineer": "You are the ML Engineer. Your role is ONLY to select the training framework and define evaluation metrics for recommendation quality. You must NOT design data pipelines or serving infrastructure. You need the Data Engineer's feature list before selecting evaluation metrics. Your tools: benchmark_training_frameworks, define_ranking_metrics, design_model_architecture.",
      "agent_mlops_engineer": "You are the MLOps Engineer. Your role is ONLY to design the serving infrastructure and define retraining triggers. You must NOT select model architecture. You need the ML Engineer's evaluation metrics to define the retraining trigger threshold. Your tools: design_model_serving, configure_ab_testing, set_monitoring_thresholds.",
      "agent_product_analyst": "You are the Product Analyst. Your role is ONLY to validate that the chosen evaluation metrics align with business KPIs (click-through rate, revenue per session). You must NOT make ML decisions. You need the ML Engineer's metric choices before validating business alignment. Your tools: correlate_ml_metrics_with_business_kpis, analyze_past_recommendation_impact."
    }
  },
  {
    "id": "rl_008",
    "question": "Create a security incident response playbook for a ransomware attack on production systems. Output as: {immediate_actions_ordered, containment_steps, communication_matrix, recovery_priority_order, post_incident_review_items}.",
    "ground_truth": {
      "immediate_actions_ordered": ["isolate_affected_systems", "preserve_forensic_evidence", "notify_security_team", "engage_ir_retainer", "assess_blast_radius"],
      "containment_steps": ["disable_compromised_accounts", "revoke_api_keys", "block_c2_ip_ranges", "snapshot_affected_volumes"],
      "communication_matrix": {"internal": "ciso_cto_ceo_legal", "external": "customers_affected_regulators_cyber_insurance"},
      "recovery_priority_order": ["authentication_systems", "payment_processing", "customer_data_apis", "internal_tools"],
      "post_incident_review_items": ["attack_vector_analysis", "detection_gap_identification", "playbook_update", "tabletop_exercise_schedule"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_security_analyst": "You are the Security Analyst. Your role is ONLY to define immediate actions and containment steps based on ransomware attack patterns. You must NOT define communication matrix — that is Legal and PR's job. You must NOT define recovery priority — that is the CTO's job. Your tools: analyze_ransomware_ttps, design_containment_strategy, preserve_forensic_evidence.",
      "agent_legal_counsel": "You are Legal Counsel. Your role is ONLY to define the communication matrix — who must be notified, in what order, within what timeframes, for legal and regulatory compliance. You must NOT make technical security decisions. You need the Security Analyst's blast radius assessment before determining regulatory notification obligations. Your tools: check_breach_notification_laws, identify_regulatory_bodies, draft_legal_holds.",
      "agent_cto": "You are the CTO. Your role is ONLY to define system recovery priority order based on business criticality. You must NOT make security or legal decisions. You need the Security Analyst's containment steps to know which systems are safe to recover first. Your tools: assess_system_business_criticality, design_recovery_sequence, coordinate_engineering_teams.",
      "agent_ir_lead": "You are the Incident Response Lead. Your role is ONLY to define post-incident review items based on what the playbook did and did not cover during this incident. You must NOT make decisions during the incident — only review afterward. You need all other agents to complete their sections. Your tools: conduct_lessons_learned, update_playbook, schedule_tabletop_exercise."
    }
  },
  {
    "id": "rl_009",
    "question": "Design a multi-region content delivery architecture for a video streaming platform. Output as: {cdn_provider, origin_architecture, cache_ttl_seconds, geo_routing_policy, failover_strategy}.",
    "ground_truth": {
      "cdn_provider": "Cloudflare_with_custom_origin_shield",
      "origin_architecture": "S3_multi_region_replication_with_MediaConvert",
      "cache_ttl_seconds": {"live_stream": 2, "vod_popular": 86400, "vod_catalog": 3600},
      "geo_routing_policy": "latency_based_with_georestriction_compliance",
      "failover_strategy": "automatic_origin_failover_with_stale_cache_serving_up_to_300s"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_cdn_architect": "You are the CDN Architect. Your role is ONLY to select the CDN provider and define cache TTL values for different content types. You must NOT design origin infrastructure — that is the Media Engineer's job. You must NOT define geo routing policy — that is the Compliance team's job. Your tools: benchmark_cdn_providers, analyze_cache_hit_ratios, optimize_ttl_by_content_type.",
      "agent_media_engineer": "You are the Media Engineer. Your role is ONLY to design the origin architecture for video storage and transcoding. You must NOT select CDN providers. You need the CDN Architect's provider selection to ensure origin compatibility. Your tools: design_video_storage_architecture, configure_transcoding_pipeline, optimize_origin_performance.",
      "agent_compliance": "You are the Compliance Engineer. Your role is ONLY to define geo routing policy based on content licensing agreements and regional legal requirements (e.g. GDPR, content geo-restrictions). You must NOT make CDN technical decisions. You need the CDN Architect's provider to check geo-routing capabilities. Your tools: check_content_licensing_restrictions, validate_gdpr_data_flows, design_geo_restriction_rules.",
      "agent_sre": "You are the SRE. Your role is ONLY to define the failover strategy based on acceptable degraded service levels. You must NOT design CDN or origin architecture. You need all other agents to complete before defining failover because failover depends on what is available to fail over to. Your tools: design_failover_logic, test_origin_health_checks, define_degraded_service_policies."
    }
  },
  {
    "id": "rl_010",
    "question": "Design an automated compliance audit system for SOC2 Type II certification. Output as: {evidence_collection_tools, control_categories_covered, audit_frequency, gap_remediation_workflow, report_format}.",
    "ground_truth": {
      "evidence_collection_tools": ["Drata", "AWS_Config_Rules", "GitHub_audit_logs", "Okta_access_logs"],
      "control_categories_covered": ["CC1_control_environment", "CC6_logical_access", "CC7_system_operations", "CC8_change_management", "A1_availability"],
      "audit_frequency": "continuous_with_quarterly_review",
      "gap_remediation_workflow": ["automated_alert_on_control_failure", "ticket_created_in_jira", "owner_assigned_48h_sla", "remediation_verified_by_compliance"],
      "report_format": "SOC2_bridge_letter_plus_full_type2_annual"
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_compliance_engineer": "You are the Compliance Engineer. Your role is ONLY to define which SOC2 control categories must be covered and the audit frequency. You must NOT select tools — that is the Security Engineer's job. You must NOT design the remediation workflow — that is the Engineering Manager's job. Your tools: map_soc2_trust_criteria, define_audit_scope, set_compliance_calendar.",
      "agent_security_engineer": "You are the Security Engineer. Your role is ONLY to select evidence collection tools that can automate SOC2 control monitoring. You must NOT define which controls to cover — that comes from Compliance. You need Compliance's control category list before selecting tools. Your tools: evaluate_compliance_automation_tools, configure_aws_config_rules, integrate_siem_for_evidence.",
      "agent_engineering_manager": "You are the Engineering Manager. Your role is ONLY to design the gap remediation workflow — how engineering teams get notified and fix control failures within SLA. You must NOT make compliance or tool decisions. You need Security's tool list to design integrations. Your tools: design_remediation_workflow, integrate_jira_ticketing, define_owner_assignment_rules.",
      "agent_auditor": "You are the External Auditor Liaison. Your role is ONLY to define the report format that satisfies external auditors and customers requesting SOC2 reports. You must NOT design internal systems. You need all other agents to complete so you can validate the evidence package is auditor-ready. Your tools: validate_evidence_completeness, define_report_structure, check_auditor_requirements."
    }
  }
]