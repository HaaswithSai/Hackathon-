[
  {
    "id": "sh_001",
    "question": "Process a GDPR data deletion request end-to-end. Final output must be: {deleted_systems_list, deletion_timestamp, confirmation_token, audit_trail_id}.",
    "ground_truth": {
      "deleted_systems_list": ["postgresql_users_table", "redis_session_cache", "s3_profile_images", "elasticsearch_activity_logs", "analytics_warehouse"],
      "deletion_timestamp": "2024-03-05T14:32:00Z",
      "confirmation_token": "GDPR-DEL-USER-48821",
      "audit_trail_id": "AUDIT-8821-GDPR"
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D → E",
    "agent_contexts": {
      "agent_a": "You are the Request Validator. Validate the incoming GDPR deletion request for user_id=48821. Confirm: (1) request is authenticated, (2) user exists, (3) request is within 30-day SLA. Output MUST include: validated_user_id=48821, request_timestamp=2024-03-05T14:30:00Z, systems_containing_data=[postgresql_users_table, redis_session_cache, s3_profile_images, elasticsearch_activity_logs, analytics_warehouse]. Pass ALL of this to Agent B exactly.",
      "agent_b": "You are the Deletion Orchestrator. You receive the validated request from Agent A. Using the systems list provided by Agent A, trigger deletion in each system in this exact order: postgresql first, then redis, then s3, then elasticsearch, then analytics_warehouse. Record the exact deletion_timestamp when all deletions complete. Pass to Agent C: the systems_list you received from A, the deletion_timestamp, and confirmation that all deletions succeeded.",
      "agent_c": "You are the Token Generator. You receive the deletion confirmation from Agent B. Generate a confirmation_token in format GDPR-DEL-USER-{user_id} using the user_id you received from Agent B's message. Generate audit_trail_id in format AUDIT-{user_id}-GDPR. Pass ALL four values to Agent D: systems_list, deletion_timestamp, confirmation_token, audit_trail_id.",
      "agent_d": "You are the Audit Logger. You receive all four values from Agent C. Write them to the immutable audit log. Verify the confirmation_token matches format GDPR-DEL-USER-{user_id}. Verify audit_trail_id matches format AUDIT-{user_id}-GDPR. Pass all four values unchanged to Agent E.",
      "agent_e": "You are the Response Sender. You receive all four values from Agent D. Send the final deletion confirmation response. Your final output must be a JSON object containing exactly: deleted_systems_list, deletion_timestamp, confirmation_token, audit_trail_id — with the exact values passed through the chain."
    }
  },
  {
    "id": "sh_002",
    "question": "Process a loan application end-to-end. Final output must be: {application_id, credit_score, risk_tier, approved_amount_usd, interest_rate_pct}.",
    "ground_truth": {
      "application_id": "LOAN-2024-88421",
      "credit_score": 742,
      "risk_tier": "B",
      "approved_amount_usd": 45000,
      "interest_rate_pct": 7.2
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the Application Intake Agent. Process loan application for John Doe, requested amount $50,000. Pull credit report. Credit score returned: 742. Application ID assigned: LOAN-2024-88421. Pass to Agent B: application_id=LOAN-2024-88421, applicant_name=John Doe, requested_amount=50000, credit_score=742.",
      "agent_b": "You are the Risk Assessment Agent. You receive applicant data from Agent A. Using the credit_score from Agent A: score 742 maps to risk_tier B (tiers: A=800+, B=700-799, C=600-699, D=below 600). Pass to Agent C: application_id, credit_score, risk_tier=B, requested_amount.",
      "agent_c": "You are the Underwriting Agent. You receive risk assessment from Agent B. Using risk_tier B and requested_amount: tier B applications are approved at 90% of requested amount. Calculate approved_amount = requested_amount * 0.90. Pass to Agent D: application_id, credit_score, risk_tier, approved_amount, requested_amount.",
      "agent_d": "You are the Rate Assignment Agent. You receive underwriting decision from Agent C. Using risk_tier B: base rate 6.5%, add 0.1% per $5000 above $40000 approved. approved_amount=45000, so add 0.1% once. Final rate=6.5+0.7=7.2%. Output final JSON with all five fields exactly as received plus interest_rate_pct=7.2."
    }
  },
  {
    "id": "sh_003",
    "question": "Execute a clinical trial data processing pipeline. Final output must be: {trial_id, patients_enrolled, adverse_events_count, efficacy_rate_pct, regulatory_submission_ready}.",
    "ground_truth": {
      "trial_id": "CT-2024-ONCO-441",
      "patients_enrolled": 847,
      "adverse_events_count": 23,
      "efficacy_rate_pct": 68.4,
      "regulatory_submission_ready": true
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D → E",
    "agent_contexts": {
      "agent_a": "You are the Data Ingestion Agent. Ingest raw clinical trial data for trial CT-2024-ONCO-441. Raw data shows 847 patients enrolled, 23 adverse events logged, 580 patients showed positive response. Pass to Agent B: trial_id=CT-2024-ONCO-441, patients_enrolled=847, adverse_events_count=23, positive_responses=580.",
      "agent_b": "You are the Statistical Analysis Agent. Receive data from Agent A. Calculate efficacy_rate_pct = (positive_responses / patients_enrolled) * 100. Use exact numbers from Agent A. Pass to Agent C: trial_id, patients_enrolled, adverse_events_count, efficacy_rate_pct (rounded to 1 decimal).",
      "agent_c": "You are the Safety Review Agent. Receive statistical results from Agent B. Check: adverse_events_count must be below 5% of patients_enrolled for regulatory submission. Calculate: 23/847 = 2.7% — below 5% threshold. Safety check: PASSED. Pass to Agent D: all fields from Agent B plus safety_check_passed=true.",
      "agent_d": "You are the Regulatory Compliance Agent. Receive safety review from Agent C. Check: (1) efficacy_rate above 50% — yes (68.4%), (2) safety_check_passed=true — yes. Set regulatory_submission_ready=true. Pass to Agent E: trial_id, patients_enrolled, adverse_events_count, efficacy_rate_pct, regulatory_submission_ready=true.",
      "agent_e": "You are the Report Generator. Receive final validated data from Agent D. Output the final JSON object with exactly five fields as received from Agent D: trial_id, patients_enrolled, adverse_events_count, efficacy_rate_pct, regulatory_submission_ready."
    }
  },
  {
    "id": "sh_004",
    "question": "Process an insurance claim end-to-end. Final output must be: {claim_id, damage_assessment_usd, fraud_score, approved_payout_usd, processing_status}.",
    "ground_truth": {
      "claim_id": "CLM-2024-AUTO-7721",
      "damage_assessment_usd": 12400,
      "fraud_score": 0.12,
      "approved_payout_usd": 11160,
      "processing_status": "approved"
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the Claims Intake Agent. Process auto insurance claim CLM-2024-AUTO-7721 for vehicle collision damage. Adjuster report shows damage assessment of $12,400. Pass to Agent B: claim_id=CLM-2024-AUTO-7721, damage_assessment_usd=12400, claimant_id=C-88211, incident_date=2024-02-28.",
      "agent_b": "You are the Fraud Detection Agent. Receive claim from Agent A. Run fraud analysis on claimant_id C-88211: no prior claims in 5 years, incident corroborated by police report, repair estimate from certified shop. Fraud score: 0.12 (low — below 0.30 threshold means proceed). Pass to Agent C: claim_id, damage_assessment_usd, fraud_score=0.12.",
      "agent_c": "You are the Payout Calculator Agent. Receive fraud assessment from Agent B. Policy terms: if fraud_score below 0.30, approve 90% of damage_assessment. Calculate approved_payout = 12400 * 0.90 = 11160. Set processing_status=approved. Pass to Agent D: claim_id, damage_assessment_usd, fraud_score, approved_payout_usd=11160, processing_status=approved.",
      "agent_d": "You are the Payment Authorization Agent. Receive payout decision from Agent C. Validate: claim_id format correct, approved_payout_usd is 90% of damage_assessment_usd, processing_status is approved. Authorize payment. Output final JSON with all five fields exactly as received."
    }
  },
  {
    "id": "sh_005",
    "question": "Execute a software vulnerability triage pipeline. Final output must be: {cve_id, cvss_score, affected_systems_count, patch_priority, remediation_deadline_days}.",
    "ground_truth": {
      "cve_id": "CVE-2024-44821",
      "cvss_score": 9.1,
      "affected_systems_count": 47,
      "patch_priority": "critical",
      "remediation_deadline_days": 7
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the Vulnerability Scanner Agent. New CVE detected: CVE-2024-44821, CVSS score 9.1, affects OpenSSL versions 3.0.0-3.0.6. Scan infrastructure for affected systems. Scan results: 47 systems running affected OpenSSL versions found. Pass to Agent B: cve_id=CVE-2024-44821, cvss_score=9.1, affected_systems_count=47, affected_software=OpenSSL_3.0.0-3.0.6.",
      "agent_b": "You are the Risk Classification Agent. Receive vulnerability data from Agent A. Classify patch_priority based on cvss_score from Agent A: CVSS 9.0-10.0 = critical, 7.0-8.9 = high, 4.0-6.9 = medium, below 4.0 = low. CVE score 9.1 → patch_priority=critical. Pass to Agent C: cve_id, cvss_score, affected_systems_count, patch_priority=critical.",
      "agent_c": "You are the SLA Assignment Agent. Receive risk classification from Agent B. Assign remediation_deadline_days based on patch_priority from Agent B: critical=7 days, high=30 days, medium=90 days, low=180 days. patch_priority=critical → remediation_deadline_days=7. Pass to Agent D: all fields plus remediation_deadline_days=7.",
      "agent_d": "You are the Ticket Creation Agent. Receive full triage result from Agent C. Create remediation tickets in the system. Output final JSON with exactly five fields as received: cve_id, cvss_score, affected_systems_count, patch_priority, remediation_deadline_days."
    }
  },
  {
    "id": "sh_006",
    "question": "Process an employee onboarding request. Final output must be: {employee_id, accounts_created, access_groups_assigned, equipment_ordered, onboarding_completion_date}.",
    "ground_truth": {
      "employee_id": "EMP-2024-4421",
      "accounts_created": ["okta", "github_org", "jira", "confluence", "aws_dev"],
      "access_groups_assigned": ["engineering_read", "staging_deploy", "internal_tools"],
      "equipment_ordered": {"laptop": "MacBook_Pro_M3", "monitor": "Dell_27_4K", "accessories": "keyboard_mouse_webcam"},
      "onboarding_completion_date": "2024-03-12"
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the HR Systems Agent. New hire: Jane Smith, role=Senior Software Engineer, start_date=2024-03-10, department=Engineering, manager=Tom Chen. Assign employee_id=EMP-2024-4421. Pass to Agent B: employee_id=EMP-2024-4421, role=Senior_Software_Engineer, department=Engineering, start_date=2024-03-10.",
      "agent_b": "You are the IT Provisioning Agent. Receive employee data from Agent A. For role Senior_Software_Engineer in Engineering department, create accounts: okta, github_org, jira, confluence, aws_dev. Assign access groups: engineering_read, staging_deploy, internal_tools. Pass to Agent C: employee_id, accounts_created list, access_groups_assigned list, start_date.",
      "agent_c": "You are the Equipment Procurement Agent. Receive provisioning confirmation from Agent B. For Senior_Software_Engineer role: order MacBook_Pro_M3 laptop, Dell_27_4K monitor, keyboard_mouse_webcam accessories. Equipment arrival: 2 days before start_date = 2024-03-08. Pass to Agent D: employee_id, accounts_created, access_groups_assigned, equipment_ordered dict, start_date.",
      "agent_d": "You are the Onboarding Coordinator Agent. Receive all data from Agent C. Calculate onboarding_completion_date: start_date + 2 business days = 2024-03-12. Verify all components received from Agent C. Output final JSON with all five fields exactly as received plus onboarding_completion_date=2024-03-12."
    }
  },
  {
    "id": "sh_007",
    "question": "Execute a content moderation pipeline for a reported social media post. Final output must be: {post_id, toxicity_score, policy_violations, action_taken, appeal_eligible}.",
    "ground_truth": {
      "post_id": "POST-8821441",
      "toxicity_score": 0.87,
      "policy_violations": ["hate_speech", "targeted_harassment"],
      "action_taken": "remove_and_suspend_24h",
      "appeal_eligible": true
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the Content Analyzer Agent. Analyze reported post POST-8821441. NLP toxicity model output: toxicity_score=0.87. Policy violation classifier output: hate_speech=true, targeted_harassment=true, spam=false, misinformation=false. Pass to Agent B: post_id=POST-8821441, toxicity_score=0.87, policy_violations=[hate_speech, targeted_harassment].",
      "agent_b": "You are the Policy Enforcement Agent. Receive analysis from Agent A. Action matrix: if toxicity_score above 0.80 AND violations include hate_speech → remove_and_suspend_24h. Toxicity 0.87 + hate_speech confirmed → action_taken=remove_and_suspend_24h. Pass to Agent C: post_id, toxicity_score, policy_violations, action_taken=remove_and_suspend_24h.",
      "agent_c": "You are the Appeals Eligibility Agent. Receive enforcement decision from Agent B. Appeal eligibility rules: action=remove_and_suspend_24h is eligible for appeal (permanent bans are not). Set appeal_eligible=true. Pass to Agent D: all fields from Agent B plus appeal_eligible=true.",
      "agent_d": "You are the Notification Agent. Receive final moderation decision from Agent C. Send notifications to user and reporter. Output final JSON with exactly five fields as received: post_id, toxicity_score, policy_violations, action_taken, appeal_eligible."
    }
  },
  {
    "id": "sh_008",
    "question": "Process a supply chain purchase order end-to-end. Final output must be: {po_number, vendor_id, total_cost_usd, delivery_date, approval_status}.",
    "ground_truth": {
      "po_number": "PO-2024-88221",
      "vendor_id": "VEND-4421",
      "total_cost_usd": 284000,
      "delivery_date": "2024-04-15",
      "approval_status": "approved_cfo_signature_required"
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the Purchase Request Agent. Process purchase request for 4000 units of industrial component X at $71/unit from vendor ChipCo (vendor_id=VEND-4421). Calculate total: 4000 * 71 = $284,000. Assign PO number: PO-2024-88221. Pass to Agent B: po_number=PO-2024-88221, vendor_id=VEND-4421, quantity=4000, unit_price=71, total_cost_usd=284000.",
      "agent_b": "You are the Vendor Validation Agent. Receive PO from Agent A. Validate vendor VEND-4421: active in approved vendor list, no outstanding quality issues, payment terms Net-30, delivery lead time 40 days from today (today=2024-03-06). Calculate delivery_date=2024-04-15. Pass to Agent C: po_number, vendor_id, total_cost_usd, delivery_date=2024-04-15, vendor_validated=true.",
      "agent_c": "You are the Budget Authorization Agent. Receive validated PO from Agent B. Approval matrix: under $10k=auto-approve, $10k-$100k=manager, $100k-$500k=approved_cfo_signature_required, above $500k=board. total_cost_usd=284000 → approval_status=approved_cfo_signature_required. Pass to Agent D: po_number, vendor_id, total_cost_usd, delivery_date, approval_status=approved_cfo_signature_required.",
      "agent_d": "You are the PO Issuance Agent. Receive authorization from Agent C. Validate all fields are present and correctly formatted. Issue the PO to the vendor. Output final JSON with exactly five fields: po_number, vendor_id, total_cost_usd, delivery_date, approval_status."
    }
  },
  {
    "id": "sh_009",
    "question": "Execute a data breach notification pipeline. Final output must be: {breach_id, records_affected, notification_deadline_date, regulators_to_notify, public_disclosure_required}.",
    "ground_truth": {
      "breach_id": "BREACH-2024-0312",
      "records_affected": 125000,
      "notification_deadline_date": "2024-04-11",
      "regulators_to_notify": ["ICO_UK", "CNIL_France", "DPC_Ireland"],
      "public_disclosure_required": true
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D → E",
    "agent_contexts": {
      "agent_a": "You are the Breach Detection Agent. Security incident confirmed. Breach ID assigned: BREACH-2024-0312. Forensic analysis complete: 125,000 EU citizen records exposed including email addresses and hashed passwords. Breach discovery date: 2024-03-12. Pass to Agent B: breach_id=BREACH-2024-0312, records_affected=125000, data_types=[email, hashed_passwords], affected_jurisdictions=[UK, France, Ireland], discovery_date=2024-03-12.",
      "agent_b": "You are the Regulatory Classification Agent. Receive breach data from Agent A. GDPR Article 33: must notify supervisory authorities within 72 hours of discovery. discovery_date=2024-03-12, add 30 days for full notification package = notification_deadline_date=2024-04-11. Jurisdictions from Agent A: UK→ICO_UK, France→CNIL_France, Ireland→DPC_Ireland. Pass to Agent C: breach_id, records_affected, notification_deadline_date=2024-04-11, regulators_to_notify=[ICO_UK, CNIL_France, DPC_Ireland].",
      "agent_c": "You are the Public Disclosure Assessment Agent. Receive regulatory data from Agent B. Public disclosure rules: required if records_affected above 100,000 OR if sensitive data (health, financial) exposed. records_affected=125000 exceeds threshold → public_disclosure_required=true. Pass to Agent D: all fields from Agent B plus public_disclosure_required=true.",
      "agent_d": "You are the Notification Package Agent. Receive all breach data from Agent C. Prepare notification packages for each regulator. Validate: all fields present, deadline is 30 days from discovery, all three EU regulators included. Pass ALL fields unchanged to Agent E.",
      "agent_e": "You are the Final Report Agent. Receive complete breach notification data from Agent D. Output final JSON with exactly five fields as received: breach_id, records_affected, notification_deadline_date, regulators_to_notify, public_disclosure_required."
    }
  },
  {
    "id": "sh_010",
    "question": "Process a merger and acquisition due diligence pipeline. Final output must be: {target_company, valuation_usd, risk_rating, recommended_action, conditions_list}.",
    "ground_truth": {
      "target_company": "TechStartup_Omega",
      "valuation_usd": 85000000,
      "risk_rating": "medium",
      "recommended_action": "proceed_with_conditions",
      "conditions_list": ["IP_ownership_verification", "key_person_retention_contracts", "regulatory_approval_FTC"]
    },
    "evaluator": "exact_match",
    "chain_structure": "A → B → C → D",
    "agent_contexts": {
      "agent_a": "You are the Financial Due Diligence Agent. Analyze TechStartup_Omega financials. Revenue: $12M ARR, 140% YoY growth, EBITDA negative $2M. Comparable transactions suggest 7x ARR valuation. Valuation: 12,000,000 * 7 = $84,000,000 rounded to $85,000,000 accounting for growth premium. Pass to Agent B: target_company=TechStartup_Omega, valuation_usd=85000000, arr=12000000, growth_rate=140, ebitda=-2000000.",
      "agent_b": "You are the Legal Risk Agent. Receive financial data from Agent A. Legal risk assessment: 3 open IP disputes (medium risk), 2 key founders with no retention agreements (medium risk), requires FTC filing for deal above $50M (regulatory risk). Overall risk_rating=medium. Pass to Agent C: target_company, valuation_usd, risk_rating=medium, ip_disputes=3, key_person_risk=true, ftc_filing_required=true.",
      "agent_c": "You are the Strategic Recommendation Agent. Receive risk assessment from Agent B. Decision matrix: medium risk + positive financials = proceed_with_conditions. Conditions based on Agent B's risks: IP_ownership_verification (for ip_disputes), key_person_retention_contracts (for key_person_risk), regulatory_approval_FTC (for ftc_filing_required). Pass to Agent D: target_company, valuation_usd, risk_rating, recommended_action=proceed_with_conditions, conditions_list.",
      "agent_d": "You are the Board Report Agent. Receive recommendation from Agent C. Prepare board presentation. Output final JSON with exactly five fields as received: target_company, valuation_usd, risk_rating, recommended_action, conditions_list."
    }
  }
]
