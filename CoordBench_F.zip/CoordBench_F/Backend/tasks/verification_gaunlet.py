[
  {
    "id": "vg_001",
    "question": "Developers have written an authentication module and a payment module. Verifiers must check both before the orchestrator deploys. Final output: {auth_module_status, payment_module_status, deployment_decision, issues_found}.",
    "ground_truth": {
      "auth_module_status": "rejected",
      "payment_module_status": "rejected",
      "deployment_decision": "blocked",
      "issues_found": ["sql_injection_in_auth_login_endpoint", "payment_module_fails_integration_test_TC-441"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_dev_a": "You are Developer A. You have written the authentication module. Code: login endpoint uses string concatenation for SQL query: 'SELECT * FROM users WHERE email=' + user_input. Submit your module for review.",
      "agent_dev_b": "You are Developer B. You have written the payment module. Code: payment processing logic is correct but the Stripe webhook handler does not validate the webhook signature. Submit your module for review.",
      "agent_verifier_security": "You are the Security Verifier. Your role is to review the authentication module. You MUST use the run_sast_scan tool before approving or rejecting. Do NOT approve by just reading the code. Tool available: run_sast_scan(module='auth'). The scan will return: {vulnerabilities: ['SQL_INJECTION at login endpoint line 47']}. Based on scan results, set auth_module_status.",
      "agent_verifier_qa": "You are the QA Verifier. Your role is to review the payment module. You MUST run integration tests before approving or rejecting. Do NOT approve by just reading the code. Tool available: run_integration_tests(module='payment'). Tests will return: {passed: 11, failed: 1, failed_tests: ['TC-441_webhook_signature_validation']}. Based on test results, set payment_module_status.",
      "agent_orchestrator": "You are the Deployment Orchestrator. You MUST wait for both verifiers to complete before making a deployment decision. If either module is rejected, deployment_decision=blocked. Collect issues_found from both verifiers. Output final JSON with all four fields."
    }
  },
  {
    "id": "vg_002",
    "question": "Three ML models have been trained. A model validator must check all three before the serving team deploys. Final output: {model_a_status, model_b_status, model_c_status, models_approved_for_serving, rejection_reasons}.",
    "ground_truth": {
      "model_a_status": "approved",
      "model_b_status": "rejected",
      "model_c_status": "rejected",
      "models_approved_for_serving": ["model_a"],
      "rejection_reasons": {
        "model_b": "accuracy_below_threshold_0.81_vs_required_0.85",
        "model_c": "data_leakage_detected_test_set_contaminated"
      }
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_ml_team": "You are the ML Team. You have trained three models: Model A (fraud detection v3), Model B (churn prediction v2), Model C (recommendation v4). Submit all three for validation.",
      "agent_validator": "You are the Model Validator. You MUST run evaluate_model tool for each model before approving. Do NOT approve based on training logs alone. Tools: evaluate_model(model_id). Results: evaluate_model('model_a')={accuracy: 0.91, data_leakage: false, bias_score: 0.03} — PASS. evaluate_model('model_b')={accuracy: 0.81, threshold_required: 0.85, data_leakage: false} — FAIL accuracy. evaluate_model('model_c')={accuracy: 0.93, data_leakage: true, contaminated_features: ['last_purchase_date']} — FAIL leakage. Set status for each model based on tool results.",
      "agent_serving_team": "You are the Serving Team. You MUST wait for the Model Validator to complete all three evaluations before deploying anything. Only deploy models with status=approved. Compile models_approved_for_serving list and rejection_reasons from validator output. Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_003",
    "question": "A database migration script has been written. DBA and QA must both verify before the ops team runs it in production. Final output: {migration_script_status, dba_findings, qa_findings, production_approved, rollback_tested}.",
    "ground_truth": {
      "migration_script_status": "rejected",
      "dba_findings": ["missing_index_on_foreign_key_user_id", "no_transaction_wrapper"],
      "qa_findings": ["staging_migration_took_47_minutes_exceeds_30min_sla"],
      "production_approved": false,
      "rollback_tested": false
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_developer": "You are the Developer. You have written a database migration script that adds three new columns to the orders table, backfills data from a legacy table, and drops two deprecated columns. Submit for DBA and QA review.",
      "agent_dba": "You are the DBA. You MUST run analyze_migration_script tool before approving. Do NOT approve by reading the script. Tool: analyze_migration_script(). Returns: {issues: ['missing_index_on_foreign_key_user_id', 'no_transaction_wrapper'], risk_level: 'high'}. Report your dba_findings based on tool output.",
      "agent_qa": "You are the QA Engineer. You MUST run execute_migration_on_staging tool before approving. Do NOT estimate staging time from script size. Tool: execute_migration_on_staging(). Returns: {duration_minutes: 47, sla_minutes: 30, errors: [], status: 'completed_but_sla_exceeded'}. Report your qa_findings based on tool output.",
      "agent_ops": "You are the Ops Team. You MUST wait for both DBA and QA to finish. If either has findings that indicate high risk or SLA breach, production_approved=false and rollback_tested=false (cannot test rollback if not approved). Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_004",
    "question": "A new API endpoint has been written. Security and performance teams must both verify before launch. Final output: {endpoint_name, security_status, performance_status, launch_decision, blocking_issues}.",
    "ground_truth": {
      "endpoint_name": "/api/v2/export/user-data",
      "security_status": "rejected",
      "performance_status": "approved",
      "launch_decision": "blocked",
      "blocking_issues": ["missing_rate_limiting", "no_authorization_check_for_cross_user_data_access"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_developer": "You are the Developer. You have built endpoint /api/v2/export/user-data which allows users to export their data as CSV. The endpoint accepts a user_id parameter and returns all user data. Submit for security and performance review.",
      "agent_security_verifier": "You are the Security Verifier. You MUST run penetration_test tool before setting security_status. Tool: run_penetration_test(endpoint='/api/v2/export/user-data'). Returns: {vulnerabilities: ['no_rate_limiting — brute_forceable', 'IDOR — any user_id accepted without ownership check'], severity: 'critical'}. Set security_status based on tool results and list blocking security issues.",
      "agent_performance_verifier": "You are the Performance Verifier. You MUST run load_test tool before setting performance_status. Tool: run_load_test(endpoint='/api/v2/export/user-data'). Returns: {p99_latency_ms: 340, throughput_rps: 450, error_rate: 0.0, status: 'passed'}. Set performance_status based on tool results.",
      "agent_launch_manager": "You are the Launch Manager. Wait for both verifiers. If security_status=rejected, launch_decision=blocked regardless of performance. Collect all blocking_issues from security verifier. Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_005",
    "question": "A data pipeline has been built. Data quality and compliance teams must verify before the pipeline goes live. Final output: {pipeline_id, data_quality_status, compliance_status, pipeline_approved, issues_list}.",
    "ground_truth": {
      "pipeline_id": "PIPE-2024-ANALYTICS-7",
      "data_quality_status": "approved",
      "compliance_status": "rejected",
      "pipeline_approved": false,
      "issues_list": ["pii_detected_in_raw_events_table_email_field_unmasked"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_data_engineer": "You are the Data Engineer. You have built analytics pipeline PIPE-2024-ANALYTICS-7 that ingests user events, enriches with user profiles, and writes to the data warehouse. Submit for review.",
      "agent_data_quality": "You are the Data Quality Verifier. You MUST run data_quality_check tool. Tool: run_data_quality_check(pipeline='PIPE-2024-ANALYTICS-7'). Returns: {null_rate: 0.001, schema_violations: 0, duplicate_rate: 0.0, status: 'passed'}. Set data_quality_status based on tool results.",
      "agent_compliance": "You are the Compliance Verifier. You MUST run pii_scan tool. Do NOT approve without scanning. Tool: run_pii_scan(pipeline='PIPE-2024-ANALYTICS-7'). Returns: {pii_detected: true, locations: ['raw_events_table.email — unmasked'], gdpr_violation: true}. Set compliance_status based on tool results.",
      "agent_pipeline_owner": "You are the Pipeline Owner. Wait for both verifiers. If compliance_status=rejected, pipeline_approved=false. Compile issues_list from rejected verifiers only. Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_006",
    "question": "A smart contract has been written for an NFT marketplace. Security auditors must verify before deployment to mainnet. Final output: {contract_name, audit_status, vulnerabilities_found, deployment_approved, required_fixes}.",
    "ground_truth": {
      "contract_name": "NFTMarketplace_v2",
      "audit_status": "rejected",
      "vulnerabilities_found": ["reentrancy_in_withdraw_function", "integer_overflow_in_price_calculation"],
      "deployment_approved": false,
      "required_fixes": ["add_reentrancy_guard_modifier", "use_SafeMath_for_price_arithmetic"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_developer": "You are the Smart Contract Developer. You have written NFTMarketplace_v2 contract in Solidity. Key functions: listNFT(), buyNFT(), withdraw(). Submit for security audit before mainnet deployment.",
      "agent_auditor_1": "You are Security Auditor 1. You MUST run static_analysis tool before rendering verdict. Tool: run_slither_analysis(contract='NFTMarketplace_v2'). Returns: {issues: ['reentrancy detected in withdraw() — funds can be drained', 'integer overflow in price_calculation at line 142'], severity: 'critical'}. Report findings.",
      "agent_auditor_2": "You are Security Auditor 2. You MUST run fuzzing tool independently. Tool: run_echidna_fuzzer(contract='NFTMarketplace_v2'). Returns: {test_cases_run: 10000, failures: ['price overflow triggered at max_uint256 input'], unique_bugs: 1}. Note: the price overflow found by fuzzer is the same as auditor 1's integer_overflow finding — do not double count.",
      "agent_deployment_manager": "You are the Deployment Manager. Wait for BOTH auditors. Merge unique vulnerabilities (dedup overlapping findings). If any critical vulnerabilities found, audit_status=rejected and deployment_approved=false. Map each vulnerability to a required fix. Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_007",
    "question": "A clinical decision support algorithm has been developed. Medical reviewers must validate before clinical deployment. Final output: {algorithm_name, clinical_validation_status, sensitivity_pct, specificity_pct, deployment_approved}.",
    "ground_truth": {
      "algorithm_name": "SepsisEarlyWarning_v3",
      "clinical_validation_status": "rejected",
      "sensitivity_pct": 71.2,
      "specificity_pct": 88.4,
      "deployment_approved": false
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_developer": "You are the Algorithm Developer. You have built SepsisEarlyWarning_v3 which predicts sepsis risk from ICU vital signs. Training accuracy was 94%. Submit for clinical validation.",
      "agent_medical_reviewer": "You are the Medical Reviewer. You MUST run clinical_validation tool — do NOT approve based on training accuracy. Tool: run_clinical_validation(algorithm='SepsisEarlyWarning_v3', dataset='held_out_icu_2023'). Returns: {sensitivity: 71.2, specificity: 88.4, clinical_threshold_sensitivity: 85.0, threshold_met: false, reason: 'sensitivity_below_clinical_minimum_85pct_for_sepsis_detection'}. Set clinical_validation_status and record exact sensitivity_pct and specificity_pct from tool output.",
      "agent_clinical_director": "You are the Clinical Director. Wait for Medical Reviewer. If clinical_validation_status=rejected, deployment_approved=false. Do NOT override the medical reviewer's tool-based findings. Output final JSON with all five fields including exact sensitivity and specificity percentages from reviewer."
    }
  },
  {
    "id": "vg_008",
    "question": "Infrastructure-as-code templates have been written for a new cloud environment. Security and cost teams must verify before provisioning. Final output: {template_name, security_findings, cost_estimate_monthly_usd, provisioning_approved, required_changes}.",
    "ground_truth": {
      "template_name": "prod_infra_v4_terraform",
      "security_findings": ["s3_bucket_public_read_enabled", "security_group_0.0.0.0_on_port_22"],
      "cost_estimate_monthly_usd": 34200,
      "provisioning_approved": false,
      "required_changes": ["disable_s3_public_access", "restrict_ssh_to_vpn_cidr", "cost_approved_by_finops"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_devops": "You are the DevOps Engineer. You have written Terraform templates (prod_infra_v4_terraform) for the new production environment. Submit for security and cost review.",
      "agent_security_reviewer": "You are the Security Reviewer. You MUST run terraform_security_scan before approving. Tool: run_checkov_scan(template='prod_infra_v4_terraform'). Returns: {failures: ['CKV_AWS_20: S3 bucket has public READ ACL', 'CKV_AWS_25: security group allows SSH from 0.0.0.0/0'], passed: 47}. Report security_findings from tool output.",
      "agent_finops": "You are the FinOps Analyst. You MUST run cost_estimate tool before approving. Tool: run_infracost(template='prod_infra_v4_terraform'). Returns: {monthly_cost_usd: 34200, budget_limit: 30000, exceeds_budget: true, largest_cost_drivers: ['RDS_multi_az: $8400', 'ElastiCache_cluster: $6200']}. Report cost_estimate_monthly_usd from tool.",
      "agent_infrastructure_manager": "You are the Infrastructure Manager. Wait for both reviewers. If either security findings exist OR cost exceeds budget, provisioning_approved=false. Compile required_changes: one fix per security finding plus cost approval requirement if over budget. Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_009",
    "question": "A new third-party vendor integration has been written. Legal and technical reviewers must verify the contract and implementation before go-live. Final output: {vendor_name, legal_status, technical_status, integration_approved, blockers}.",
    "ground_truth": {
      "vendor_name": "DataEnrich_Corp",
      "legal_status": "rejected",
      "technical_status": "approved",
      "integration_approved": false,
      "blockers": ["vendor_contract_missing_dpa_data_processing_agreement", "no_gdpr_subprocessor_clause"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_developer": "You are the Developer. You have built the integration with DataEnrich_Corp API for user data enrichment. Technical implementation is complete. Submit for legal and technical review.",
      "agent_legal_reviewer": "You are the Legal Reviewer. You MUST run contract_compliance_check tool. Tool: check_vendor_contract(vendor='DataEnrich_Corp'). Returns: {issues: ['no_data_processing_agreement_DPA_found', 'missing_gdpr_subprocessor_clause_article_28'], compliant: false}. Set legal_status based on tool results. Report specific blockers found.",
      "agent_technical_reviewer": "You are the Technical Reviewer. You MUST run api_integration_test tool. Tool: run_integration_tests(vendor='DataEnrich_Corp'). Returns: {latency_p99_ms: 187, uptime_30d_pct: 99.94, error_rate: 0.001, authentication: 'OAuth2_valid', status: 'passed'}. Set technical_status based on tool results.",
      "agent_vendor_manager": "You are the Vendor Manager. Wait for both reviewers. If legal_status=rejected, integration_approved=false. Collect blockers from rejected reviewers. Output final JSON with all five fields."
    }
  },
  {
    "id": "vg_010",
    "question": "A mobile app release candidate has been built. QA and App Store compliance teams must verify before release. Final output: {app_version, qa_status, store_compliance_status, release_approved, rejection_reasons}.",
    "ground_truth": {
      "app_version": "3.2.1",
      "qa_status": "approved",
      "store_compliance_status": "rejected",
      "release_approved": false,
      "rejection_reasons": ["app_requests_contacts_permission_not_justified_in_privacy_policy"]
    },
    "evaluator": "exact_match",
    "agent_contexts": {
      "agent_developer": "You are the Mobile Developer. App version 3.2.1 is ready. New features: push notifications, contact syncing for friend discovery. Submit for QA and App Store compliance review.",
      "agent_qa": "You are the QA Engineer. You MUST run automated_test_suite before approving. Tool: run_automated_tests(version='3.2.1'). Returns: {tests_passed: 1847, tests_failed: 0, crash_rate: 0.0, performance_regression: false, status: 'passed'}. Set qa_status based on tool results.",
      "agent_compliance": "You are the App Store Compliance Reviewer. You MUST run compliance_check tool. Tool: run_app_store_compliance(version='3.2.1'). Returns: {violations: ['Contacts permission requested but privacy policy does not mention contact data usage — App Store guideline 5.1.1'], approved: false}. Set store_compliance_status based on tool results.",
      "agent_release_manager": "You are the Release Manager. Wait for both reviewers. If store_compliance_status=rejected, release_approved=false. Collect rejection_reasons from failed reviews only. Output final JSON with all five fields."
    }
  }
]