"""
Generate docs/validation_report.md from validation/results.json.

Reads the live Cohen's κ results (Stage 2) and the IAA summary from
gold_labels.json (Stage 1) to produce a fully auto-generated markdown report.

Usage:
    python -m validation.generate_report
    python -m validation.generate_report --results validation/results.json
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import typer
from rich.console import Console

BASE_DIR = Path(__file__).parent.parent
app = typer.Typer(help="Generate validation_report.md from results.json.")
console = Console()

# ── Category and display metadata ────────────────────────────────────────────

CATEGORY_MAP: Dict[str, int] = {
    "task_disobedience":         1,
    "role_drift":                1,
    "loop":                      1,
    "context_degradation":       1,
    "termination_blindness":     1,
    "stagnation":                1,
    "info_siloing":              2,
    "echo_chamber":              2,
    "agent_dominance":           2,
    "reasoning_action_mismatch": 2,
    "unresolved_conflict":       2,
    "handoff_corruption":        2,
    "premature_termination":     3,
    "superficial_verification":  3,
    "incorrect_verification":    3,
    "hallucinated_verification": 3,
    "coordination_overhead":     3,
}

CATEGORY_NAMES: Dict[int, str] = {
    1: "Specification Issues",
    2: "Inter-Agent Misalignment",
    3: "Task Verification",
}

READABLE: Dict[str, str] = {
    "task_disobedience":         "Task Disobedience",
    "role_drift":                "Role Drift",
    "loop":                      "Step Repetition / Looping",
    "context_degradation":       "Context Degradation",
    "termination_blindness":     "Termination Blindness",
    "stagnation":                "Stagnation",
    "info_siloing":              "Information Siloing",
    "echo_chamber":              "Echo Chamber Convergence",
    "agent_dominance":           "Agent Dominance",
    "reasoning_action_mismatch": "Reasoning-Action Mismatch",
    "unresolved_conflict":       "Unresolved Conflict",
    "handoff_corruption":        "Handoff Corruption",
    "premature_termination":     "Premature Termination",
    "superficial_verification":  "Superficial Verification",
    "incorrect_verification":    "Incorrect Verification",
    "hallucinated_verification": "Hallucinated Verification",
    "coordination_overhead":     "Coordination Overhead",
}

TYPE_LABELS: Dict[str, str] = {
    "programmatic": "Programmatic",
    "rule_based":   "Rule-Based",
    "hybrid":       "Hybrid (Rule + LLM)",
    "llm_judge":    "LLM Judge",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _fmt(value: Any, decimals: int = 2) -> str:
    if value is None:
        return "N/A"
    try:
        v = float(value)
        return "N/A" if math.isnan(v) else f"{v:.{decimals}f}"
    except (TypeError, ValueError):
        return "N/A"


def _status_cell(r: Dict, threshold: float) -> str:
    kappa = r.get("cohen_kappa")
    if kappa is None:
        return "—"
    try:
        v = float(kappa)
        if math.isnan(v):
            return "—"
        return "PASS ✓" if v >= threshold else "FAIL ✗"
    except (TypeError, ValueError):
        return "—"


def _notes(r: Dict, threshold: float) -> str:
    parts: List[str] = []
    dtype = r.get("type", "")

    if dtype == "programmatic":
        parts.append("Deterministic; no LLM calls.")
    elif dtype == "hybrid":
        parts.append("Rule detector + LLM judge combined.")

    if r.get("iaa_reliable") is False:
        parts.append("⚠ Human labels have low IAA — treat result with caution.")

    kappa = r.get("cohen_kappa")
    if kappa is not None:
        try:
            v = float(kappa)
            if not math.isnan(v):
                if v < threshold and v >= threshold - 0.05:
                    parts.append("Near-threshold — minor prompt tuning may suffice.")
                elif v < threshold - 0.05:
                    parts.append("Sub-threshold — needs prompt/logic refinement.")
        except (TypeError, ValueError):
            pass

    return " ".join(parts)


def _date_prefix(iso: str) -> str:
    return iso[:10] if len(iso) >= 10 else iso


# ── Report generation ─────────────────────────────────────────────────────────

def generate(
    results_path: Path,
    out_path: Path,
    iaa_path: Optional[Path] = None,
) -> None:
    with open(results_path, encoding="utf-8") as f:
        results_data = json.load(f)

    detectors: Dict[str, Dict] = results_data.get("detectors", {})
    threshold: float = results_data.get("threshold_kappa", 0.65)
    n_transcripts = results_data.get("n_transcripts", "?")
    generated_at = results_data.get("generated_at", "?")

    # Optional IAA data (Stage 1)
    iaa_summary: Dict[str, Dict] = {}
    n_raters: Any = "?"
    iaa_generated = "?"
    if iaa_path and iaa_path.exists():
        with open(iaa_path, encoding="utf-8") as f:
            iaa_raw = json.load(f)
        iaa_summary = iaa_raw.get("iaa_summary", {})
        n_raters = iaa_raw.get("n_raters", "?")
        iaa_generated = iaa_raw.get("generated_at", "?")

    pass_count = sum(1 for r in detectors.values() if r.get("passes_threshold"))
    total = len(detectors)

    lines: List[str] = [
        "# MAST Detector Validation Report",
        "",
        f"> Auto-generated {_date_prefix(generated_at)}  "
        f"·  {n_transcripts} transcripts  ·  {n_raters} human raters",
        "",
        "## Methodology",
        "",
        f"- **{n_transcripts} hold-out transcripts** annotated by **{n_raters} independent raters**.",
        "  Disagreements resolved by majority vote.",
        "- The automated detector swarm processed the same transcripts.",
        f"- **Pass threshold**: Cohen's κ ≥ {threshold} per failure mode.",
        "- **Inter-annotator reliability** measured with Fleiss' κ and Krippendorff's α (Stage 1).",
        "  Failure modes with Fleiss κ < 0.60 are flagged as unreliable ground truth.",
        "",
    ]

    # ── Stage 1: Human label reliability ──────────────────────────────────
    if iaa_summary:
        iaa_reliable_count = sum(1 for v in iaa_summary.values() if v.get("reliable"))
        lines += [
            "## Stage 1 — Human Label Reliability (IAA)",
            "",
            "Measures whether the human raters agree with *each other* before comparing",
            "any detector against their labels.  A failure mode with low Fleiss κ has",
            "unreliable ground truth and its Stage 2 results should be interpreted with caution.",
            "",
            f"_(Computed {_date_prefix(iaa_generated)})_",
            "",
            f"**{iaa_reliable_count}/{len(iaa_summary)} failure modes** "
            f"have reliable human labels (Fleiss κ ≥ 0.60).",
            "",
            "| Failure Mode | Fleiss κ | Krippendorff α | Reliable? | Prevalence |",
            "|---|---:|---:|:---:|---:|",
        ]
        for mode in READABLE:
            if mode not in iaa_summary:
                continue
            iaa = iaa_summary[mode]
            fk = _fmt(iaa.get("fleiss_kappa"))
            ka = _fmt(iaa.get("krippendorff_alpha"))
            rel = "✓" if iaa.get("reliable") else "✗"
            prev = f"{iaa.get('prevalence', 0):.1%}"
            lines.append(f"| {READABLE[mode]} | {fk} | {ka} | {rel} | {prev} |")
        lines.append("")

    # ── Stage 2: Detector validation ──────────────────────────────────────
    lines += [
        "## Stage 2 — Detector vs. Human Agreement",
        "",
        f"**Summary**: {pass_count}/{total} detectors pass Cohen's κ ≥ {threshold}.",
        "",
    ]

    for cat_id in sorted(CATEGORY_NAMES):
        cat_modes = [
            m for m in CATEGORY_MAP
            if CATEGORY_MAP[m] == cat_id and m in detectors
        ]
        if not cat_modes:
            continue

        lines += [
            f"### Category {cat_id}: {CATEGORY_NAMES[cat_id]}",
            "",
            "| Failure Mode | Detector Type | N | Cohen κ | F1 | Precision | Recall | Status | Notes |",
            "|---|---|---:|---:|---:|---:|---:|:---:|---|",
        ]
        for mode in cat_modes:
            r = detectors[mode]
            name   = READABLE.get(mode, mode)
            dtype  = TYPE_LABELS.get(r.get("type", ""), r.get("type", ""))
            n      = r.get("n_evaluated", "?")
            kappa  = _fmt(r.get("cohen_kappa"))
            f1     = _fmt(r.get("f1"))
            prec   = _fmt(r.get("precision"))
            rec    = _fmt(r.get("recall"))
            status = _status_cell(r, threshold)
            notes  = _notes(r, threshold)
            lines.append(
                f"| {name} | {dtype} | {n} | {kappa} | {f1} | {prec} | {rec} | {status} | {notes} |"
            )
        lines.append("")

    # ── Confusion matrix summary (TP/FP/TN/FN) ────────────────────────────
    lines += [
        "## Confusion Matrix Summary",
        "",
        "| Failure Mode | TP | FP | TN | FN | Precision | Recall |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for mode, r in detectors.items():
        lines.append(
            f"| {READABLE.get(mode, mode)} "
            f"| {r.get('tp', '?')} | {r.get('fp', '?')} "
            f"| {r.get('tn', '?')} | {r.get('fn', '?')} "
            f"| {_fmt(r.get('precision'))} | {_fmt(r.get('recall'))} |"
        )
    lines.append("")

    # ── Next steps ────────────────────────────────────────────────────────
    failing = [
        READABLE.get(m, m)
        for m, r in detectors.items()
        if not r.get("passes_threshold")
        and not (
            isinstance(r.get("cohen_kappa"), float)
            and math.isnan(r.get("cohen_kappa"))  # type: ignore[arg-type]
        )
    ]

    lines += ["## Next Steps", ""]
    if failing:
        lines.append(
            f"{len(failing)} detector(s) are sub-threshold and need attention:"
        )
        for mode, r in detectors.items():
            if not r.get("passes_threshold") and not math.isnan(float(r.get("cohen_kappa") or float("nan"))):
                name = READABLE.get(mode, mode)
                dtype = r.get("type", "")
                if dtype == "llm_judge":
                    fix = "Revise prompt — require the judge to explicitly quote the stated intention and the actual action before rendering a verdict."
                elif dtype == "programmatic":
                    fix = "Review heuristic thresholds and edge-case handling."
                elif dtype == "rule_based":
                    fix = "Review rule thresholds; consider adding an LLM judge cross-check."
                else:
                    fix = "Review detector logic and thresholds."
                lines.append(f"- **{name}** ({TYPE_LABELS.get(dtype, dtype)}): {fix}")
    else:
        lines.append(
            f"All {total} validated detectors pass the κ ≥ {threshold} threshold. "
            "Re-evaluate on a fresh batch of 50 transcripts before the next paper submission."
        )
    lines.append("")

    # ── Write ─────────────────────────────────────────────────────────────
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    console.print(f"[green]Report written → {out_path}[/green]")


@app.command()
def report(
    results: Path = typer.Option(
        BASE_DIR / "validation" / "results.json",
        help="Path to results.json from validate_detectors.py",
    ),
    iaa: Optional[Path] = typer.Option(
        None,
        help="Path to gold_labels.json for IAA section (default: labels/gold_labels.json)",
    ),
    out: Path = typer.Option(
        BASE_DIR / "docs" / "validation_report.md",
        help="Output path for the markdown report",
    ),
) -> None:
    """Generate docs/validation_report.md from results.json."""
    if not results.exists():
        console.print(f"[red]results.json not found: {results}[/red]")
        console.print("[yellow]Run first: python -m validation.validate_detectors[/yellow]")
        raise typer.Exit(1)

    iaa_path = iaa or (BASE_DIR / "labels" / "gold_labels.json")
    generate(results, out, iaa_path if iaa_path.exists() else None)


if __name__ == "__main__":
    app()
