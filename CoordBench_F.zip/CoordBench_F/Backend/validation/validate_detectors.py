"""
Run every detector against transcripts in gold_labels.json and compute validation metrics.

Stage 2 of the validation pipeline: measures Cohen's κ, Precision, Recall, F1 for
each detector vs the human gold standard produced by labels/compute_iaa.py.

Usage:
    python -m validation.validate_detectors
    python -m validation.validate_detectors --skip-llm          # only programmatic + rule-based
    python -m validation.validate_detectors --modes loop,echo_chamber
"""
from __future__ import annotations

import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import typer
from rich.console import Console
from rich.table import Table
from sklearn.metrics import cohen_kappa_score, precision_recall_fscore_support

# Make project root importable when running as __main__
sys.path.insert(0, str(Path(__file__).parent.parent))

from Backend.harness.detectors.programmatic.loop_detector import run as _loop
from Backend.harness.detectors.programmatic.termination_detector import run as _termination
from Backend.harness.detectors.programmatic.context_degradation import run as _context_deg
from Backend.harness.detectors.programmatic.task_disobedience import run as _task_disob
from Backend.harness.detectors.programmatic.coordination_overhead import run as _coord_overhead
from Backend.harness.detectors.rule_detectors.dominance import run as _dominance_rule
from Backend.harness.detectors.rule_detectors.stagnation import run as _stagnation
from Backend.harness.detectors.rule_detectors.handoff_corruption import run as _handoff
from Backend.harness.detectors.llm_judge.echo_chamber import run as _echo_chamber
from Backend.harness.detectors.llm_judge.agent_dominance import run as _dom_llm
from Backend.harness.detectors.llm_judge.role_drift import run as _role_drift
from Backend.harness.detectors.llm_judge.info_siloing import run as _info_silo
from Backend.harness.detectors.llm_judge.reasoning_action_mismatch import run as _ram
from Backend.harness.detectors.llm_judge.unresolved_conflict import run as _conflict
from Backend.harness.detectors.llm_judge.superficial_verification import run as _superficial
from Backend.harness.detectors.llm_judge.incorrect_verification import run as _incorrect

BASE_DIR = Path(__file__).parent.parent
app = typer.Typer(help="Validate MAST detectors against human gold labels.")
console = Console()

KAPPA_THRESHOLD = 0.65


def _det(result: Any) -> bool:
    if isinstance(result, dict):
        return bool(result.get("detected", False))
    return bool(result)


# ---------------------------------------------------------------------------
# Detector registry
# Each entry: failure_mode → (detector_type, callable(path) → bool)
# ---------------------------------------------------------------------------

DETECTOR_MAP: Dict[str, Tuple[str, Callable[[str], bool]]] = {
    # ── Programmatic ─────────────────────────────────────────────────────
    "loop": (
        "programmatic",
        lambda p: _det(_loop(p)),
    ),
    "context_degradation": (
        "programmatic",
        lambda p: _det(_context_deg(p)),
    ),
    "task_disobedience": (
        "programmatic",
        lambda p: _det(_task_disob(p)),
    ),
    "coordination_overhead": (
        "programmatic",
        lambda p: _det(_coord_overhead(p)),
    ),
    "premature_termination": (
        "programmatic",
        lambda p: bool((_termination(p) or {}).get("premature_termination", False)),
    ),
    "termination_blindness": (
        "programmatic",
        lambda p: bool((_termination(p) or {}).get("termination_blindness", False)),
    ),
    # ── Rule-based ────────────────────────────────────────────────────────
    "stagnation": (
        "rule_based",
        lambda p: _det(_stagnation(p)),
    ),
    "handoff_corruption": (
        "rule_based",
        lambda p: _det(_handoff(p)),
    ),
    # ── Hybrid: rule detector OR LLM judge ───────────────────────────────
    "agent_dominance": (
        "hybrid",
        lambda p: _det(_dominance_rule(p)) or _det(_dom_llm(p)),
    ),
    # ── LLM Judge ────────────────────────────────────────────────────────
    "echo_chamber": (
        "llm_judge",
        lambda p: _det(_echo_chamber(p)),
    ),
    "role_drift": (
        "llm_judge",
        lambda p: _det(_role_drift(p)),
    ),
    "info_siloing": (
        "llm_judge",
        lambda p: _det(_info_silo(p)),
    ),
    "reasoning_action_mismatch": (
        "llm_judge",
        lambda p: _det(_ram(p)),
    ),
    "unresolved_conflict": (
        "llm_judge",
        lambda p: _det(_conflict(p)),
    ),
    "superficial_verification": (
        "llm_judge",
        lambda p: _det(_superficial(p)),
    ),
    "incorrect_verification": (
        "llm_judge",
        lambda p: _det(_incorrect(p)),
    ),
    # Hallucinated verification = superficial_verification detector
    # (both detect approval claims that have no backing tool_call)
    "hallucinated_verification": (
        "llm_judge",
        lambda p: _det(_superficial(p)),
    ),
}

LLM_MODES = {k for k, (t, _) in DETECTOR_MAP.items() if t == "llm_judge"}


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def _compute_metrics(y_true: List[bool], y_pred: List[bool]) -> Dict[str, Any]:
    n = len(y_true)
    tp = sum(1 for a, b in zip(y_true, y_pred) if a and b)
    tn = sum(1 for a, b in zip(y_true, y_pred) if not a and not b)
    fp = sum(1 for a, b in zip(y_true, y_pred) if not a and b)
    fn = sum(1 for a, b in zip(y_true, y_pred) if a and not b)

    base = {"tp": tp, "tn": tn, "fp": fp, "fn": fn, "n": n}

    # Degenerate: one class only — sklearn cohen_kappa_score raises
    if len(set(y_true)) < 2 or len(set(y_pred)) < 2:
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1   = (2 * prec * rec / (prec + rec)) if (prec + rec) > 0 else 0.0
        return {**base, "precision": round(prec, 4), "recall": round(rec, 4),
                "f1": round(f1, 4), "cohen_kappa": float("nan"),
                "note": "degenerate — only one class present"}

    prec, rec, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="binary", zero_division=0
    )
    kappa = cohen_kappa_score(y_true, y_pred)
    return {**base,
            "precision": round(float(prec), 4),
            "recall":    round(float(rec),  4),
            "f1":        round(float(f1),   4),
            "cohen_kappa": round(float(kappa), 4)}


# ---------------------------------------------------------------------------
# Main command
# ---------------------------------------------------------------------------

@app.command()
def validate(
    gold_labels_path: Path = typer.Option(
        BASE_DIR / "labels" / "gold_labels.json",
        help="Path to gold_labels.json from compute_iaa.py",
    ),
    transcripts_dir: Path = typer.Option(
        BASE_DIR / "transcripts" / "raw",
        help="Directory containing .jsonl transcript files",
    ),
    out: Path = typer.Option(
        BASE_DIR / "validation" / "results.json",
        help="Output path for validation results",
    ),
    skip_llm: bool = typer.Option(
        False, "--skip-llm", help="Skip LLM-judge detectors (faster, no API calls)"
    ),
    modes: Optional[str] = typer.Option(
        None,
        help="Comma-separated subset of failure modes to validate (default: all)",
    ),
    threshold: float = typer.Option(KAPPA_THRESHOLD, help="Cohen's κ pass threshold"),
) -> None:
    """Run all detectors against gold labels and compute Cohen's κ, P, R, F1."""
    if not gold_labels_path.exists():
        console.print(f"[red]gold_labels.json not found: {gold_labels_path}[/red]")
        console.print("[yellow]Run first: python -m labels.compute_iaa[/yellow]")
        raise typer.Exit(1)

    with open(gold_labels_path, encoding="utf-8") as f:
        gold_data = json.load(f)

    gold_labels: Dict[str, Dict] = gold_data.get("labels", {})
    iaa_summary: Dict[str, Dict] = gold_data.get("iaa_summary", {})

    # Determine which modes to validate
    active_modes = list(DETECTOR_MAP.keys())
    if modes:
        active_modes = [m.strip() for m in modes.split(",") if m.strip() in DETECTOR_MAP]
    if skip_llm:
        active_modes = [m for m in active_modes if m not in LLM_MODES]

    # Build transcript path index
    tpath_index: Dict[str, Path] = {
        f.stem: f
        for f in transcripts_dir.glob("*.jsonl")
        if f.name != "default.jsonl"
    }

    eval_tids = [tid for tid in gold_labels if tid in tpath_index]
    if not eval_tids:
        console.print(
            "[red]No overlap between gold_labels and available transcripts.[/red]\n"
            f"[dim]gold_labels has {len(gold_labels)} entries; "
            f"transcripts_dir has {len(tpath_index)} files.[/dim]"
        )
        raise typer.Exit(1)

    console.print(
        f"\n[bold]Validating {len(active_modes)} detectors "
        f"on {len(eval_tids)} transcripts...[/bold]"
        + (" [dim](LLM judge detectors skipped)[/dim]" if skip_llm else "")
        + "\n"
    )

    results: Dict[str, Any] = {}

    for mode in active_modes:
        d_type, detector_fn = DETECTOR_MAP[mode]
        iaa = iaa_summary.get(mode, {})

        y_true: List[bool] = []
        y_pred: List[bool] = []
        errors: List[str] = []

        with console.status(f"[cyan]{mode}[/cyan]  ({d_type})"):
            for tid in eval_tids:
                gold_val = gold_labels[tid].get(mode)
                if gold_val is None:
                    continue  # annotator skipped this mode for this transcript

                try:
                    pred = detector_fn(str(tpath_index[tid]))
                except Exception as exc:
                    errors.append(f"{tid}: {exc}")
                    pred = False

                y_true.append(bool(gold_val))
                y_pred.append(bool(pred))

        if not y_true:
            console.print(f"  [yellow]{mode}[/yellow]: no valid labels, skipping")
            continue

        metrics = _compute_metrics(y_true, y_pred)
        kappa = metrics["cohen_kappa"]
        kappa_ok = not (isinstance(kappa, float) and math.isnan(kappa))
        passes = kappa_ok and kappa >= threshold

        results[mode] = {
            "type": d_type,
            "failure_mode": mode,
            "n_evaluated": len(y_true),
            "iaa_fleiss_kappa": iaa.get("fleiss_kappa"),
            "iaa_reliable": iaa.get("reliable", True),
            **metrics,
            "passes_threshold": passes,
            "errors": errors[:5],
        }

    # ── Summary table ─────────────────────────────────────────────────────
    tbl = Table(title=f"Detector Validation  (threshold κ ≥ {threshold})", show_header=True)
    tbl.add_column("Failure Mode", style="cyan", min_width=28)
    tbl.add_column("Type", style="dim", min_width=14)
    tbl.add_column("N", justify="right", min_width=5)
    tbl.add_column("Cohen κ", justify="right", min_width=9)
    tbl.add_column("F1", justify="right", min_width=6)
    tbl.add_column("Prec", justify="right", min_width=6)
    tbl.add_column("Recall", justify="right", min_width=7)
    tbl.add_column("Status", justify="center", min_width=8)

    pass_count = 0
    for mode, r in results.items():
        kappa = r["cohen_kappa"]
        kappa_str = f"{kappa:.3f}" if not (isinstance(kappa, float) and math.isnan(kappa)) else "N/A"
        status = "[green]PASS[/green]" if r["passes_threshold"] else "[red]FAIL[/red]"
        if r["passes_threshold"]:
            pass_count += 1
        tbl.add_row(
            mode, r["type"], str(r["n_evaluated"]),
            kappa_str, f"{r['f1']:.3f}",
            f"{r['precision']:.3f}", f"{r['recall']:.3f}", status,
        )

    console.print(tbl)
    console.print(f"\n[bold]{pass_count}/{len(results)} detectors pass κ ≥ {threshold}[/bold]\n")

    # ── Write results.json ─────────────────────────────────────────────────
    out.parent.mkdir(parents=True, exist_ok=True)
    output = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "n_transcripts": len(eval_tids),
        "threshold_kappa": threshold,
        "skip_llm": skip_llm,
        "detectors": results,
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, default=str)

    console.print(f"[green]Results saved → {out}[/green]")


if __name__ == "__main__":
    app()
