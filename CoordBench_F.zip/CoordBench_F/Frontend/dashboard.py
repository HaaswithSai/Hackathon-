"""
CoordBench Dashboard
====================
Streamlit UI for running and viewing multi-agent coordination benchmarks.
 
Run with:
    streamlit run dashboard.py
"""
 
import json
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
 
import pandas as pd
import streamlit as st
 
ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(ROOT))
 
# ── Page config ───────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CoordBench Dashboard",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)
 
# ── Global CSS ────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* ── Base & fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
 
/* ── Page background ── */
.stApp { background: linear-gradient(135deg, #0f0c29, #302b63, #24243e); }
 
/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    border-right: 1px solid rgba(255,255,255,0.08);
}
[data-testid="stSidebar"] * { color: #e0e0e0 !important; }
[data-testid="stSidebar"] .stSelectbox label,
[data-testid="stSidebar"] .stCheckbox label { color: #b0b8d4 !important; }
 
/* ── Hero header ── */
.hero-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-size: 2.8rem;
    font-weight: 700;
    line-height: 1.2;
    margin-bottom: 0.2rem;
}
.hero-sub {
    color: #8892b0;
    font-size: 0.95rem;
    margin-bottom: 1.5rem;
    letter-spacing: 0.05em;
}
 
/* ── Section headers ── */
.section-header {
    font-size: 1.1rem;
    font-weight: 600;
    color: #ccd6f6;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    margin: 1.5rem 0 0.8rem 0;
    padding-bottom: 0.4rem;
    border-bottom: 2px solid rgba(102,126,234,0.4);
}
 
/* ── Metric cards ── */
.metric-card {
    background: linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.03) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    padding: 1.2rem 1.4rem;
    text-align: center;
    backdrop-filter: blur(10px);
    transition: transform 0.2s, box-shadow 0.2s;
    margin-bottom: 0.5rem;
}
.metric-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 30px rgba(102,126,234,0.25);
}
.metric-label {
    font-size: 0.75rem;
    font-weight: 500;
    color: #8892b0;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 0.4rem;
}
.metric-value {
    font-size: 1.8rem;
    font-weight: 700;
    color: #ccd6f6;
    line-height: 1.1;
}
.metric-delta {
    font-size: 0.85rem;
    color: #64ffda;
    margin-top: 0.2rem;
    font-weight: 500;
}
.metric-delta.bad { color: #ff6b9d; }
 
/* ── Leaderboard ── */
.lb-container {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px;
    overflow: hidden;
}
.lb-row {
    display: flex;
    align-items: center;
    padding: 0.85rem 1.2rem;
    border-bottom: 1px solid rgba(255,255,255,0.05);
    transition: background 0.15s;
    gap: 1rem;
}
.lb-row:last-child { border-bottom: none; }
.lb-row:hover { background: rgba(102,126,234,0.08); }
.lb-rank { font-size: 1.4rem; min-width: 2rem; text-align: center; }
.lb-framework {
    font-size: 0.7rem;
    font-weight: 600;
    padding: 0.2rem 0.6rem;
    border-radius: 20px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    min-width: 80px;
    text-align: center;
}
.fw-autogen  { background: rgba(100,255,218,0.15); color: #64ffda; border: 1px solid rgba(100,255,218,0.3); }
.fw-crewai   { background: rgba(240,147,251,0.15); color: #f093fb; border: 1px solid rgba(240,147,251,0.3); }
.fw-langgraph{ background: rgba(255,154,100,0.15); color: #ff9a64; border: 1px solid rgba(255,154,100,0.3); }
.fw-default  { background: rgba(200,200,200,0.15); color: #ccc;    border: 1px solid rgba(200,200,200,0.3); }
.lb-model    { color: #a8b2d8; font-size: 0.85rem; flex: 1; min-width: 120px; }
.lb-sr       { font-weight: 700; color: #64ffda; min-width: 110px; text-align: center; font-size: 0.9rem; }
.lb-fm       { color: #8892b0; font-size: 0.78rem; flex: 2; }
.lb-cost     { color: #ffb347; font-size: 0.8rem; min-width: 150px; text-align: right; }
.lb-header {
    display: flex;
    padding: 0.5rem 1.2rem;
    gap: 1rem;
    background: rgba(102,126,234,0.12);
    border-bottom: 1px solid rgba(102,126,234,0.2);
}
.lb-header span {
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #667eea;
}
 
/* ── Archetype cards ── */
.arch-card {
    background: linear-gradient(135deg, rgba(102,126,234,0.1), rgba(118,75,162,0.1));
    border: 1px solid rgba(102,126,234,0.2);
    border-radius: 14px;
    padding: 1.2rem;
    text-align: center;
    height: 100%;
}
.arch-title { font-size: 0.8rem; font-weight: 600; color: #8892b0; text-transform: uppercase; letter-spacing: 0.06em; }
.arch-score { font-size: 2rem; font-weight: 700; color: #ccd6f6; margin: 0.3rem 0; }
.arch-pct   { font-size: 1rem; color: #64ffda; font-weight: 600; }
.arch-meta  { font-size: 0.75rem; color: #8892b0; margin-top: 0.4rem; }
 
/* ── Failure mode badge ── */
.fm-badge {
    display: inline-block;
    background: rgba(255,107,157,0.12);
    border: 1px solid rgba(255,107,157,0.25);
    color: #ff6b9d;
    border-radius: 20px;
    padding: 0.15rem 0.6rem;
    font-size: 0.72rem;
    font-weight: 500;
    margin: 0.15rem;
}
 
/* ── Welcome cards ── */
.welcome-card {
    background: linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 14px;
    padding: 1.2rem 1.4rem;
    margin-bottom: 0.8rem;
}
.welcome-card h4 { color: #ccd6f6; margin: 0 0 0.4rem 0; font-size: 0.95rem; }
.welcome-card p  { color: #8892b0; margin: 0; font-size: 0.85rem; line-height: 1.5; }
 
/* ── Divider ── */
.custom-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(102,126,234,0.4), transparent);
    margin: 1.5rem 0;
}
 
/* ── Dataframe styling ── */
[data-testid="stDataFrame"] {
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.08) !important;
}
 
/* ── Progress bar ── */
.stProgress > div > div { background: linear-gradient(90deg, #667eea, #f093fb) !important; border-radius: 4px; }
 
/* ── Buttons ── */
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #667eea, #764ba2) !important;
    border: none !important;
    border-radius: 10px !important;
    font-weight: 600 !important;
    letter-spacing: 0.04em !important;
    padding: 0.6rem 1.2rem !important;
    transition: opacity 0.2s !important;
}
.stButton > button[kind="primary"]:hover { opacity: 0.85 !important; }
.stButton > button:not([kind="primary"]) {
    background: rgba(255,255,255,0.06) !important;
    border: 1px solid rgba(255,255,255,0.12) !important;
    border-radius: 10px !important;
    color: #ccd6f6 !important;
}
 
/* ── Info / success / error boxes ── */
.stAlert { border-radius: 12px !important; border: none !important; }
 
/* ── Hide Streamlit branding ── */
#MainMenu, footer, header { visibility: hidden; }
</style>
""", unsafe_allow_html=True)
 
# ── Constants ─────────────────────────────────────────────────────────────
RESULTS_DIR = ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
 
FRAMEWORKS = ["langgraph", "autogen", "crewai"]
MODELS = [
    "gpt-4o",
    "gpt-4o-mini",
    "anthropic/claude-opus-4-7",
    "anthropic/claude-sonnet-4-6",
    "anthropic/claude-3-5-sonnet",
    "anthropic/claude-3-haiku",
    "google/gemini-pro-1.5",
]
TASK_TYPE_LABELS = {
    "role_locked":           "Role Locked (RL)",
    "sequential_handoff":    "Sequential Handoff (SH)",
    "verification_gauntlet": "Verification Gauntlet (VG)",
}
FAILURE_MODE_LABELS = {
    "loop":                       "Loop / Step Repetition",
    "stagnation":                 "Stagnation",
    "premature_termination":      "Premature Termination",
    "termination_blindness":      "Termination Blindness",
    "context_degradation":        "Context Degradation",
    "task_disobedience":          "Task Disobedience",
    "coordination_overhead":      "Coordination Overhead",
    "agent_dominance":            "Agent Dominance",
    "handoff_corruption":         "Handoff Corruption",
    "echo_chamber":               "Echo Chamber",
    "sycophantic_convergence":    "Sycophantic Convergence",
    "role_drift":                 "Role Drift",
    "info_siloing":               "Information Siloing",
    "reasoning_action_mismatch":  "Reasoning-Action Mismatch",
    "unresolved_conflict":        "Unresolved Conflict",
    "superficial_verification":   "Superficial Verification",
    "incorrect_verification":     "Incorrect Verification",
    "role_rigidity":              "Role Rigidity",
    "credit_assignment_ambiguity":"Credit Assignment Ambiguity",
}
FW_CSS = {
    "autogen":   "fw-autogen",
    "crewai":    "fw-crewai",
    "langgraph": "fw-langgraph",
}
RANK_MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}
 
# ── Session state ─────────────────────────────────────────────────────────
def _init_state() -> None:
    defaults = {
        "is_running":   False,
        "progress":     0.0,
        "progress_msg": "",
        "run_results":  None,
        "run_error":    None,
        "selected_file":None,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v
 
_init_state()
 
# ── Helpers ───────────────────────────────────────────────────────────────
def list_result_files() -> List[Path]:
    return sorted(RESULTS_DIR.glob("*.json"), reverse=True)
 
def load_result_file(path: Path) -> Optional[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None
 
def fw_badge(fw: str) -> str:
    css = FW_CSS.get(fw.lower(), "fw-default")
    return f'<span class="lb-framework {css}">{fw.upper()}</span>'
 
# ── Background benchmark thread ───────────────────────────────────────────
def _benchmark_thread(framework, model, task_types, quick_mode) -> None:
    try:
        from Backend.benchmark_runner import run_benchmark
 
        def _cb(current, total, msg):
            st.session_state.progress     = current / max(1, total)
            st.session_state.progress_msg = msg
 
        results = run_benchmark(
            framework=framework,
            model=model,
            task_types=task_types,
            quick_mode=quick_mode,
            progress_callback=_cb,
        )
        st.session_state.run_results = results
        st.session_state.run_error   = None
    except Exception as exc:
        st.session_state.run_error   = str(exc)
        st.session_state.run_results = None
    finally:
        st.session_state.is_running  = False
        st.session_state.progress    = 1.0
 
# ── Sidebar ───────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
        <div style='text-align:center; padding: 1rem 0 0.5rem 0;'>
            <div style='font-size:2.5rem;'>🤖</div>
            <div style='font-size:1.2rem; font-weight:700; color:#ccd6f6;'>CoordBench</div>
            <div style='font-size:0.75rem; color:#8892b0; letter-spacing:0.08em;'>MULTI-AGENT BENCHMARK</div>
        </div>
    """, unsafe_allow_html=True)
    st.divider()
 
    st.markdown("<div style='color:#667eea; font-size:0.75rem; font-weight:600; letter-spacing:0.1em; text-transform:uppercase; margin-bottom:0.6rem;'>⚙ Run Configuration</div>", unsafe_allow_html=True)
 
    framework    = st.selectbox("Framework", FRAMEWORKS, index=0)
    model_choice = st.selectbox("Model", MODELS + ["custom..."], index=0)
    if model_choice == "custom...":
        model = st.text_input("Custom model (OpenRouter format)", value="gpt-4o")
    else:
        model = model_choice
 
    st.markdown("<div style='color:#8892b0; font-size:0.8rem; margin: 0.6rem 0 0.3rem 0;'>Task Types</div>", unsafe_allow_html=True)
    sel_rl = st.checkbox("Role Locked (10 tasks)",           value=True)
    sel_sh = st.checkbox("Sequential Handoff (10 tasks)",    value=True)
    sel_vg = st.checkbox("Verification Gauntlet (10 tasks)", value=True)
 
    task_types = []
    if sel_rl: task_types.append("role_locked")
    if sel_sh: task_types.append("sequential_handoff")
    if sel_vg: task_types.append("verification_gauntlet")
 
    quick_mode = st.toggle(
        "Quick mode",
        value=True,
        help="Quick: 8 rule-based detectors, seconds per task.\nFull: all 19 detectors incl. LLM judges, ~60s per task.",
    )
    st.divider()
 
    run_btn = st.button(
        "▶  Run Benchmark",
        use_container_width=True,
        disabled=st.session_state.is_running or not task_types,
        type="primary",
    )
 
    if run_btn and not st.session_state.is_running:
        st.session_state.is_running   = True
        st.session_state.progress     = 0.0
        st.session_state.progress_msg = "Starting…"
        st.session_state.run_results  = None
        st.session_state.run_error    = None
        threading.Thread(
            target=_benchmark_thread,
            args=(framework, model, task_types, quick_mode),
            daemon=True,
        ).start()
 
    st.divider()
    st.markdown("<div style='color:#667eea; font-size:0.75rem; font-weight:600; letter-spacing:0.1em; text-transform:uppercase; margin-bottom:0.6rem;'>📂 Load Saved Results</div>", unsafe_allow_html=True)
    result_files = list_result_files()
    if result_files:
        labels       = [f.stem for f in result_files]
        chosen_label = st.selectbox("Select run", labels, index=0)
        chosen_path  = result_files[labels.index(chosen_label)]
        if st.button("Load Results", use_container_width=True):
            st.session_state.run_results = load_result_file(chosen_path)
            st.session_state.run_error   = None
    else:
        st.info("No saved results yet.")
 
# ── Hero header ───────────────────────────────────────────────────────────
st.markdown('<div class="hero-header">CoordBench</div>', unsafe_allow_html=True)
st.markdown('<div class="hero-sub">COORDINATION FAILURE DASHBOARD · MAST 14-MODE TAXONOMY</div>', unsafe_allow_html=True)
 
# ── Leaderboard ───────────────────────────────────────────────────────────
st.markdown('<div class="section-header">🏆 Leaderboard — Framework × Model</div>', unsafe_allow_html=True)
 
_lb_files = list_result_files()
if not _lb_files:
    st.info("No results yet — run a benchmark to populate the leaderboard.")
else:
    _seen: Dict[str, Dict] = {}
    for _f in _lb_files:
        _d = load_result_file(_f)
        if not _d:
            continue
        _key = f"{_d.get('framework','?')}|{_d.get('model','?')}"
        _sr  = _d.get("success_rate", 0)
        if _key not in _seen or _sr > _seen[_key]["_sr"]:
            _fm   = _d.get("failure_mode_counts", {})
            _top3 = sorted(_fm.items(), key=lambda x: -x[1])[:3]
            _seen[_key] = {
                "fw":     _d.get("framework", "?"),
                "model":  _d.get("model", "?"),
                "succ":   _d.get("tasks_succeeded", 0),
                "total":  _d.get("total_tasks", 0),
                "sr":     _sr,
                "top3":   _top3,
                "turns":  _d.get("avg_turns", 0),
                "tokens": int(_d.get("avg_total_tokens", 0)),
                "_sr":    _sr,
            }
 
    _lb_rows = sorted(_seen.values(), key=lambda x: (-x["_sr"], x["turns"]))
 
    # Header row
    lb_html = """
    <div class="lb-container">
      <div class="lb-header">
        <span style="min-width:2rem">Rank</span>
        <span style="min-width:80px">Framework</span>
        <span style="flex:1">Model</span>
        <span style="min-width:110px;text-align:center">Success Rate</span>
        <span style="flex:2">Top Failure Modes</span>
        <span style="min-width:150px;text-align:right">Avg Coord. Cost</span>
      </div>
    """
    for _i, _row in enumerate(_lb_rows, 1):
        _medal    = RANK_MEDALS.get(_i, f"#{_i}")
        _badge    = fw_badge(_row["fw"])
        _pct      = f"{_row['sr']*100:.1f}%"
        _sr_str   = f"{_row['succ']}/{_row['total']} ({_pct})"
        _fm_badges = "".join(
            f'<span class="fm-badge">{FAILURE_MODE_LABELS.get(k, k)} ({v})</span>'
            for k, v in _row["top3"]
        ) or '<span style="color:#64ffda;font-size:0.78rem">✓ None</span>'
        _cost_str = f"{_row['turns']:.1f} turns / {_row['tokens']:,} tok"
        lb_html += f"""
      <div class="lb-row">
        <span class="lb-rank">{_medal}</span>
        {_badge}
        <span class="lb-model">{_row['model']}</span>
        <span class="lb-sr">{_sr_str}</span>
        <span class="lb-fm">{_fm_badges}</span>
        <span class="lb-cost">{_cost_str}</span>
      </div>
        """
    lb_html += "</div>"
    st.markdown(lb_html, unsafe_allow_html=True)
 
st.markdown('<div class="custom-divider"></div>', unsafe_allow_html=True)
 
# ── Progress indicator ────────────────────────────────────────────────────
if st.session_state.is_running:
    st.info(f"⏳ {st.session_state.progress_msg or 'Running benchmark…'}")
    st.progress(st.session_state.progress)
    time.sleep(0.8)
    st.rerun()
 
if st.session_state.run_error:
    st.error(f"Benchmark failed: {st.session_state.run_error}")
 
# ── Results display ───────────────────────────────────────────────────────
results: Optional[Dict[str, Any]] = st.session_state.run_results
 
if results is None:
    st.markdown('<div class="section-header">Getting Started</div>', unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("""
        <div class="welcome-card">
            <h4>🔒 Role Locked</h4>
            <p>Agents have strict role boundaries. Tests role adherence and cross-agent handoffs under constraint.</p>
        </div>""", unsafe_allow_html=True)
    with c2:
        st.markdown("""
        <div class="welcome-card">
            <h4>🔁 Sequential Handoff</h4>
            <p>Information must pass through an A→B→C→D chain without corruption or loss across agents.</p>
        </div>""", unsafe_allow_html=True)
    with c3:
        st.markdown("""
        <div class="welcome-card">
            <h4>✅ Verification Gauntlet</h4>
            <p>Verifiers must actually invoke tools before approving. Tests for superficial verification patterns.</p>
        </div>""", unsafe_allow_html=True)
 
    st.markdown("""
    <div style='background:rgba(102,126,234,0.08);border:1px solid rgba(102,126,234,0.2);border-radius:14px;padding:1.2rem 1.6rem;margin-top:0.5rem;color:#8892b0;font-size:0.85rem;line-height:1.7;'>
        <b style='color:#ccd6f6;'>Quick start:</b>
        Choose a framework and model in the sidebar → select task types → click <b style='color:#667eea;'>▶ Run Benchmark</b>.<br>
        Or load a previously saved run from <b style='color:#667eea;'>Load Saved Results</b>.
    </div>
    """, unsafe_allow_html=True)
    st.stop()
 
# ── Run header ────────────────────────────────────────────────────────────
fw  = results.get("framework", "?")
mdl = results.get("model", "?")
ts  = results.get("timestamp", "")
 
st.markdown(
    f'<div style="display:flex;align-items:center;gap:0.8rem;margin-bottom:0.3rem;">'
    f'{fw_badge(fw)}'
    f'<span style="font-size:1.3rem;font-weight:700;color:#ccd6f6;">{mdl}</span>'
    f'</div>'
    f'<div style="color:#8892b0;font-size:0.78rem;margin-bottom:1rem;">Run: {ts}</div>',
    unsafe_allow_html=True,
)
 
# ── Key metrics ───────────────────────────────────────────────────────────
sr = results.get("success_rate", 0)
c1, c2, c3, c4, c5 = st.columns(5)
metrics = [
    (c1, "Success Rate",  f"{results.get('tasks_succeeded',0)}/{results.get('total_tasks',0)}", f"{sr*100:.1f}%", sr >= 0.5),
    (c2, "Avg Turns",     f"{results.get('avg_turns', 0):.1f}", "turns", True),
    (c3, "Avg Tokens",    f"{int(results.get('avg_total_tokens', 0)):,}", "tokens", True),
    (c4, "Avg Latency",   f"{int(results.get('avg_latency_ms', 0)):,}", "ms", True),
    (c5, "Failure Modes", str(len(results.get("failure_mode_counts", {}))), "detected", False),
]
for col, label, val, delta, good in metrics:
    delta_cls = "" if good else "bad"
    col.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">{label}</div>
        <div class="metric-value">{val}</div>
        <div class="metric-delta {delta_cls}">{delta}</div>
    </div>""", unsafe_allow_html=True)
 
st.markdown('<div class="custom-divider"></div>', unsafe_allow_html=True)
 
task_results: List[Dict] = results.get("task_results", [])
 
# ── Failure mode counts ───────────────────────────────────────────────────
st.markdown('<div class="section-header">⚠️ Failure Mode Breakdown</div>', unsafe_allow_html=True)
fm_counts = results.get("failure_mode_counts", {})
if fm_counts:
    total_tasks_n = results.get("total_tasks", 1)
    fm_rows = []
    for fm_key, count in sorted(fm_counts.items(), key=lambda x: -x[1]):
        pct = count / total_tasks_n * 100
        fm_rows.append({
            "Failure Mode":   FAILURE_MODE_LABELS.get(fm_key, fm_key),
            "Tasks Affected": count,
            "% of Tasks":     f"{pct:.0f}%",
        })
    st.dataframe(fm_rows, use_container_width=True, hide_index=True)
else:
    st.success("✅ No coordination failures detected in this run.")
 
# ── Comparison View ───────────────────────────────────────────────────────
st.markdown('<div class="custom-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">🆚 Compare Runs</div>', unsafe_allow_html=True)
 
result_files_all = list_result_files()
if len(result_files_all) < 2:
    st.info("Need at least 2 saved result files to compare runs.")
else:
    labels_all    = [f.stem for f in result_files_all]
    loaded_slug   = mdl.replace("/", "_").replace(":", "_")
    loaded_stem   = f"{fw}_{loaded_slug}_{ts}"
    same_fw_stems = [l for l in labels_all if l.startswith(f"{fw}_") and l != loaded_stem]
    default_sel   = (([loaded_stem] if loaded_stem in labels_all else []) + same_fw_stems)[:3]
 
    selected_labels = st.multiselect(
        "Select runs to compare",
        labels_all,
        default=default_sel,
        key=f"cmp_multi_{loaded_stem}",
    )
 
    if len(selected_labels) < 2:
        st.warning("Select at least 2 runs to compare.")
    else:
        runs = [load_result_file(result_files_all[labels_all.index(lbl)]) for lbl in selected_labels]
        runs = [r for r in runs if r]
 
        def _run_label(d):
            return f"{d.get('framework','?').upper()} + {d.get('model','?')}"
 
        def _type_stats(d):
            stats = {}
            for r in d.get("task_results", []):
                tt = r.get("task_type", "unknown")
                stats.setdefault(tt, {"total": 0, "success": 0, "tokens": []})
                stats[tt]["total"]   += 1
                stats[tt]["success"] += int(r.get("task_success", False))
                stats[tt]["tokens"].append(r.get("total_tokens", 0))
            return stats
 
        run_labels = [_run_label(r) for r in runs]
        archetypes = ["role_locked", "sequential_handoff", "verification_gauntlet"]
 
        st.markdown("**Overall Metrics**")
        row_defs = [
            ("Success Rate",  lambda d: f"{d.get('tasks_succeeded',0)}/{d.get('total_tasks',0)} ({d.get('success_rate',0)*100:.1f}%)"),
            ("Avg Turns",     lambda d: f"{d.get('avg_turns',0):.1f}"),
            ("Avg Tokens",    lambda d: f"{int(d.get('avg_total_tokens',0)):,}"),
            ("Avg Latency",   lambda d: f"{int(d.get('avg_latency_ms',0)):,} ms"),
            ("Failure Modes", lambda d: str(len(d.get("failure_mode_counts", {})))),
        ]
        metric_rows = []
        for label, fn in row_defs:
            row = {"Metric": label}
            for rl, rd in zip(run_labels, runs):
                row[rl] = fn(rd)
            metric_rows.append(row)
        st.dataframe(pd.DataFrame(metric_rows).set_index("Metric"), use_container_width=True)
 
        st.markdown("**Success Rate by Task Type**")
        arch_rows = []
        for tt in archetypes:
            row = {"Task Type": TASK_TYPE_LABELS.get(tt, tt)}
            for rl, rd in zip(run_labels, runs):
                s   = _type_stats(rd).get(tt, {"total": 0, "success": 0, "tokens": []})
                pct = s["success"] / max(1, s["total"]) * 100
                avg_tok = sum(s["tokens"]) / max(1, len(s["tokens"]))
                row[rl] = f"{s['success']}/{s['total']} ({pct:.0f}%)  ~{avg_tok:,.0f} tok"
            arch_rows.append(row)
        st.dataframe(pd.DataFrame(arch_rows).set_index("Task Type"), use_container_width=True)
 
        st.markdown("**Failure Mode Counts**")
        all_fms = sorted(set().union(*[set(r.get("failure_mode_counts", {}).keys()) for r in runs]))
        if all_fms:
            fm_rows = []
            for fm in all_fms:
                row = {"Failure Mode": FAILURE_MODE_LABELS.get(fm, fm)}
                for rl, rd in zip(run_labels, runs):
                    row[rl] = rd.get("failure_mode_counts", {}).get(fm, 0)
                fm_rows.append(row)
            st.dataframe(pd.DataFrame(fm_rows).set_index("Failure Mode"), use_container_width=True)
        else:
            st.success("✅ No failure modes in selected runs.")
 
# ── Footer ────────────────────────────────────────────────────────────────
st.markdown('<div class="custom-divider"></div>', unsafe_allow_html=True)
st.markdown("""
<div style='text-align:center; color:#8892b0; font-size:0.75rem; letter-spacing:0.06em; padding-bottom:1rem;'>
    CoordBench v0.1 &nbsp;·&nbsp; MAST 14-mode taxonomy &nbsp;·&nbsp;
    LangGraph &nbsp;·&nbsp; AutoGen &nbsp;·&nbsp; CrewAI
</div>
""", unsafe_allow_html=True)
 