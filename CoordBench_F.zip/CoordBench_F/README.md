# CoordBench — Multi-Agent Coordination Failure Benchmark



## Overview

Existing multi-agent benchmarks (AgentBench, SWE-bench, τ-bench) measure only whether a task succeeds or fails — not **why** agents failed to coordinate. When a multi-agent run goes wrong, practitioners cannot tell whether it was caused by information siloing, an echo chamber, a loop, premature termination, or any of a dozen other failure patterns.

**CoordBench** (MAC-Bench) addresses this gap. It is a research-grade evaluation suite that:

- Captures full interaction transcripts between agents via an interceptor proxy
- Applies a **19-detector hybrid swarm** (programmatic rules + LLM-as-judge + heuristics) to identify coordination failures
- Evaluates across **frameworks** (LangGraph, AutoGen) and **models** (Claude Opus 4.7, GPT-4o, GPT-4o-mini)
- Produces reproducible leaderboards broken down by failure mode

---


---

## Setup

### Prerequisites

- Python 3.10+
- API keys set in a `.env` file at the project root:

```env
OPENROUTER_API_KEY=...
OPENAI_API_KEY=...
ANTHROPIC_API_KEY=...
```

### Install

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Or core only
pip install -e .
```

### Docker

```bash
docker build -t mac-bench .
docker run -e OPENROUTER_API_KEY=$KEY mac-bench \
  run \
  --task-file Backend/tasks/verification_gaunlet.py \
  --framework langgraph \
  --model gpt-4o
```

---

## Usage

### Full Benchmark Run

Runs all 30 tasks for a given framework × model combination, evaluates with all 19 detectors, and writes results to `Backend/results/`.

```bash
python Backend/benchmark_runner.py \
  --framework langgraph \
  --model gpt-4o \
  --full-eval
```

### Single Task (Harness CLI)

```bash
python -m Backend.harness.run_harness run \
  --task-file Backend/tasks/verification_gaunlet.py \
  --framework langgraph \
  --model gpt-4o \
  --proxy-url http://localhost:8080/v1
```

### Validate Detectors Against Gold Labels

Computes Cohen's κ per failure mode against manually-annotated transcripts (target: κ ≥ 0.65).

```bash
python -m Backend.validation.validate_detectors

# Specific modes only
python -m Backend.validation.validate_detectors --modes loop,echo_chamber
```

### Dashboard

Interactive results browser — view leaderboards, filter by framework/model/task, and drill into transcripts.

```bash
streamlit run Frontend/dashboard.py
# Opens at http://localhost:8501
```

### Typical Full Workflow

```bash
# 1. Start the interceptor proxy
python -m Backend.harness.interceptor_proxy &

# 2. Run the benchmark
python Backend/benchmark_runner.py --framework langgraph --model claude-opus-4-7 --full-eval

# 3. (Optional) Validate detectors against gold labels
python -m Backend.validation.validate_detectors

# 4. View results
streamlit run Frontend/dashboard.py
```

> **Note:** Each framework × model combination takes approximately 2–4 hours (30 tasks × ~5 min per task).

---

## Team Members

- Haaswith Sai Tripuraneni
- Mangali Prathyusha
- Somik Bansal

---

## Folder Structure

```
frontend/   — Streamlit dashboard
backend/    — Benchmark harness, detectors, tasks, evaluators, results
docs/       — Methodology, ablation study, presentation slides
```
