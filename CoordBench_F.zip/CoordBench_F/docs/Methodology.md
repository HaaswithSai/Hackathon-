# Methodology — MAC-Bench / CoordBench Team

---

## 1. Problem Statement

Multi-agent systems built on LLMs are increasingly deployed to solve complex tasks through collaboration — research assistants, coding teams, customer-support workflows, and scientific pipelines. Yet existing evaluation methods score only final task outcomes and tell practitioners nothing about *how* agents interacted or *why* a run failed.

We are building **MAC-Bench** — a benchmark that systematically measures how multi-agent LLM systems fail at coordination, not just whether they get the final answer right. The benchmark is designed for researchers and framework engineers who need to diagnose and rank coordination quality across systems.

**Success looks like:** a reusable package — task suite, failure taxonomy, automated detectors, and a reproducible harness — that any practitioner can run to get a framework × model leaderboard with a per-failure-mode breakdown, where every number can be reproduced from the public repository.

---

## 2. Background & Motivation

Multi-agent frameworks (LangGraph, AutoGen, CrewAI) are now widely deployed in production. Despite this, all major existing agent benchmarks — AgentBench, τ-bench, AgentDojo, SWE-bench — score the final task outcome only. They do not measure coordination quality at all, so when a system fails, practitioners cannot answer the most important question: *why did it fail?*

Did one agent misunderstand another? Did agents agree into a wrong answer (echo chamber)? Did one agent dominate and silence the others? Did critical information known to one agent never reach the agent that needed it? Did the team loop indefinitely without progress?

Recent peer-reviewed work (MAST, 2025) has begun studying these failures qualitatively across seven frameworks, identifying 14 distinct failure modes. No public benchmark, however, defines them rigorously, detects them automatically, and ranks frameworks head-to-head. This is the gap MAC-Bench fills — comparable to how HELM became the reference for LLM evaluation and AgentDojo became the reference for prompt-injection defense.

---

## 3. Assumptions & Scope

**In scope:**
- Multi-agent task execution using LLM-based agents
- Interaction logging and full transcript capture via an interceptor proxy
- A 14-mode coordination failure taxonomy with falsifiable, binary definitions
- Hybrid automated detectors validated against human annotation
- Cross-framework benchmarking: LangGraph and AutoGen
- Cross-model benchmarking: Claude Opus 4.7, GPT-4o, GPT-4o-mini

**Out of scope:**
- Training or fine-tuning any underlying LLM (benchmark measures off-the-shelf models only)
- Real-time deployment systems or production monitoring
- Large-scale distributed infrastructure
- Reinforcement learning optimization of agent behavior
- More than two frameworks in the initial release (CrewAI deferred — adapter not yet stable)

**Key assumptions:**
- LLM APIs are reliable and available for the duration of experiments
- A task that a single frontier agent reliably fails (≥80% failure rate on single-agent baseline) genuinely requires coordination to solve
- Interaction logs captured at the API boundary are sufficient to reconstruct every agent's information state at each turn
- All task evaluators include a deterministic programmatic check; LLM-as-judge alone for final task success is not used

---

## 4. Approach Overview

MAC-Bench evaluates multi-agent systems by analyzing their internal interactions rather than only their final outputs — transforming evaluation from outcome-based to behavior-based. A transparent interceptor proxy captures every API call between agents and LLM providers without modifying framework internals. Captured transcripts are analyzed by a swarm of nineteen detectors organized into three tiers (programmatic, LLM-as-judge, and rule-based) that classify each run against a 14-mode failure taxonomy. Tasks are drawn from three coordination archetypes specifically engineered so that a single agent structurally cannot solve them. The final deliverable is a reproducible leaderboard crossing two frameworks with three frontier models, broken down by failure mode.

---

## 5. System Architecture

```
[Task Registry]
      |
      v
[Benchmark Harness Runner]  <-- sets run_id in proxy via admin endpoint
      |
      v
[Framework Adapter]  (LangGraph | AutoGen)
      |
      v  (all /chat/completions traffic routed through)
[Interceptor Proxy]  localhost:8080  (FastAPI)
      |  -- normalizes payloads, injects credentials, logs latency
      |  -- appends structured record to per-run JSONL transcript
      v
[LLM Provider API]  (Anthropic | OpenAI)
      |
      v  (response returned via proxy)
[Transcript Store]  logs/{framework}/{model}/{task_id}.jsonl
      |
      v
[Evaluation Pipeline]
      |-- [Programmatic Evaluators]  (exact-match JSON vs. ground truth)
      |-- [MAST Detector Swarm]  (19 detectors x 3 tiers)
              |-- Tier 1: 5 programmatic detectors  (loop, termination, overhead, context, disobedience)
              |-- Tier 2: 11 LLM-as-judge detectors  (Claude Opus 4.7, separate API key)
              |-- Tier 3: 3 rule-based detectors     (handoff_corruption, stagnation, dominance)
      |
      v
[Aggregator]  confidence-weighted voting → failure-mode label set per run
      |
      v
[Results & Leaderboard]  results/leaderboard.json  (fully reproducible from stored JSONs)
```

**Component notes:**

- *Task Registry* (`tasks/registry.json`): 50 tasks across three archetypes, each with a deterministic ground-truth JSON and a task-specific programmatic evaluator in `evaluators/`.
- *Interceptor Proxy* (`harness/interceptor_proxy.py`): Captures the full message array, token counts, wall-clock latency, and run identifier per turn. Enables Hallucinated Verification detection by cross-referencing claimed tool calls against actual API events.
- *Aggregator* (`detectors/aggregator.py`): A failure mode is added to the label set if a high-confidence programmatic detector fires, or if two or more medium-confidence LLM judges and at least one rule-based detector agree.
- External services: Anthropic API (claude-opus-4-7), OpenAI API (gpt-4o, gpt-4o-mini).

---

## 6. Data

| Aspect | Details |
|---|---|
| Source | Custom-designed task suite; no external dataset reused |
| Size | 50 tasks (three archetypes × ~17 tasks each; current experimental run used 30) |
| Splits | Single evaluation set — no train/val/test split; benchmark is not trained on |
| Preprocessing | Tasks authored as JSON with agent role definitions, tool assignments, and exact-match ground-truth answers; loaded by `tasks/loader.py` |
| Known issues | Synthetic design — tasks do not come from real deployment logs; limited domain variety in v1; single-run evaluation introduces LLM variability; all 14 failure modes may not be equally represented across the 50 tasks |

**Task archetypes:**

| Archetype | Coordination bottleneck | Example failure surfaces |
|---|---|---|
| Verification Gauntlet (VG) | Tool access structurally partitioned across agents — neither agent can produce correct output alone | Information siloing, hallucinated verification |
| Sequential Handoff (SH) | Each agent's output is the mandatory input for the next; final answer requires all upstream handoffs | Context degradation, handoff corruption |
| Role-Locked Scheduling (RL) | Hard role constraints (e.g., agent may only approve, never propose); consensus required | Role drift, echo chamber, agent dominance |

Single-agent baselines were run on all tasks prior to the main experiment; tasks solved by a single frontier agent were removed to enforce the ≥80% single-agent failure rate requirement.

---

## 7. Models / Algorithms

**LLM Agents**

| Model | Provider | Temperature | Role |
|---|---|---|---|
| `claude-opus-4-7` | Anthropic | 0.0 | Primary evaluated agent |
| `gpt-4o` | OpenAI | 0.0 | Evaluated agent |
| `gpt-4o-mini` | OpenAI | 0.0 | Evaluated agent |

All models used zero-shot; no fine-tuning applied. Temperature set to 0.0 for maximum determinism.

**MAST Detector Swarm (19 detectors across 3 tiers)**

*Tier 1 — Programmatic (5 detectors, highest confidence weight):*
- `loop_detector.py` — Levenshtein distance on consecutive message sequences; fires if distance < threshold for 3+ turns
- `termination_detector.py` — Checks whether TERMINATE precedes or follows the programmatic evaluator's success signal
- `coordination_overhead.py` — Computes talk-to-action ratio and token overhead ratios
- `context_degradation.py` — Scans for constraints stated in turn 1 that are contradicted by the same agent in turn N
- `task_disobedience.py` — Verifies final output JSON against hard constraints

*Tier 2 — LLM-as-Judge (11 detectors, medium confidence weight):*
Judge model: `claude-opus-4-7` on a separate API key, independent of the models under evaluation. Each judge prompt enforces strict chain-of-thought: quote the specific turn evidencing the failure → identify the responsible agent → justify the verdict → render binary flag + confidence score. Covers: information siloing, echo chamber convergence, agent dominance, reasoning-action mismatch, unresolved conflict, superficial verification, incorrect verification, and four others mapped to Category 2 and 3 failure modes.

*Tier 3 — Rule-Based (3 detectors, lower confidence weight):*
- `handoff_corruption.py` — Detects truncation or overwriting of partial results across handoffs
- `stagnation.py` — Flags runs with no new tool calls for 5+ consecutive turns
- `dominance.py` — Counts per-agent token contributions; fires if any agent exceeds 80% of total volume

**MAST Taxonomy (14 failure modes in 3 categories)**

| Category | Failure Mode |
|---|---|
| Specification Issues (~42%) | Task Disobedience, Role Drift, Step Repetition/Looping, Context Degradation, Termination Blindness |
| Inter-Agent Misalignment (~37%) | Information Siloing, Echo Chamber Convergence, Agent Dominance, Reasoning-Action Mismatch, Unresolved Conflict |
| Task Verification (~21%) | Premature Termination, Superficial Verification, Incorrect Verification, Hallucinated Verification |

---

## 8. Implementation Details

**Stack**

| Component | Technology |
|---|---|
| Language | Python 3.10+ |
| Agent frameworks | LangGraph, AutoGen |
| LLM routing / proxy | LiteLLM + custom FastAPI interceptor |
| Serialization | JSON / JSONL |
| Dependency management | `pyproject.toml` (pinned versions) |
| Containerization | Docker (for full reproduction) |

**Compute:** API-based execution only — no local GPU required. All inference is handled by Anthropic and OpenAI APIs. Typical wall-clock time per full framework × model run: ~2–4 hours depending on API latency.

**Repro command:**
```bash
python benchmark_runner.py --framework langgraph --model claude-opus-4-7 --tasks all
```

**Determinism / seeds:** Framework random seeds are fixed where APIs permit. Model temperature is set to 0.0 for all evaluated models. Results will still show minor variance across re-runs due to LLM non-determinism at temperature 0; multi-run averaging is recommended for final reporting. Full environment is reproducible via Docker.

---

## 9. Evaluation Protocol

**Primary metric:** Task Success Rate — fraction of tasks where the programmatic evaluator confirms the correct ground-truth answer (exact-match JSON). This is the right primary metric because it is deterministic, not subject to LLM judge variance, and directly measures whether coordination produced a correct result.

**Secondary metrics:**

| Metric | Description |
|---|---|
| Failure-Mode Breakdown | Count and proportion of runs flagged for each of the 14 MAST modes |
| Average Turn Count | Mean agent turns per task run |
| Average Total Tokens | Mean tokens consumed per task run |
| Average Latency | Mean wall-clock time per API call (ms) |
| Talk-to-Action Ratio | Conversational turns / tool-call turns — measures coordination overhead |

**Baselines:**

| Baseline | Description |
|---|---|
| Single-agent baseline | Same frontier model, no multi-agent orchestration; used to verify coordination is the bottleneck (must fail ≥80% of tasks) |
| Fixed-role system | Static Planner–Executor–Critic topology, no dynamic orchestration; measures contribution of dynamic agent routing |
| Outcome-only evaluation | Success rate with no taxonomy analysis; establishes floor for diagnostic value |

**Detector validation:** All 19 detectors validated against human gold standard — 50 transcripts annotated independently by 3 human raters, disagreements resolved by structured discussion. Cohen's κ reported per failure mode. Pre-registered acceptance threshold: κ ≥ 0.65. Current results: 13/14 modes cleared the threshold; Reasoning-Action Mismatch (κ = 0.61) is the single below-threshold mode and is flagged as a known limitation.

**Statistical considerations:** v1 is a single-run evaluation; no confidence intervals are reported. Multi-run evaluation with mean ± std is planned for v2. No significance tests are applied to the current results given the sample size (30 tasks × 6 combinations).

---

## 10. Results Summary

Full per-failure-mode breakdown is in [ablation.md](ablation.md).

| Framework | Model | Task Success Rate | Avg Turns | Avg Tokens | Notes |
|---|---|---|---|---|---|
| Single-agent baseline | claude-opus-4-7 | ~3% | — | — | Confirms coordination is bottleneck |
| LangGraph | claude-opus-4-7 | **16.7% (5/30)** | 13.7 | 12,428 | Best overall; dominant failure: Premature Termination |
| AutoGen | gpt-4o-mini | 3.3% (1/30) | 19.6 | 18,642 | High stagnation rate |
| LangGraph | gpt-4o-mini | 3.3% (1/30) | 23.0 | 9,635 | High coordination overhead |
| LangGraph | gpt-4o | 0.0% (0/21) | 32.3 | 12,339 | Strongest model; worst success rate |

**Surprising finding:** GPT-4o (the strongest model tested) achieves 0% success with the highest turn count (32.3), while Claude Opus 4.7 achieves 16.7% at the lowest turn count. This demonstrates that model reasoning capability does not compensate for poor coordination behavior — the framework-model interaction matters more than raw capability.

---

## 11. Limitations & Failure Modes

**Reasoning-Action Mismatch detector is below threshold (κ = 0.61).** The LLM judge does not yet reliably force a quote of both the stated constraint and the violating action in the same output. Prompt refinement is underway; this mode's results should be interpreted with caution and are flagged in `docs/validation_report.md`.

**Synthetic task suite.** All 30 tasks are authored, not drawn from real deployment logs. The three archetypes cover meaningful coordination surfaces but may not reflect the full distribution of failures seen in production multi-agent systems.

**Single-run evaluation.** LLM non-determinism at temperature 0.0 still produces run-to-run variance. Headline numbers (e.g., 16.7%) are point estimates from one run and should not be treated as stable means.

**Only two frameworks evaluated.** CrewAI and other production frameworks are not yet included. Cross-framework generalizability of findings is limited.

**LLM judge shares provider with one evaluated model.** The Tier 2 judge uses Claude Opus 4.7 on a separate API key. For runs where the evaluated agent is also Claude Opus 4.7, there is a residual risk of shared systematic bias. This is partially mitigated by using a separate API key and different system prompt, but cannot be fully eliminated without switching judge providers for Claude-evaluated runs.

**Concrete failure example — Premature Termination (most common):** In a Verification Gauntlet task, the orchestrator emits `TERMINATE` after the Security Verifier reports its result, without waiting for the Performance Verifier's tool call to complete. The programmatic evaluator returns `fail` (incomplete JSON), but the framework has already torn down the agent loop. This failure appears in 30/30 runs across all framework × model combinations.

---

## 12. Future Work

Ranked by expected impact:

1. **Fix Premature Termination via orchestrator prompt engineering.** This is the single most common failure mode (present in every run). A targeted intervention — requiring the orchestrator to explicitly verify all expected tool results before emitting TERMINATE — is estimated to have the highest single-change impact on task success rate.

2. **Multi-run statistical evaluation.** Run each framework × model combination 5 times and report mean ± std. Convert current point estimates into statistically meaningful comparisons.

3. **Refine Reasoning-Action Mismatch prompt to reach κ ≥ 0.65.** Force the judge to quote both the stated constraint and the violating action before rendering a verdict. Revalidate against the held-out annotation set.

4. **Expand to CrewAI and one open-source framework** (e.g., a LangGraph-compatible open-source orchestrator). Three frameworks are required for the benchmark to be a meaningful cross-framework comparison.

5. **Expand task suite to 50 tasks with real-world grounding.** Incorporate tasks drawn from open-source multi-agent project transcripts (e.g., SWE-agent logs, AutoGen community examples) to complement the synthetic archetypes.

6. **Add Gemini and Grok to the model matrix.** The benchmark specification requires ≥3 frontier models; expanding to 5 increases generalizability and surfaces model-specific coordination patterns.

7. **Prescriptive interventions.** Show that a small, targeted change (different role prompt, added critic agent, topology switch) measurably moves a specific failure mode. This converts the benchmark from descriptive to prescriptive and is the stretch goal for v2.

---

## 13. References

Cemri et al. (2025). *Why Do Multi-Agent LLM Systems Fail?* — [https://arxiv.org/abs/2503.13657](https://arxiv.org/abs/2503.13657)

Zhu et al. (2025). *MultiAgentBench: Evaluating the Collaboration and Competition of LLM Agents.* ACL 2025 — [https://arxiv.org/abs/2503.01935](https://arxiv.org/abs/2503.01935)

Liu et al. (2023). *AgentBench: Evaluating LLMs as Agents.* ICLR 2024 — [https://arxiv.org/abs/2308.03688](https://arxiv.org/abs/2308.03688)

Debenedetti et al. (2024). *AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents.* NeurIPS 2024 — [https://arxiv.org/abs/2406.13352](https://arxiv.org/abs/2406.13352)

Jimenez et al. (2024). *SWE-bench: Can Language Models Resolve Real-World GitHub Issues?* ICLR 2024 — [https://arxiv.org/abs/2310.06770](https://arxiv.org/abs/2310.06770)

Yao et al. (2024). *τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains* — [https://arxiv.org/abs/2406.12045](https://arxiv.org/abs/2406.12045)

LangGraph — Graph-based agent orchestration framework — [https://github.com/langchain-ai/langgraph](https://github.com/langchain-ai/langgraph)

AutoGen — Multi-agent conversation framework by Microsoft — [https://github.com/microsoft/autogen](https://github.com/microsoft/autogen)

LiteLLM — Unified LLM API proxy — [https://github.com/BerriAI/litellm](https://github.com/BerriAI/litellm)