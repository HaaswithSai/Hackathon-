# Ablation Study — MAC-Bench: Multi-Agent Coordination Benchmark

---

## 1. Goal of the Ablation

The goal of this ablation study is to evaluate the contribution of each major component in MAC-Bench and understand how each affects coordination failure detection and system performance.

**Hypothesis:**  
Multi-agent failures are primarily caused by coordination issues such as premature termination, looping, and poor information flow. Components like transcript logging, hybrid detection, and dynamic agent orchestration are essential for accurately diagnosing these failures.

---

## 2. Setup

| Aspect | Value |
|---|---|
| Base model / system | MAC-Bench (Harness + Proxy + Evaluation Pipeline) |
| Dataset / eval set | 30 coordination-focused multi-agent tasks |
| Primary metric | Task Success Rate |
| Secondary metrics | Failure Modes, Avg Coordination Cost (turns) |
| Hardware | API-based execution |
| Seeds | Single run |
| Repro command | `python main.py --framework langgraph --tasks all` |

---

## 3. Variants Tested

| ID | Variant | Description | Knob being changed |
|---|---|---|---|
| V0 | Baseline | Full MAC-Bench system | — |
| V1 | No Failure Detection | Only success rate, no taxonomy | taxonomy on/off |
| V2 | No Transcript Logging | No proxy, no interaction logs | logging on/off |
| V3 | Fixed Agents | Planner–Executor–Critic only | dynamic agents on/off |
| V4 | No Hybrid Detection | Rule-only or LLM-only detection | hybrid on/off |
| V5 | Framework Change | LangGraph vs AutoGen | orchestration |
| V6 | Model Change | Claude vs GPT models | model |

---

## 4. Results

| Variant | Primary metric ↑ (Success Rate) | Secondary metric ↓ (Coord Cost) | Cost / call | Notes |
|---|---|---|---|---|
| V0 (baseline) | **16.7%** | 13.7 turns | Medium | Best performance |
| V1 | 16.7% | 13.7 turns | Medium | No failure insights |
| V2 | 16.7% | — | Low | No analysis possible |
| V3 | 3.3% | 23.0 turns | Medium | Reduced coordination quality |
| V4 | 10–12% | ~18 turns | Medium | Inconsistent detection |
| V5 | 3.3% (AutoGen) | 19.6 turns | Medium | Framework impact |
| V6 | 0–3.3% (GPT) | 23–32 turns | Medium | Model impact |

---

## 5. Per-Variant Analysis

### V1 — No Failure Detection
- **Effect on primary metric:** No change  
- **Effect on secondary metrics:** No behavioral insights  
- **Why this happened:** Only outcome measured, not interaction  
- **Failure cases / surprises:** Cannot explain failures  

---

### V2 — No Transcript Logging
- **Effect on primary metric:** No change  
- **Effect on secondary metrics:** No coordination analysis  
- **Why this happened:** No access to interaction data  
- **Failure cases / surprises:** Entire failure detection breaks  

---

### V3 — Fixed Agents
- **Effect on primary metric:** ↓ significant drop (16.7% → 3.3%)  
- **Effect on secondary metrics:** Increased coordination cost  
- **Why this happened:** Limited interaction flexibility  
- **Failure cases / surprises:** More looping and premature termination  

---

### V4 — No Hybrid Detection
- **Effect on primary metric:** Slight drop  
- **Effect on secondary metrics:** Reduced detection accuracy  
- **Why this happened:** Rules miss semantics, LLM lacks consistency  
- **Failure cases / surprises:** Inconsistent failure classification  

---

### V5 — Framework Change
- **Effect on primary metric:** LangGraph (16.7%) > AutoGen (3.3%)  
- **Effect on secondary metrics:** AutoGen has higher turns  
- **Why this happened:** Less structured orchestration in AutoGen  
- **Failure cases / surprises:** More stagnation and loops  

---

### V6 — Model Change
- **Effect on primary metric:** Claude > GPT models  
- **Effect on secondary metrics:** GPT has higher coordination cost  
- **Why this happened:** Models struggle with coordination, not reasoning  
- **Failure cases / surprises:** Even strong models fail due to premature termination  

---

## 6. Qualitative Examples

| Input | V0 output | V3 output | V5 output |
|---|---|---|---|
| Debug task | Correct + verified | Early stop | Looping |
| Planning task | Structured reasoning | Missing steps | Repeated reasoning |
| Conflict task | Resolved disagreement | Wrong consensus | Stagnation |

---

## 7. Takeaways

- Transcript logging is essential for analysis  
- Hybrid detection improves reliability  
- Dynamic agents significantly improve performance  
- Premature termination is the dominant failure mode  
- Framework design impacts coordination  
- Model strength alone does not ensure success  

---

## 8. Threats to Validity

- Small dataset (30 tasks)  
- Single-run evaluation  
- Potential bias in LLM-as-judge  
- Synthetic task design  
- Limited model coverage  

---

## 9. Open Questions / Next Ablations

- How does increasing number of agents affect failures?  
- Can premature termination be prevented with better routing?  
- What is the optimal coordination strategy?  
- How do different prompting strategies affect outcomes?  
- Can failures be predicted early during execution?  
