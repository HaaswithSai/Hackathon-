# MAC-Bench: Multi-Agent Coordination Benchmark Architecture

MAC-Bench is an evaluation framework designed to move beyond simple task completion metrics and rigorously test the **collaborative intelligence** and **interaction dynamics** of multi-agent LLM systems.

This document details the complete architecture of MAC-Bench, explaining how the components interact to simulate, detect, and evaluate complex social failures in multi-agent environments.

---

## High-Level Overview

MAC-Bench operates in four primary phases:

1. **Task Initialization**: Loads a scenario requiring explicit coordination (e.g., puzzles or adversarial scheduling) from the `tasks/` registry.
2. **Orchestration & Execution**: Executes the task using a specific multi-agent framework adapter (e.g., LangGraph, AutoGen). Adapters enforce strict "Memory Partitioning" to mandate cross-talk.
3. **Failure Detection**: As agents communicate, the resulting transcript is piped into "Social" Failure Detectors that scan for issues like dominance, deadlocks, and corrupted information handoffs.
4. **Evaluation & Metrics**: Computes final performance metrics, including coordination costs and a failure heatmap, outputting them to the Leaderboard.

```mermaid
graph TD
    A[Task Suite JSON] -->|Injects Constraints| B(Orchestration Harness)
    B --> C{Framework Adapters}
    C -->|LangGraph| D[Hierarchical Supervisor]
    C -->|AutoGen| E[Partitioned Group Chat]
    
    D --> F[Transcript Generation]
    E --> F
    
    F --> G[Advanced Failure Detectors]
    G -->|Dominance| H(Metrics & Leaderboard)
    G -->|Stagnation| H
    G -->|Handoff Corruption| H
```

---

## 1. Interaction Architecture (The Adapters)

To ensure true collaboration, MAC-Bench overrides the default behaviors of popular frameworks (like simple sequential handoffs or global message broadcasting) to force active negotiation and memory isolation.

### A. LangGraph Adapter (`langgraph_adapter.py`)
- **State Graph**: Implements an `AgentState` containing `agent_memories`. Instead of a single shared list of messages, every agent has a strictly isolated context window.
- **Hierarchical Supervisor**: Uses an LLM to dynamically decide the next speaker based on the `routing_history`.
- **How it works**: 
  - If Agent A needs information from Agent B, Agent A must explicitly output a message addressing `@AgentB`. 
  - The supervisor routes the conversation to Agent B, passing *only* the message directed at them into Agent B's local memory.

### B. AutoGen Adapter (`autogen_adapter.py`)
- **Dynamic Group Chat**: Configures the `GroupChat` with `speaker_selection_method="auto"`, allowing agents to organically interrupt or volunteer information.
- **Partitioned Group Chat Manager**: Subclasses `GroupChatManager` to intercept broadcasts.
- **How it works**: 
  - By default, PyAutoGen broadcasts every message to all agents. The custom `PartitionedGroupChatManager` checks the message content. 
  - If Agent A says *"The server is down"*, no other agent receives it. If Agent A says *"@OpsAgent The server is down"*, the manager exclusively sends the message to the `OpsAgent`.

> [!IMPORTANT]
> **Memory Partitioning** is the core mechanism that forces agents to "speak" to share information. Without it, agents could silently read from a global context and solve tasks without demonstrating coordination.

---

## 2. Dataset Engineering (The Tasks)

The `tasks/suite.json` contains specialized archetypes that mathematically require multi-agent interaction to solve. Single agents will fail these tasks 100% of the time.

### Archetype 1: Distributed Partial Information Puzzles (DPIP)
Each agent is seeded with a non-overlapping fragment of data.
- **Example**: 
  - Agent A's System Prompt: *"You hold part 1 of the code: '456'."*
  - Agent B's System Prompt: *"You hold part 2 of the code: '789'."*
- **Execution**: To output the final expected answer (`456789`), Agent A and Agent B must discover that the other possesses missing information and explicitly request it.

### Archetype 2: Adversarial Constraint Scheduling
Agents are given conflicting mandates, forcing a negotiation phase to find a middle ground.
- **Example**: 
  - OpsAgent constraint: Schedule maintenance between 02:00 and 06:00.
  - SalesAgent constraint: No maintenance between 00:00 and 04:00.
- **Execution**: The agents must debate and compromise on the overlapping valid window (04:00 to 06:00). If one yields entirely without honoring their constraint, a failure is triggered.

---

## 3. Advanced Failure Detectors

Once a task concludes, the transcript is passed to rule-based social detectors (`detectors/rule_detectors/`). These look beyond task success/failure to classify *why* coordination broke down.

| Detector | Component | How it Works (Example) |
| :--- | :--- | :--- |
| **Agent Dominance** | `dominance.py` | Calculates the "Rejection Ratio". If Agent A says *"No, you are wrong"* to Agent B 4 times without invoking a search tool or providing verifiable data, Agent A is flagged for Dominance. |
| **Inter-Agent Conflict** | `stagnation.py` | Uses Jaccard Similarity on the transcript to detect Deadlocks. If Agent A says *"We must use React"* and Agent B replies *"No, use HTMX"*, and this loop repeats identically 3 times, it triggers a stagnation flag. |
| **Handoff Corruption** | `handoff_corruption.py` | Uses regex to track explicit data points. If Agent A tells Agent B, *"The IP is 192.168.1.5"*, and Agent B subsequently attempts to ping `192.168.1.6`, a corruption failure is logged. |

---

## 4. Leaderboard & Evaluation Metrics

The final results are aggregated by `results/leaderboard.py`. Instead of just providing an accuracy percentage, the leaderboard offers deep behavioral insights into the multi-agent system.

### Key Metrics
- **Time-to-Consensus**: Measures the number of interaction turns required to reach the `TERMINATE` signal. 
  - *Insight*: Identifies frameworks that are slow to agree or constantly over-communicate.
- **Coordination Cost**: A token-ratio metric comparing `Conversation Tokens` (agents talking to each other) vs. `Execution Tokens` (agents using tools/APIs). 
  - *Insight*: High coordination cost indicates a highly inefficient architecture where agents spend more time debating than acting.
- **Failure Heatmap**: A cross-matrix mapping orchestration frameworks against specific social failure modes.

### Example Leaderboard Output

```text
============================================================
              MAC-BENCH LEADERBOARD & METRICS               
============================================================

Framework: LangGraph
Success Rate:      17/20 (85.0%)
Time-to-Consensus: 6.2 turns average
Coordination Cost: 2.15 (Conv: 43000 / Exec: 20000)

Framework: AutoGen
Success Rate:      12/20 (60.0%)
Time-to-Consensus: 14.5 turns average
Coordination Cost: 4.80 (Conv: 96000 / Exec: 20000)

============================================================
                      FAILURE HEATMAP                       
============================================================
Framework       | Deadlocks       | Dominance       | Handoff Corruption
------------------------------------------------------------------------
LangGraph       | 1               | 0               | 2              
AutoGen         | 4               | 3               | 1              
```

> [!TIP]
> Use the Failure Heatmap to identify architectural flaws. For example, if a framework consistently triggers "Deadlocks," it implies its speaker selection method lacks conflict-resolution mechanisms.
