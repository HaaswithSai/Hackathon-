# Multi-Agent Coordination Benchmark (mac-bench)

A scientific instrument to systematically measure **how** and **why** multi-agent LLM systems fail at coordination.

## Core Philosophy
Every existing benchmark asks "did the agents get the right answer?" — this benchmark asks "HOW did they fail to coordinate, and WHY?"

It consists of four interlocking pieces:
1. **A Task Suite (50-100 Tasks):** Specifically engineered so that coordination is the bottleneck. A single smart AI reliably fails, but a well-coordinating team can succeed.
2. **A Failure Taxonomy:** An ontology of 6 distinct ways multi-agent systems fail at coordination.
3. **Automated Detectors:** A hybrid system (Rule-based + LLM-as-Judge) that reads transcripts and automatically labels which failure modes occurred.
4. **A Leaderboard:** A Framework × Model matrix detailing success rates, failure-mode breakdowns, and efficiency metrics.

## Getting Started

1. Clone the repository
2. Copy `.env.example` to `.env` and insert your API keys:
   ```bash
   cp .env.example .env
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the benchmark:
   ```bash
   python harness/run_experiment.py --task T01 --framework crewai --model gpt-4o
   ```
5. Evaluate results:
   ```bash
   python harness/evaluate.py --run_id <RUN_ID>
   ```

## Repository Structure
- `/tasks`: JSON files defining tasks across the 6 families.
- `/evaluators`: Programmatic pass/fail scripts for each task.
- `/harness`: The execution layer that runs tasks on different frameworks.
- `/detectors`: The analysis pipeline containing rule-based and LLM-based failure detectors.
- `/results`: Stores transcripts and the aggregated leaderboard.
- `taxonomy.md`: The formal definitions of the 6 failure modes.
- `FAILURES.md`: Methodology trail documenting abandoned tasks and rejected detectors.
