import difflib

class FeatureExtractor:
    def __init__(self):
        self.agreement_keywords = ["agree", "correct", "yes", "makes sense", "exactly", "i concur", "that is right"]
        self.disagreement_keywords = ["disagree", "no", "incorrect", "wrong", "however", "but", "alternative", "issue"]
        
    def extract_features(self, transcript: list, task_spec: dict) -> dict:
        """
        Extracts behavioral features from the transcript for the detection layer.
        """
        if not transcript:
            return {
                "agreement_score": 0.0,
                "diversity_score": 1.0,
                "contribution_balance": 0.0,
                "critic_challenge_rate": 0.0,
                "info_flow_score": 0.0,
                "turn_count": 0,
                "repetition_score": 0.0
            }
            
        turn_count = len(transcript)
        total_words = 0
        agent_words = {}
        
        agreement_count = 0
        disagreement_count = 0
        critic_challenges = 0
        critic_turns = 0
        
        repetition_sum = 0.0
        
        private_keywords_found = 0
        total_private_keywords = 0
        
        # Gather private contexts to check information flow
        private_contexts = {}
        agent_profiles = task_spec.get('agent_profiles', [])
        
        # Handle dict format or list format for agent_profiles
        if isinstance(agent_profiles, dict):
            for aid, profile in agent_profiles.items():
                private_contexts[aid] = profile.get("private_context", "")
        else:
            for profile in agent_profiles:
                private_contexts[profile.get("agent_id", "")] = profile.get("private_context", "")
                
        # Simple extraction of long words as keywords from private context
        all_private_keywords = set()
        for ctx in private_contexts.values():
            words = [w.lower().strip('.,!?()"\'') for w in ctx.split()]
            keywords = {w for w in words if len(w) > 5}
            all_private_keywords.update(keywords)
            
        total_private_keywords = len(all_private_keywords)
        found_keywords = set()

        for i, turn in enumerate(transcript):
            content = turn.get("content", "").lower()
            agent = turn.get("agent_id", turn.get("agent", ""))
            role = turn.get("role", "").lower()
            
            # Word counts for balance
            words = len(content.split())
            agent_words[agent] = agent_words.get(agent, 0) + words
            total_words += words
            
            # Agreement/Disagreement
            has_agreement = any(kw in content for kw in self.agreement_keywords)
            has_disagreement = any(kw in content for kw in self.disagreement_keywords)
            
            if has_agreement:
                agreement_count += 1
            if has_disagreement:
                disagreement_count += 1
                
            # Critic challenges
            if "critic" in role or "reviewer" in role or "auditor" in role or "advocate" in role:
                critic_turns += 1
                if has_disagreement:
                    critic_challenges += 1
                    
            # Info flow
            for kw in all_private_keywords:
                if kw in content:
                    found_keywords.add(kw)
                    
            # Repetition (similarity with previous turn)
            if i > 0:
                prev_content = transcript[i-1].get("content", "")
                similarity = difflib.SequenceMatcher(None, prev_content, content).ratio()
                repetition_sum += similarity

        # Compute final scores
        total_ag_dis = agreement_count + disagreement_count
        agreement_score = agreement_count / total_ag_dis if total_ag_dis > 0 else 0.5
        diversity_score = 1.0 - agreement_score
        
        # Gini-like contribution balance (1.0 means perfectly balanced, 0.0 means one agent did everything)
        if total_words > 0 and len(agent_words) > 0:
            expected_share = 1.0 / len(agent_words)
            variance = sum(( (count / total_words) - expected_share ) ** 2 for count in agent_words.values())
            # Normalize variance: max variance is (1-expected)^2 + (n-1)*(0-expected)^2
            max_variance = ((1.0 - expected_share) ** 2) + ((len(agent_words) - 1) * (expected_share ** 2))
            contribution_balance = 1.0 - (variance / max_variance if max_variance > 0 else 0)
        else:
            contribution_balance = 0.0
            
        critic_challenge_rate = critic_challenges / critic_turns if critic_turns > 0 else 0.0
        info_flow_score = len(found_keywords) / total_private_keywords if total_private_keywords > 0 else 1.0
        repetition_score = repetition_sum / (turn_count - 1) if turn_count > 1 else 0.0

        return {
            "agreement_score": round(agreement_score, 3),
            "diversity_score": round(diversity_score, 3),
            "contribution_balance": round(contribution_balance, 3),
            "critic_challenge_rate": round(critic_challenge_rate, 3),
            "info_flow_score": round(info_flow_score, 3),
            "turn_count": turn_count,
            "repetition_score": round(repetition_score, 3)
        }
