from .rule_detectors.stagnation import StagnationDetector
from .rule_detectors.dominance import DominanceDetector
from .rule_detectors.handoff_corruption import HandoffCorruptionDetector
from .llm_detectors.echo_chamber import EchoChamberDetector
from .llm_detectors.info_silo import InfoSiloDetector
from .llm_detectors.role_drift import RoleDriftDetector

class HybridPipeline:
    def __init__(self, judge_client=None):
        # Rule Based
        self.stagnation = StagnationDetector()
        self.dominance = DominanceDetector()
        self.handoff = HandoffCorruptionDetector()
        
        # LLM Based
        self.echo_chamber = EchoChamberDetector(judge_client)
        self.info_silo = InfoSiloDetector(judge_client)
        self.role_drift = RoleDriftDetector(judge_client)

    def run(self, transcript, task_spec):
        """
        Runs the full hybrid detection pipeline on a single transcript.
        Returns a vector of the 6 failure modes.
        """
        results = {
            "F1_EchoChamber": self.echo_chamber.detect(transcript, task_spec),
            "F2_InfoSilo": self.info_silo.detect(transcript, task_spec),
            "F3_RoleDrift": self.role_drift.detect(transcript, task_spec),
            "F4_Dominance": self.dominance.detect(transcript, task_spec['agent_profiles']),
            "F5_HandoffCorruption": self.handoff.detect(transcript, task_spec),
            "F6_Stagnation": self.stagnation.detect(transcript)
        }
        return results
