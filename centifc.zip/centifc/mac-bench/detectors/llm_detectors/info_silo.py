import litellm
import json
import os

class InfoSiloDetector:
    def __init__(self, judge_model=None):
        self.judge_model = judge_model or os.getenv("JUDGE_MODEL", "gpt-4o")

    def detect(self, transcript, task_spec):
        """
        Detects F2: Information Silo
        Uses LLM-as-Judge to see if critical private information was never shared.
        """
        prompt = f"""
        You are an expert judge evaluating multi-agent transcripts for 'Information Silo' failures.
        Task: {task_spec.get('description', '')}
        Agent Profiles (with private information): {task_spec.get('agent_profiles', [])}
        Transcript: {transcript}
        
        Did any agent fail to share their critical private information that was necessary to solve the task?
        Answer strictly in JSON format: {{"flagged": bool, "reason": "string"}}
        """
        try:
            response = litellm.completion(
                model=self.judge_model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            return {"flagged": False, "reason": f"Judge error: {str(e)}"}
