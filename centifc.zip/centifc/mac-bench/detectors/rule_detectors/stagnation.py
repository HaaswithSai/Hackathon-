import difflib

class StagnationDetector:
    def __init__(self, threshold=0.92, max_turns=3):
        self.threshold = threshold
        self.max_turns = max_turns

    def detect(self, transcript):
        """
        Detects F6: Stagnation Loop
        Rule: Computes similarity of consecutive turns. If > threshold for `max_turns` consecutive, flag.
        """
        loop_count = 0
        for i in range(1, len(transcript)):
            prev = transcript[i-1]["content"]
            curr = transcript[i]["content"]
            
            # Simple sequence matcher for similarity (in prod, use cosine similarity with embeddings)
            similarity = difflib.SequenceMatcher(None, prev, curr).ratio()
            
            if similarity >= self.threshold:
                loop_count += 1
            else:
                loop_count = 0
                
            if loop_count >= self.max_turns - 1:
                return {"flagged": True, "turn": i, "severity": "High"}
                
        return {"flagged": False}
