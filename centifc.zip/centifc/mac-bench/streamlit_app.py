import streamlit as st
import json
import os
import glob
import pandas as pd
from collections import defaultdict

# Page config
st.set_page_config(
    page_title="MAC-Bench Leaderboard",
    page_icon="🏆",
    layout="wide"
)

st.title("🏆 Multi-Agent Coordination Benchmark (MAC-Bench)")
st.markdown("This dashboard presents the evaluation results of various multi-agent frameworks and underlying language models across different coordination failure modes.")

@st.cache_data
def load_evaluation_data():
    eval_files = glob.glob("results/evaluations/*_eval.json")
    
    if not eval_files:
        return None, None
        
    # Stats structure: [framework][model] -> { success_count: int, total_count: int, failures: { F1: int, ... } }
    stats = defaultdict(lambda: defaultdict(lambda: {
        "success_count": 0,
        "total_count": 0,
        "failures": {
            "F1_EchoChamber": 0,
            "F2_InfoSilo": 0,
            "F3_RoleDrift": 0,
            "F4_Dominance": 0,
            "F5_HandoffCorruption": 0,
            "F6_Stagnation": 0
        },
        "total_turns": 0
    }))
    
    raw_evals = []

    for file_path in eval_files:
        try:
            with open(file_path, "r") as f:
                data = json.load(f)
                
            fw = data["metadata"]["framework"]
            mod = data["metadata"]["model"]
            
            # Record raw data for detailed view
            raw_evals.append({
                "Framework": fw,
                "Model": mod,
                "Task": data["metadata"].get("task_name", "Unknown"),
                "Success": data["task_success"],
                "Turns": data["efficiency"]["turn_count"],
                "Timestamp": data["metadata"].get("timestamp", "")
            })
            
            entry = stats[fw][mod]
            entry["total_count"] += 1
            
            if data["task_success"]:
                entry["success_count"] += 1
                
            for f_mode, f_result in data["failure_profile"].items():
                if f_result.get("flagged", False):
                    entry["failures"][f_mode] += 1
                    
            entry["total_turns"] += data["efficiency"]["turn_count"]
        except Exception as e:
            st.warning(f"Error parsing {file_path}: {e}")

    # Prepare DataFrame for Leaderboard
    leaderboard_data = []
    failure_data = []
    
    for fw, models in stats.items():
        for mod, data in models.items():
            success_rate = (data["success_count"] / data["total_count"]) * 100 if data["total_count"] > 0 else 0
            avg_turns = data["total_turns"] / data["total_count"] if data["total_count"] > 0 else 0
            
            # Get top failures string
            sorted_failures = sorted(data["failures"].items(), key=lambda x: x[1], reverse=True)
            top_failures_str = ", ".join([f"{k.split('_')[0]}: {v}" for k, v in sorted_failures[:2] if v > 0])
            if not top_failures_str:
                top_failures_str = "None"
                
            leaderboard_data.append({
                "Framework": fw,
                "Model": mod,
                "Success Rate (%)": round(success_rate, 1),
                "Avg Turns": round(avg_turns, 1),
                "Evaluations": data["total_count"],
                "Top Failures": top_failures_str
            })
            
            # Prepare failure data for charts
            for failure, count in data["failures"].items():
                failure_data.append({
                    "Framework": fw,
                    "Model": mod,
                    "Failure Mode": failure,
                    "Count": count
                })

    df_leaderboard = pd.DataFrame(leaderboard_data)
    df_failures = pd.DataFrame(failure_data)
    df_raw = pd.DataFrame(raw_evals)
    
    return df_leaderboard, df_failures, df_raw

df_leaderboard, df_failures, df_raw = load_evaluation_data()

if df_leaderboard is None or df_leaderboard.empty:
    st.info("No evaluations found. Run the harness and evaluate first.")
else:
    # Key Metrics
    st.header("Overall Metrics")
    col1, col2, col3 = st.columns(3)
    
    total_evals = df_leaderboard["Evaluations"].sum()
    avg_success = df_leaderboard["Success Rate (%)"].mean()
    avg_turns = df_leaderboard["Avg Turns"].mean()
    
    col1.metric("Total Evaluations", total_evals)
    col2.metric("Average Success Rate", f"{avg_success:.1f}%")
    col3.metric("Average Turns", f"{avg_turns:.1f}")
    
    st.divider()

    # Leaderboard
    st.header("🏆 Leaderboard")
    
    # Optional filtering
    selected_frameworks = st.multiselect(
        "Filter by Framework", 
        options=df_leaderboard["Framework"].unique(),
        default=df_leaderboard["Framework"].unique()
    )
    
    filtered_df = df_leaderboard[df_leaderboard["Framework"].isin(selected_frameworks)]
    
    # Sort dataframe
    filtered_df = filtered_df.sort_values(by="Success Rate (%)", ascending=False).reset_index(drop=True)
    
    st.dataframe(
        filtered_df,
        column_config={
            "Success Rate (%)": st.column_config.ProgressColumn(
                "Success Rate (%)",
                help="Task Success Rate",
                format="%f%%",
                min_value=0,
                max_value=100,
            ),
        },
        hide_index=True,
        use_container_width=True
    )
    
    st.divider()
    
    # Failure Modes Analysis
    st.header("⚠️ Failure Profiles")
    st.markdown("Breakdown of failure modes detected during evaluations.")
    
    if not df_failures.empty:
        # Group by Framework and Failure Mode
        failure_summary = df_failures.groupby(["Framework", "Failure Mode"])["Count"].sum().reset_index()
        
        # Pivot for stacked bar chart
        pivot_failures = failure_summary.pivot(index="Framework", columns="Failure Mode", values="Count").fillna(0)
        
        st.bar_chart(pivot_failures)
    
    with st.expander("View Detailed Logs"):
        st.dataframe(df_raw, use_container_width=True)

