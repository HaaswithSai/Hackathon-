# Failure-Mode Taxonomy

This document defines the 6 precise, falsifiable ways multi-agent systems fail at coordination, as measured by `mac-bench`.

## F1 — Echo Chamber (False Consensus)
**Definition:** Agents converge to agreement before sufficient evidence supports it, and the resulting answer is wrong.
**Detection Mechanism:** LLM-as-Judge. Detectable by watching the disagreement rate drop to zero while the evidence base remains unexplored. The judge assesses whether the agents agreed due to social pressure/momentum rather than grounded reasoning.

## F2 — Information Silo
**Definition:** Critical private information known to Agent X (or retrieved via Agent X's tools) never gets communicated to the rest of the team or incorporated into the final answer.
**Detection Mechanism:** LLM-as-Judge. Traces whether each agent's uniquely provided private facts appear anywhere in the shared reasoning thread or the final artifact.

## F3 — Role Drift
**Definition:** An agent abandons its assigned function for a sustained period (2+ consecutive turns). For example, a Critic that only approves or a Fact-Checker that only proposes new ideas.
**Detection Mechanism:** LLM-as-Judge. Compares actual output distribution and action types against the assigned-role description. Distinguishes from helpful flexibility by requiring a sustained deviation.

## F4 — Dominant Agent Silencing
**Definition:** One agent contributes >60% of the substantive content, and at least one other agent's unique, necessary contributions are absent from the final answer.
**Detection Mechanism:** Rule-Based. Turn-length analysis and content-origin tracing.

## F5 — Handoff Corruption
**Definition:** Facts or intermediate artifacts get distorted as they pass between agents in a pipeline. Numbers change, claims get dropped, or hallucinations are introduced during the transfer.
**Detection Mechanism:** Rule-Based. Entity and number tracking across handoff boundaries (e.g., comparing the output of Agent A with the input utilization of Agent B).

## F6 — Stagnation Loop
**Definition:** Agents keep cycling through the same content without making progress toward task completion.
**Detection Mechanism:** Rule-Based. Computes semantic similarity of consecutive turns. If similarity is >0.92 for 3+ consecutive turns, the team is in a stagnation loop.
